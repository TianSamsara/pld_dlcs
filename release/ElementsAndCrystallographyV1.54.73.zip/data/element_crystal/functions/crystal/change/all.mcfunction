scoreboard players set @s element_zf_hold_ldl -1

scoreboard players set @s number_middle -1

#获取自身的炉子等级
execute store result score @s element_zf_hold_ldl run data get entity @s SelectedItem.tag.rare

# 检测结晶

execute if predicate element_crystal:element_crystal/off_hand/crystal/common run scoreboard players set @s number_middle 0
execute if predicate element_crystal:element_crystal/off_hand/crystal/refined run scoreboard players set @s number_middle 1
execute if predicate element_crystal:element_crystal/off_hand/crystal/condense run scoreboard players set @s number_middle 2

# 如果是傻逼罪乳鸽的逆天写法则跳出检测
execute if score @s number_middle matches 10.. run scoreboard players set @s number_middle -1

# 如果是普通元素
execute if score @s number_middle matches 0 if score @s element_zf_hold_ldl matches 3.. run function element_crystal:crystal/change/reset
# 如果是精炼元素
execute if score @s number_middle matches 1 if score @s element_zf_hold_ldl matches 4.. run function element_crystal:crystal/change/reset
# 如果是浓缩元素
execute if score @s number_middle matches 2 if score @s element_zf_hold_ldl matches 5.. run function element_crystal:crystal/change/reset