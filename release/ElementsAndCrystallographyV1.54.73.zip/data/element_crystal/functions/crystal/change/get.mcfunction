# number_middle=结晶等级
execute store result score @s number_middle run data get block ~ ~ ~ Items[{Slot:0b}].tag.element_crystal.crystal
# number_middle_1=法宝等级
execute store result score @s number_middle_1 run data get block ~ ~ ~ Items[{Slot:0b}].tag.element_crystal.level

scoreboard players set @s number_middle_2 0
# 如果自身法宝等级小于结晶等级，则将结晶等级设置为0
execute if score @s number_middle_1 <= @s number_middle run scoreboard players set @s number_middle_2 1
# 如果自身法宝等级小于结晶等级，则将结晶等级设置为0
execute if score @s number_middle_1 <= @s number_middle run scoreboard players set @s number_middle 0
# 如果自身法宝等级大于结晶等级，则将结晶等级+1
execute if score @s number_middle_2 matches 0 if score @s number_middle_1 > @s number_middle run scoreboard players add @s number_middle 1

# 将结晶等级赋予武器
execute store result block ~ ~ ~ Items[{Slot:0b}].tag.element_crystal.crystal int 1 run scoreboard players get @s number_middle 