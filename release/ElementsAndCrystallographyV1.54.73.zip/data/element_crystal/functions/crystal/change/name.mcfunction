

# 生成标记

summon marker ~ ~ ~ {Tags:["panling","element.crystal.change","name1"],CustomName:'{"translate":""}',CustomNameVisible:false}
summon marker ~ ~ ~ {Tags:["panling","element.crystal.change","name2"],CustomName:'{"translate":""}',CustomNameVisible:false}


# number_middle=结晶等级
execute store result score @s number_middle run data get block ~ ~ ~ Items[{Slot:0b}].tag.element_crystal.crystal
# number_middle_1=元素类别
execute store result score @s number_middle_1 run data get block ~ ~ ~ Items[{Slot:0b}].tag.element_crystal.element


data get entity @e[limit=1,tag=panling,tag=element.crystal.change,tag=name1] CustomName

# 根据结晶等级赋予名字
execute if score @s number_middle matches 0 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.common.name"}'
execute if score @s number_middle matches 1 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.refined.name"}'
execute if score @s number_middle matches 2 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.condense.name"}'
execute if score @s number_middle matches 3 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.distil.name"}'
data modify entity @e[limit=1,tag=panling,tag=element.crystal.change,tag=name1] CustomName set from storage element_subject:crystal/change 名字

# 根据元素类别赋予名字
execute if score @s number_middle_1 matches 0 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.metal.name"}'
execute if score @s number_middle_1 matches 1 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.wood.name"}'
execute if score @s number_middle_1 matches 2 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.water.name"}'
execute if score @s number_middle_1 matches 3 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.fire.name"}'
execute if score @s number_middle_1 matches 4 run data modify storage element_subject:crystal/change 名字 set value '{"translate":"element_crystal.item.crystal.earth.name"}'
data modify entity @e[limit=1,tag=panling,tag=element.crystal.change,tag=name2] CustomName set from storage element_subject:crystal/change 名字


# 放置告示牌
setblock ~ ~1 ~ minecraft:oak_sign{front_text:{messages:['[{"selector":"@e[tag=panling,tag=element.crystal.change,tag=name1]"},{"selector":"@e[tag=panling,tag=element.crystal.change,tag=name2]"}]','{"translate":""}','{"translate":""}','{"translate":""}']}} replace

# 设置名字
data modify block ~ ~ ~ Items.[{Slot:0b}].tag.display.Name set from block ~ ~1 ~ front_text.messages[0]


# 清除盔甲架
kill @e[type=marker,tag=element.crystal.change]


