# 传统激活
# 替换副手
setblock ~ 255 ~ chest
function pld:equipment_lock/lock/offhand

# 将等级的数据存入副手物品上
execute positioned ~ 255 ~ run function element_crystal:crystal/change/get

# 更改名字
execute positioned ~ 255 ~ run function element_crystal:crystal/change/name

# 替换副手物品
function pld:equipment_lock/replace/player_offhand_replace
setblock ~ 255 ~ air

# 重置 停止继续检测
scoreboard players set @s element_zf_hold_ldl 0
