
# 检测结晶
# 如果是普通元素
execute unless score @s number_middle_4 matches ..-1 if predicate element_crystal:element_crystal/off_hand/crystal/common run function element_crystal:crystal/get/common/all
# 如果是精炼元素
execute unless score @s number_middle_4 matches ..-1 if predicate element_crystal:element_crystal/off_hand/crystal/refined run function element_crystal:crystal/get/refined/all
# 如果是浓缩元素
execute unless score @s number_middle_4 matches ..-1 if predicate element_crystal:element_crystal/off_hand/crystal/condense run function element_crystal:crystal/get/condense/all
# # 如果是蒸馏元素
# execute if predicate element_crystal:element_crystal/off_hand/crystal/distil run function element_crystal:crystal/get/distil/all

# 如果被截断了则返回
scoreboard players remove @s[scores={number_middle_4=..-1}] number_middle_4 1
