
execute unless score @s number_middle matches 1.. run function element_crystal:crystal/get/none
execute if score @s number_middle matches 1.. run function element_crystal:crystal/get/common/earth/count