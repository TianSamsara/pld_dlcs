
# 拥有的数量-number_middle

# 获得元素
scoreboard players operation @s count = @s number_middle
# 检测背包内空位
function element.subject:give/back
function element.subject:give/decide_64
scoreboard players operation @s number_middle_1 -= @s count
function element.subject:give/element/common/fire/count


# 更新副手物品
function element_crystal:crystal/set/off/element_count
# 显示
function element_crystal:crystal/get/on

