# 分包 原版镜像

# pld:system/zf/shifang/incool/ 
# element_crystal:crystal/get/condense/condense/

# 设置为浓缩元素
scoreboard players set @s number_middle_3 2

# 获取副手的普通元素存储量
execute store result score @s number_middle run data get entity @s Inventory[{Slot:-106b}].tag.element_count.condense
scoreboard players operation @s number_middle_1 = @s number_middle


#检测金元素
execute if predicate element_crystal:element_crystal/off_hand/element/metal run function element_crystal:crystal/get/condense/metal/getmain

#检测木元素
execute if predicate element_crystal:element_crystal/off_hand/element/wood run function element_crystal:crystal/get/condense/wood/getmain

#检测水元素
execute if predicate element_crystal:element_crystal/off_hand/element/water run function element_crystal:crystal/get/condense/water/getmain

#检测火元素
execute if predicate element_crystal:element_crystal/off_hand/element/fire run function element_crystal:crystal/get/condense/fire/getmain

#检测土元素
execute if predicate element_crystal:element_crystal/off_hand/element/earth run function element_crystal:crystal/get/condense/earth/getmain

