title @s actionbar {"text":"","extra":[{"text":"已经没有元素了！","color":"red","bold":true}]}
