# 分包 原版镜像

# pld:system/zf/shifang/incool/ 
# element_crystal:crystal/get/refined/refined/

# 设置为精炼元素
scoreboard players set @s number_middle_3 1

# 获取副手的普通元素存储量
execute store result score @s number_middle run data get entity @s Inventory[{Slot:-106b}].tag.element_count.refined
scoreboard players operation @s number_middle_1 = @s number_middle


#检测金元素
execute if predicate element_crystal:element_crystal/off_hand/element/metal run function element_crystal:crystal/get/refined/metal/getmain

#检测木元素
execute if predicate element_crystal:element_crystal/off_hand/element/wood run function element_crystal:crystal/get/refined/wood/getmain

#检测水元素
execute if predicate element_crystal:element_crystal/off_hand/element/water run function element_crystal:crystal/get/refined/water/getmain

#检测火元素
execute if predicate element_crystal:element_crystal/off_hand/element/fire run function element_crystal:crystal/get/refined/fire/getmain

#检测土元素
execute if predicate element_crystal:element_crystal/off_hand/element/earth run function element_crystal:crystal/get/refined/earth/getmain

