# 检测主手是不是空气

execute unless entity @s[nbt={SelectedItem:{}}] run function element_crystal:crystal/get/refined/metal/getcont