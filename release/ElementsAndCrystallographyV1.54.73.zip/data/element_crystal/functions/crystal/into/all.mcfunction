scoreboard players set @s number_middle_4 0

# 检测结晶
# 如果是普通元素
execute if predicate element_crystal:element_crystal/off_hand/crystal/common run function element_crystal:crystal/into/common/all
# 如果是精炼元素
execute if predicate element_crystal:element_crystal/off_hand/crystal/refined run function element_crystal:crystal/into/refined/all
# 如果是浓缩元素
execute if predicate element_crystal:element_crystal/off_hand/crystal/condense run function element_crystal:crystal/into/condense/all
# # 如果是蒸馏元素
# execute if predicate element_crystal:element_crystal/off_hand/crystal/distil run function element_crystal:crystal/into/distil/all


