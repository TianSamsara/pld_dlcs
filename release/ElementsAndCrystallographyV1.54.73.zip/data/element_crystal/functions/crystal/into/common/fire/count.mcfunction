
# 距离上限的数量-number_middle

# 检测背包内元素数量
execute store result score @s number_middle_2 run clear @s minecraft:blaze_rod{id:"panling:fire"} 0 
# 如果大于距离上限的数量则将清空的数量设置为距离上限的数量
execute if score @s number_middle_2 >= @s number_middle run scoreboard players operation @s number_middle_2 = @s number_middle

# 获得元素数量
scoreboard players operation @s number_middle_1 += @s number_middle_2

# 清除元素
scoreboard players operation @s count = @s number_middle_2
function element.subject:clear/element/common/fire/count

# 更新副手物品
function element_crystal:crystal/set/off/element_count
# 显示
function element_crystal:crystal/into/in

