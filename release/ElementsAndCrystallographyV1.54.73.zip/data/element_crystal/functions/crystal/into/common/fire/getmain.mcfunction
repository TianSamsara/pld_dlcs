# 检测主手是不是火元素

execute if entity @s[nbt={SelectedItem:{tag:{id:"panling:fire"}}}] run function element_crystal:crystal/into/common/fire/getcont