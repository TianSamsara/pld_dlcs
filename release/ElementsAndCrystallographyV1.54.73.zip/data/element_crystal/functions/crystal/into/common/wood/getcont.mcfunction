
execute unless score @s number_middle matches 1.. run function element_crystal:crystal/into/full
execute if score @s number_middle matches 1.. run function element_crystal:crystal/into/common/wood/count