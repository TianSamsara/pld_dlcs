# 检测主手是不是土元素

execute if entity @s[nbt={SelectedItem:{tag:{id:"panling:again_refined_earth"}}}] run function element_crystal:crystal/into/condense/earth/getcont