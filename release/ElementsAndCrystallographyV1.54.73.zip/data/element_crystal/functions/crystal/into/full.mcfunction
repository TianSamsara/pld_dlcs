title @s actionbar {"text":"","extra":[{"text":"存储数量已达上限！","color":"red","bold":true}]}
