title @s actionbar {"text":"","extra":[{"text":"成功存入","color":"green","bold":true},{"score":{"name":"@s","objective":"number_middle_2"},"color":"green","bold":true},{"translate":"个元素","color":"green","bold":true}]}
# 截断运行
scoreboard players remove @s number_middle_4 1
