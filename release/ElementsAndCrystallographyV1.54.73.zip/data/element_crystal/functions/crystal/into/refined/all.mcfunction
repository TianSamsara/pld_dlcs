# 分包 原版镜像

# pld:system/zf/shifang/incool/ 
# element_crystal:crystal/into/refined/refined/

# 检测等级
# 精炼

execute if predicate element_crystal:element_crystal/off_hand/level/refined run scoreboard players operation @s number_middle = refined element_crystal_element_refined
execute if predicate element_crystal:element_crystal/off_hand/level/condense run scoreboard players operation @s number_middle = condense element_crystal_element_refined
execute if predicate element_crystal:element_crystal/off_hand/level/distil run scoreboard players operation @s number_middle = distil element_crystal_element_refined


# 设置为精炼元素
scoreboard players set @s number_middle_3 1

# 获取副手的普通元素存储量
execute store result score @s number_middle_1 run data get entity @s Inventory[{Slot:-106b}].tag.element_count.refined
# 计算距离上限的数量
scoreboard players operation @s number_middle -= @s number_middle_1


#检测金元素
execute if predicate element_crystal:element_crystal/off_hand/element/metal run function element_crystal:crystal/into/refined/metal/getmain

#检测木元素
execute if predicate element_crystal:element_crystal/off_hand/element/wood run function element_crystal:crystal/into/refined/wood/getmain

#检测水元素
execute if predicate element_crystal:element_crystal/off_hand/element/water run function element_crystal:crystal/into/refined/water/getmain

#检测火元素
execute if predicate element_crystal:element_crystal/off_hand/element/fire run function element_crystal:crystal/into/refined/fire/getmain

#检测土元素
execute if predicate element_crystal:element_crystal/off_hand/element/earth run function element_crystal:crystal/into/refined/earth/getmain

