# 检测主手是不是金元素

execute if entity @s[nbt={SelectedItem:{tag:{id:"panling:refined_metal"}}}] run function element_crystal:crystal/into/refined/metal/getcont