# 检测主手是不是水元素

execute if entity @s[nbt={SelectedItem:{tag:{id:"panling:refined_water"}}}] run function element_crystal:crystal/into/refined/water/getcont