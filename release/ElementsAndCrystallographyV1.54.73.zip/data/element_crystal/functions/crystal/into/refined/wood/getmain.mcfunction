# 检测主手是不是木元素

execute if entity @s[nbt={SelectedItem:{tag:{id:"panling:refined_wood"}}}] run function element_crystal:crystal/into/refined/wood/getcont