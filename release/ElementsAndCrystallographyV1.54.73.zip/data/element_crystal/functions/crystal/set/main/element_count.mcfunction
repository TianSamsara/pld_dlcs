# 传统激活
setblock ~ 255 ~ chest

# 替换主手
data modify storage pld:system Temp set value []
data modify storage pld:system Temp append from entity @s SelectedItem
data modify block ~ 255 ~ Items set from storage pld:system Temp

# 将物品个数载入到结晶内
# 普通元素
execute if score @s number_middle_3 matches 0 store result block ~ 255 ~ Items[{Slot:0b}].tag.element_count.common int 1 run scoreboard players get @s number_middle_1
# 精炼元素
execute if score @s number_middle_3 matches 1 store result block ~ 255 ~ Items[{Slot:0b}].tag.element_count.refined int 1 run scoreboard players get @s number_middle_1
# 浓缩元素
execute if score @s number_middle_3 matches 2 store result block ~ 255 ~ Items[{Slot:0b}].tag.element_count.condense int 1 run scoreboard players get @s number_middle_1
# 蒸馏元素
execute if score @s number_middle_3 matches 3 store result block ~ 255 ~ Items[{Slot:0b}].tag.element_count.distil int 1 run scoreboard players get @s number_middle_1
# 替换手上物品
item replace entity @s weapon.mainhand from block ~ 255 ~ container.0
setblock ~ 255 ~ air
