# 检测结晶
# 如果是普通元素
execute if predicate element_crystal:element_crystal/main_hand/crystal/common run function element_crystal:crystal/use/common/all
# 如果是精炼元素
execute if predicate element_crystal:element_crystal/main_hand/crystal/refined run function element_crystal:crystal/use/refined/all
# 如果是浓缩元素
execute as @s[scores={element_cannon=1}] if predicate element_crystal:element_crystal/main_hand/crystal/condense run function element_crystal:crystal/use/condense/all
