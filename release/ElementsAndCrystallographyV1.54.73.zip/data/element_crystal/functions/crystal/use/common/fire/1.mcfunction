execute if score @s zf_cool_fire matches 0.. run function pld:system/zf/shifang/incool/fire/fire
execute unless score @s zf_cool_fire matches 0.. run function element_crystal:crystal/use/common/fire/count

