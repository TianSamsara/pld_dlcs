execute if score @s zf_cool_wood matches 0.. run function pld:system/zf/shifang/incool/wood/wood
execute unless score @s zf_cool_wood matches 0.. run function element_crystal:crystal/use/common/wood/count

