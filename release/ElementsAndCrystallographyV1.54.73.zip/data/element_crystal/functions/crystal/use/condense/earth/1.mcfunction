execute if score @s zf_cool_earth matches 0.. run function pld:system/zf/shifang/incool/earth/earth
execute unless score @s zf_cool_earth matches 0.. run function element_crystal:crystal/use/condense/earth/count

