#扣除元素

# 计算拥有元素数量
# 背包
execute store result score @s number_middle run clear @s minecraft:wheat_seeds{id:"panling:again_refined_water"} 0 
scoreboard players operation @s number_middle_2 = @s number_middle

# 便携元素银行
scoreboard players operation @s number_middle_2 *= distil element_crystal.element.ratio
scoreboard players operation @s number_middle_2 += @s[scores={element_crystal_mod=1}] element_number_water 
scoreboard players operation @s number_middle_2 /= distil element_crystal.element.ratio

# 结晶
scoreboard players operation @s number_middle_2 += @s number_middle_1 

# 如果没有元素
execute unless score @s number_middle_2 matches 1.. run function element_crystal:crystal/use/null

# # 计算不消耗
# execute as @s[scores={number_middle_2=1..}] store success score @s[scores={zfsuccess=0}] zfsuccess run effect clear @p[distance=..5,limit=5] poison
# execute as @s[scores={number_middle_2=1..}] store success score @s[scores={zfsuccess=0}] zfsuccess run effect clear @p[distance=..5,limit=5] wither
# execute as @s[scores={number_middle_2=1..}] run function pld:system/zf/l6_check
# 如果有元素
execute as @s[scores={number_middle_2=1..}] run function pld:system/zf/shifang/main/again_refined/again_refined_water_main

# 在身上没元素 并且元素消耗的情况下运行
execute as @s[scores={number_middle_2=1..,zfsuccess=1,ldl6success=1,number_middle=0}] run function element_crystal:crystal/use/condense/water/remove
# execute unless score @s[scores={number_middle_2=1..,zfsuccess=1}] ldl6success matches 1 run function element_crystal:crystal/use/condense/water/water_main
