# 分包 原版镜像

# pld:system/zf/shifang/incool/ 
# element_crystal:crystal/use/refined/


# 检测副手元素剩余量
execute store result score @s number_middle_1 run data get entity @s SelectedItem.tag.element_count.refined
# 设置为精炼元素
scoreboard players set @s number_middle_3 1

#检测金元素
execute if entity @s[nbt={SelectedItem:{tag:{element_crystal:{element:0}}}}] run function element_crystal:crystal/use/refined/metal/1

#检测木元素
execute if entity @s[nbt={SelectedItem:{tag:{element_crystal:{element:1}}}}] run function element_crystal:crystal/use/refined/wood/1

#检测水元素
execute if entity @s[nbt={SelectedItem:{tag:{element_crystal:{element:2}}}}] at @s run function element_crystal:crystal/use/refined/water/1

#检测火元素
execute if entity @s[nbt={SelectedItem:{tag:{element_crystal:{element:3}}}}] at @s run function element_crystal:crystal/use/refined/fire/1

#检测土元素
execute if entity @s[nbt={SelectedItem:{tag:{element_crystal:{element:4}}}}] at @s run function element_crystal:crystal/use/refined/earth/1

