# 元素结晶dlc插入

# 清空中间量
scoreboard players set @s number_middle_2 0

# 如果有元素则优先依旧扣除背包元素-1
# 检测背包对应元素数量
execute store result score @s number_middle run clear @s minecraft:blaze_rod{id:"panling:refined_fire"} 0 
# 结算扣除
scoreboard players set @s[scores={number_middle=1..}] number_middle_2 1
# 清空背包对应元素
clear @s[scores={number_middle_2=1,number_middle=1..}] minecraft:blaze_rod{id:"panling:refined_fire"} 1

# 便携元素银行-2
# 不消耗转化
# 结算扣除
scoreboard players set @s[scores={element_crystal_mod=1,number_middle_2=0,element_number_fire=1..}] number_middle_2 2
# 会消耗转化 银行扣除
scoreboard players operation @s[scores={element_crystal_mod=1,number_middle_2=2,element_number_fire=1..}] element_number_fire -= distil element_crystal.element.ratio



# DEW-3
# 建木元素熔炉


# 万通货斋-4
# 乾坤袋


# 结算扣除-114
scoreboard players set @s[scores={number_middle_2=0,number_middle_1=1..}] number_middle_2 114
# 最后结算结晶内缓存
scoreboard players remove @s[scores={number_middle_2=114}] number_middle_1 1
function element_crystal:crystal/set/main/element_count

# 如果扣除被结算
scoreboard players set @s zfsuccess 0
execute if score @s number_middle_2 matches 1.. run function element_crystal:crystal/use/refined/fire/fire_main