#扣除元素

# 计算拥有元素数量
# 背包
execute store result score @s number_middle run clear @s minecraft:bone{id:"panling:refined_wood"} 0 
scoreboard players operation @s number_middle_2 = @s number_middle

# 便携元素银行
scoreboard players operation @s number_middle_2 *= refined element_crystal.element.ratio
scoreboard players operation @s number_middle_2 += @s[scores={element_crystal_mod=1}] element_number_wood 
scoreboard players operation @s number_middle_2 /= refined element_crystal.element.ratio

# 结晶
scoreboard players operation @s number_middle_2 += @s number_middle_1 

# 如果没有元素
execute unless score @s number_middle_2 matches 1.. run function element_crystal:crystal/use/null

# # 计算不消耗
# execute as @s[scores={number_middle_2=1..}] run scoreboard players set @s zfsuccess 1
# execute as @s[scores={number_middle_2=1..}] run function pld:system/zf/l6_check
# 如果有元素
execute as @s[scores={number_middle_2=1..}] run function pld:system/zf/shifang/main/refined/wood/refined_wood_main

# 在身上没元素 并且元素消耗的情况下运行
execute as @s[scores={number_middle_2=1..,zfsuccess=1,ldl6success=1,number_middle=0}] run function element_crystal:crystal/use/refined/wood/remove
# execute unless score @s[scores={number_middle_2=1..,zfsuccess=1}] ldl6success matches 1 run function element_crystal:crystal/use/refined/wood/wood_main
