#核心处是核心、部位材料处是装备
# 区分铁的等级

# 赤铜锭
execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{id:"panling:weapon_core_3"}}]} run function element_crystal:dz/crystal/common/all
# 玄铁锭
execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{id:"panling:weapon_core_4"}}]} run function element_crystal:dz/crystal/refined/all
# 灵玉简
execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{id:"panling:weapon_core_5"}}]} run function element_crystal:dz/crystal/condense/all
