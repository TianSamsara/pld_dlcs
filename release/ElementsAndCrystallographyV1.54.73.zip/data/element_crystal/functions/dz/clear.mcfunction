
# 清空标记
scoreboard players set 锻造成功标记 dz 0

# 清空元素
data modify block ~ ~ ~ Items[{Slot:0b}].Count set value 0

# 清空核心
data modify block ~ ~ ~ Items[{Slot:3b}].Count set value 0

# 清空部位材料
data modify block ~ ~ ~ Items[{Slot:6b}].Count set value 0