#核心处是核心、部位材料处是装备

# 获取元素数量
data modify storage element_subject:crystal/dz 元素存储量 set from block ~ ~ ~ Items[{Slot:0b}].Count
data modify storage element_subject:crystal/dz 部位存储量 set from block ~ ~ ~ Items[{Slot:6b}].tag.element_count

# 元素拆分
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:metal"}},{Slot:6b,Count:8b,tag:{id:"panling:element_tick"}}]} run function element_crystal:dz/crystal/common/metal/metal
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:wood"}},{Slot:6b,Count:8b,tag:{id:"panling:element_tick"}}]} run function element_crystal:dz/crystal/common/wood/wood
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:water"}},{Slot:6b,Count:8b,tag:{id:"panling:element_tick"}}]} run function element_crystal:dz/crystal/common/water/water
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:fire"}},{Slot:6b,Count:8b,tag:{id:"panling:element_tick"}}]} run function element_crystal:dz/crystal/common/fire/fire
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:earth"}},{Slot:6b,Count:8b,tag:{id:"panling:element_tick"}}]} run function element_crystal:dz/crystal/common/earth/earth

# 继承部位的元素数量
data modify block ~ ~ ~ Items[{Slot:5b}].tag.element_count set from storage element_subject:crystal/dz 部位存储量

# 加上元素位置的存储量
execute store result score 元素存储量 dz run data get storage element_subject:crystal/dz 元素存储量
execute store result score 部位存储量 dz run data get storage element_subject:crystal/dz 部位存储量.common
scoreboard players operation 元素存储量 dz += 部位存储量 dz
# 赋值
execute store result storage element_subject:crystal/dz 元素存储量 int 1 run scoreboard players get 元素存储量 dz
data modify block ~ ~ ~ Items[{Slot:5b}].tag.element_count.common set from storage element_subject:crystal/dz 元素存储量


# 清空数据
data modify storage element_subject:crystal/dz 元素存储量 set value []
data modify storage element_subject:crystal/dz 部位存储量 set value {}

execute if score 锻造成功标记 dz matches 1 run function element_crystal:dz/clear

