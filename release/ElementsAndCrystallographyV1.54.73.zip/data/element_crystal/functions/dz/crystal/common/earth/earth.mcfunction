# 土结晶锻造
# 标记
scoreboard players set 锻造成功标记 dz 1

# 调用战利品表

loot replace block ~ ~ ~ container.5 loot element_crystal:items/crtstal/common/earth