#核心处是核心、部位材料处是装备

# 获取元素数量
data modify storage element_subject:crystal/dz 元素存储量 set from block ~ ~ ~ Items[{Slot:0b}].Count
data modify storage element_subject:crystal/dz 部位存储量 set from block ~ ~ ~ Items[{Slot:6b}].tag.element_count

# 元素拆分
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:refined_metal"}},{Slot:6b,tag:{id:"element_crystal:metal"}}]} run function element_crystal:dz/crystal/refined/metal/metal
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:refined_wood"}},{Slot:6b,tag:{id:"element_crystal:wood"}}]} run function element_crystal:dz/crystal/refined/wood/wood
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:refined_water"}},{Slot:6b,tag:{id:"element_crystal:water"}}]} run function element_crystal:dz/crystal/refined/water/water
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:refined_fire"}},{Slot:6b,tag:{id:"element_crystal:fire"}}]} run function element_crystal:dz/crystal/refined/fire/fire
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{id:"panling:refined_earth"}},{Slot:6b,tag:{id:"element_crystal:earth"}}]} run function element_crystal:dz/crystal/refined/earth/earth

# 继承部位的元素数量
data modify block ~ ~ ~ Items[{Slot:5b}].tag.element_count set from storage element_subject:crystal/dz 部位存储量

# 加上元素位置的存储量
execute store result score 元素存储量 dz run data get storage element_subject:crystal/dz 元素存储量
execute store result score 部位存储量 dz run data get storage element_subject:crystal/dz 部位存储量.refined
scoreboard players operation 元素存储量 dz += 部位存储量 dz
# 赋值
execute store result storage element_subject:crystal/dz 元素存储量 int 1 run scoreboard players get 元素存储量 dz
data modify block ~ ~ ~ Items[{Slot:5b}].tag.element_count.refined set from storage element_subject:crystal/dz 元素存储量


# 清空数据
data modify storage element_subject:crystal/dz 元素存储量 set value []
data modify storage element_subject:crystal/dz 部位存储量 set value {}

execute if score 锻造成功标记 dz matches 1 run function element_crystal:dz/clear

