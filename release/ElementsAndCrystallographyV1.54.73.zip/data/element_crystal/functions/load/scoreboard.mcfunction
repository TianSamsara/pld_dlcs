# 初始化计分板

# 初始化元素存储
# scoreboard objectives add number_middle_1 dummy ["普通金元素储存量"]
# scoreboard objectives add number_middle_1 dummy ["普通木元素储存量"]
# scoreboard objectives add number_middle_1 dummy ["普通水元素储存量"]
# scoreboard objectives add number_middle_1 dummy ["普通火元素储存量"]
# scoreboard objectives add number_middle_1 dummy ["普通土元素储存量"]

# scoreboard objectives add number_middle_1 dummy ["精炼金元素储存量"]
# scoreboard objectives add number_middle_1 dummy ["精炼木元素储存量"]
# scoreboard objectives add number_middle_1 dummy ["精炼水元素储存量"]
# scoreboard objectives add number_middle_1 dummy ["精炼火元素储存量"]
# scoreboard objectives add number_middle_1 dummy ["精炼土元素储存量"]

# scoreboard objectives add element_crystal_condense_metal dummy ["浓缩金元素储存量"]
# scoreboard objectives add element_crystal_condense_wood dummy ["浓缩木元素储存量"]
# scoreboard objectives add element_crystal_condense_water dummy ["浓缩水元素储存量"]
# scoreboard objectives add element_crystal_condense_fire dummy ["浓缩火元素储存量"]
# scoreboard objectives add element_crystal_condense_earth dummy ["浓缩土元素储存量"]


scoreboard objectives add element_crystal_mod dummy ["结算模式"]
scoreboard objectives add element_zf_hold_ldl dummy ["炉子等级"]

scoreboard objectives add element_crystal.common dummy ["普通元素存储量上限"]



# 元素存储量上限
scoreboard objectives add element_crystal_element_common dummy ["普通元素存储量上限"]
scoreboard objectives add element_crystal_element_refined dummy ["精炼元素存储量上限"]
scoreboard objectives add element_crystal_element_condense dummy ["浓缩元素存储量上限"]
scoreboard objectives add element_crystal_element_distil dummy ["蒸馏元素存储量上限"]

# 普通结晶
scoreboard players set common element_crystal_element_common 128

# 精炼结晶
scoreboard players set refined element_crystal_element_common 512
scoreboard players set refined element_crystal_element_refined 128

# 浓缩结晶
scoreboard players set condense element_crystal_element_common 2048
scoreboard players set condense element_crystal_element_refined 512
scoreboard players set condense element_crystal_element_condense 128

# 蒸馏结晶
scoreboard players set distil element_crystal_element_common 8192
scoreboard players set distil element_crystal_element_refined 2048
scoreboard players set distil element_crystal_element_condense 512
scoreboard players set distil element_crystal_element_distil 128

scoreboard objectives add element_crystal.element.ratio dummy ["元素转换比例"]
scoreboard players set refined element_crystal.element.ratio 5
scoreboard players set distil element_crystal.element.ratio 40



# 秋霜`s dlc通用量

scoreboard objectives add number_middle dummy ["数字"]
scoreboard objectives add number_middle_1 dummy ["数字1"]
scoreboard objectives add number_middle_2 dummy ["数字2"]
scoreboard objectives add number_middle_3 dummy ["数字3"]
scoreboard objectives add number_middle_4 dummy ["数字4"]
scoreboard objectives add number_middle_5 dummy ["数字5"]

scoreboard objectives add dz dummy ["锻造"]


# 初始化数字
scoreboard players set 1 int 1
scoreboard players set 2 int 2
scoreboard players set 4 int 4
scoreboard players set 5 int 5
scoreboard players set 8 int 8
scoreboard players set 10 int 10
scoreboard players set 12 int 12
scoreboard players set 16 int 16
scoreboard players set 24 int 24
scoreboard players set 32 int 32
scoreboard players set 40 int 40
scoreboard players set 48 int 48
scoreboard players set 56 int 56
scoreboard players set 64 int 64
scoreboard players set 128 int 128
scoreboard players set 256 int 256
scoreboard players set 512 int 512
scoreboard players set 1024 int 1024
scoreboard players set 2048 int 2048
scoreboard players set 4096 int 4096
scoreboard players set 8192 int 8192
scoreboard players set 16384 int 16384
scoreboard players set 32768 int 32768


