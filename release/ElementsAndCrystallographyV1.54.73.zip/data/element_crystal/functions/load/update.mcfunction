# 发送信息

# 重新初始化
function element_crystal:load/once

# 发送信息

