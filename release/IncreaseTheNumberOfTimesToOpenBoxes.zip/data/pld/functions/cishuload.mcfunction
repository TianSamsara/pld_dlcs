#注册计分板
scoreboard objectives add instance1_clear dummy "始皇陵通关次数"
scoreboard objectives add instance2_clear dummy "火魔洞通关次数"
scoreboard objectives add instance3_0_clear dummy "正塔通关次数"
scoreboard objectives add instance3_1_clear dummy "反塔通关次数"
scoreboard objectives add instance4_clear dummy "哭谷通关次数"
scoreboard objectives add instance5_clear dummy "假盘通关次数"
scoreboard objectives add temp_calc dummy "临时计算次数"
scoreboard objectives add temp_chest dummy "临时宝箱计数"
scoreboard objectives add instance5_clear dummy "假盘通关次数"
scoreboard players set @s instance1_clear 0
scoreboard players set @s instance2_clear 0
scoreboard players set @s instance3_0_clear 0
scoreboard players set @s instance3_1_clear 0
scoreboard players set @s instance4_clear 0
scoreboard players set @s instance5_clear 0
scoreboard players set @s temp_calc 0
scoreboard players set @s temp_chest 0

#始皇陵部分
forceload add 2783 -410 2783 -410
setblock 2783 84 -409 minecraft:redstone_block
setblock 2783 84 -410 minecraft:repeating_command_block[facing=north] replace
data merge block 2783 84 -410 {Command:"execute if entity @a[scores={temp_calc=5..}] run scoreboard players remove @a[scores={temp_calc=5..},x=2795,y=68,z=-432,dx=47,dy=27,dz=36] temp_calc 5",enabled:0b,Condition:0b}
setblock 2783 84 -411 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 2783 84 -411 {Command:"scoreboard players add @a[scores={temp_calc=0..},x=2795,y=68,z=-432,dx=47,dy=27,dz=36] temp_chest 1",enabled:1b,Condition:1b}
setblock 2783 84 -412 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 2783 84 -412 {Command:"scoreboard players add @a[x=2795,y=68,z=-432,dx=47,dy=27,dz=36] gold_chest 1",enabled:1b,Condition:1b}
forceload remove 2783 -410 2783 -410
#火魔洞部分
forceload add 1158 892 1158 892
setblock 1158 64 892 minecraft:redstone_block
setblock 1158 64 891 minecraft:repeating_command_block[facing=north] replace
data merge block 1158 64 891 {Command:"execute if entity @a[scores={temp_calc=5..}] run scoreboard players remove @a[scores={temp_calc=5..},x=1052,y=3,z=864,dx=82,dy=55,dz=64] temp_calc 5",enabled:0b,Condition:0b}
setblock 1158 64 890 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 1158 64 890 {Command:"scoreboard players add @a[scores={temp_calc=0..},x=1052,y=3,z=864,dx=82,dy=55,dz=64] temp_chest 1",enabled:1b,Condition:1b}
setblock 1158 64 889 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 1158 64 889 {Command:"scoreboard players add @a[x=1052,y=3,z=864,dx=82,dy=55,dz=64] gold_chest 1",enabled:1b,Condition:1b}
forceload remove 1158 892 1158 892
#正塔部分
forceload add 2714 -883 2714 -883
setblock 2714 34 -883 minecraft:redstone_block
setblock 2714 34 -884 minecraft:repeating_command_block[facing=north] replace
data merge block 2714 34 -884 {Command:"execute if entity @a[scores={temp_calc=5..}] run scoreboard players remove @a[scores={temp_calc=5..},x=2695,y=90,z=-905,dx=50,dy=-80,dz=40] temp_calc 5",enabled:0b,Condition:0b}
setblock 2714 34 -885 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 2714 34 -885 {Command:"scoreboard players add @a[scores={temp_calc=0..},x=2695,y=90,z=-905,dx=50,dy=-80,dz=40] temp_chest 1",enabled:1b,Condition:1b}
setblock 2714 34 -886 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 2714 34 -886 {Command:"scoreboard players add @a[x=2695,y=90,z=-905,dx=50,dy=-80,dz=40] gold_chest 1",enabled:1b,Condition:1b}
forceload remove 2714 -883 2714 -883
#反塔部分








#哭谷部分
forceload add 944 1186 944 1186
setblock 945 78 1187 minecraft:redstone_block
setblock 945 78 1186 minecraft:repeating_command_block[facing=north] replace
data merge block 945 78 1186 {Command:"execute if entity @a[scores={temp_calc=5..}] run scoreboard players remove @a[scores={temp_calc=5..},x=912,y=57,z=1180,dx=62,dy=52,dz=100] temp_calc 5",enabled:0b,Condition:0b}
setblock 945 78 1185 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 945 78 1185 {Command:"scoreboard players add @a[scores={temp_calc=0..},x=912,y=57,z=1180,dx=62,dy=52,dz=100] temp_chest 1",enabled:1b,Condition:1b}
setblock 945 78 1184 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 945 78 1184 {Command:"scoreboard players add @a[x=912,y=57,z=1180,dx=62,dy=52,dz=100] gold_chest 1",enabled:1b,Condition:1b}
forceload remove 944 1186 944 1186



#假盘部分
forceload add 3245 -1873 3245 -1873
setblock 3245 134 -1873 minecraft:redstone_block
setblock 3245 134 -1874 minecraft:repeating_command_block[facing=north] replace
data merge block 3245 134 -1874 {Command:"execute if entity @a[scores={temp_calc=3..}] run scoreboard players remove @a[scores={temp_calc=3..},x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] temp_calc 3",enabled:0b,Condition:0b}
setblock 3245 134 -1875 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 3245 134 -1875 {Command:"scoreboard players add @a[scores={temp_calc=0..},x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] temp_chest 1",enabled:1b,Condition:1b}
setblock 3245 134 -1876 minecraft:chain_command_block[facing=north,conditional=true] replace
data merge block 3245 134 -1876 {Command:"scoreboard players add @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] gold_chest 1",enabled:1b,Condition:1b}
forceload remove 3245 -1873 3245 -1873








