#清图
scoreboard players set #system instance2_weak 0
execute as @e[x=1052,y=3,z=864,dx=82,dy=55,dz=64,type=!player,type=!armor_stand] run function pld:system/tp_and_kill_self
execute as @e[type=armor_stand,tag=instance2] run kill @s
#被击败喊话
tellraw @a[x=1052,y=3,z=864,dx=82,dy=55,dz=64] {"translate": "pl.info.instance2.end"}
scoreboard players set @a[x=1052,y=3,z=864,dx=82,dy=55,dz=64] gold_chest 1
scoreboard players add @a[x=1052,y=3,z=864,dx=82,dy=55,dz=64] instance2_clear 1
execute as @a[x=1052,y=3,z=864,dx=82,dy=55,dz=64] store result score @s temp_calc run scoreboard players get @s instance2_clear
tellraw @a[x=1052,y=3,z=864,dx=82,dy=55,dz=64] [{"text":" 副本结束！你当前已通关本副本：","color":"gray"},{"score":{"name":"@a[x=1052,y=3,z=864,dx=82,dy=55,dz=64]","objective":"instance2_clear"},"bold":true,"color":"aqua"},{"text":"次","color":"gray"}]

schedule function pld:instances/instance2/tpout 5s