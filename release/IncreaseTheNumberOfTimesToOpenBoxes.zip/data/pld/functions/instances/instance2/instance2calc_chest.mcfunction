# 循环减5，计算总开箱次数
while score @s temp_calc matches 5.. run {
    scoreboard players remove @s temp_calc 5
    scoreboard players add @s temp_chest 1
}