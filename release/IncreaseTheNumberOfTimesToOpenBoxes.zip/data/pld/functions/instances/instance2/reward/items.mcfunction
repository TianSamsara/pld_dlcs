loot give @s loot pld:items/instance2_collection
loot give @s loot pld:items/instance2_collection
give @s minecraft:iron_nugget{display:{Lore:['{"translate":"pl.lore.rare5"}','{"translate":"pl.item.lore.acore5a"}','{"translate":"pl.item.lore.acore5b"}'],Name:'{"translate":"pl.item.name.acore5"}'},id:"panling:armor_core_5",HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]}
give @s minecraft:blaze_rod{id:"panling:fire",refined_element:3,display:{Name:'{"translate":"pl.item.name.fire"}'}} 20
