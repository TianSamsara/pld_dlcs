scoreboard players set @s copper_chest 10
tp @s 2731 72 -834 0 20

