scoreboard players set @s silver_chest 10
tp @s 2678 72 -885 0 20