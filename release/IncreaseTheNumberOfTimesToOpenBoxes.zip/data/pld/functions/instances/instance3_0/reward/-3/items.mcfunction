give @s minecraft:iron_nugget{display:{Lore:['{"translate":"pl.lore.rare4"}','{"translate":"pl.item.lore.acore4a"}','{"translate":"pl.item.lore.acore4b"}'],Name:'{"translate":"pl.item.name.acore4"}'},id:"panling:armor_core_4",HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 2
give @s minecraft:poisonous_potato{display:{Lore:['{"translate":"pl.item.lore.yy"}'],Name:'{"translate":"pl.item.name.yy2"}'},id:"panling:yy2"} 2
give @s minecraft:quartz{display:{Lore:['{"translate":"pl.lore.rare4"}','{"translate":"pl.item.lore.wcore4a"}','{"translate":"pl.item.lore.wcoreb"}'],Name:'{"translate":"pl.item.name.wcore4"}'},id:"panling:weapon_core_4",HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]}
give @s minecraft:magma_cream{id:"panling:earth",refined_element:3,display:{Name:'{"translate":"pl.item.name.earth"}'}} 10
give @s minecraft:emerald{id:"panling:metal",refined_element:3,display:{Name:'{"translate":"pl.item.name.metal"}'}} 10
give @s minecraft:bone{id:"panling:wood",refined_element:3,display:{Name:'{"translate":"pl.item.name.wood"}'}} 10
give @s minecraft:string{id:"panling:water",refined_element:3,display:{Name:'{"translate":"pl.item.name.water"}'}} 10
give @s minecraft:blaze_rod{id:"panling:fire",refined_element:3,display:{Name:'{"translate":"pl.item.name.fire"}'}} 10

