scoreboard players set @a[x=2834,y=31,z=-849,distance=..21] gold_chest 1
scoreboard players add @a[x=2834,y=31,z=-849,distance=..21] instance3_1_clear 1
execute as @a[x=2834,y=31,z=-849,distance=..21] store result score @s temp_calc run scoreboard players get @s instance3_1_clear
tellraw @a[x=2834,y=31,z=-849,distance=..21] [{"text":" 副本结束！你当前已通关本副本：","color":"gray"},{"score":{"name":"@a[x=2834,y=31,z=-849,distance=..21]","objective":"instance3_1_clear"},"bold":true,"color":"aqua"},{"text":"次","color":"gray"}]

tp @s 2714 27 -887 0 10

