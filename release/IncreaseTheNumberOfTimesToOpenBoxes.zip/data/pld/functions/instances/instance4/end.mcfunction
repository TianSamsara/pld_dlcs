#结束
scoreboard players set @a[x=912,y=57,z=1214,dx=62,dy=52,dz=70] gold_chest 1
scoreboard players add @a[x=912,y=57,z=1214,dx=62,dy=52,dz=70] instance4_clear 1
execute as @a[x=912,y=57,z=1180,dx=62,dy=52,dz=100] store result score @s temp_calc run scoreboard players get @s instance4_clear
tellraw @a[x=912,y=57,z=1214,dx=62,dy=52,dz=70] [{"text":" 副本结束！你当前已通关本副本：","color":"gray"},{"score":{"name":"@a[x=912,y=57,z=1214,dx=62,dy=52,dz=70]","objective":"instance4_clear"},"bold":true,"color":"aqua"},{"text":"次","color":"gray"}]
scoreboard players set @a[x=912,y=57,z=1214,dx=62,dy=52,dz=70] feather_mainland 1
tellraw @a[x=912,y=57,z=1214,dx=62,dy=52,dz=70] {"translate": "pl.info.instance4.end"}
kill @e[type=armor_stand,tag=instance4]
fill 973 65 1283 913 71 1215 air replace water
fill 973 64 1283 913 60 1215 air replace water
tp @a[x=912,y=57,z=1214,dx=62,dy=52,dz=70] 952 72 1185 90 ~