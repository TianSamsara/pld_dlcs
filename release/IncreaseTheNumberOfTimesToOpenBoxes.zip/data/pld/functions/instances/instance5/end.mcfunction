tellraw @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] {"translate": "pl.info.instance5.end1"}
tellraw @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] {"translate": "pl.info.instance5.end2"}
tellraw @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] {"translate": "pl.info.instance5.end3"}
advancement grant @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303,scores={race=0},advancements={pld:mission/shen/main/main11=true}] only pld:mission/shen/main/finished
advancement grant @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303,scores={race=1},advancements={pld:mission/yao/main/main14=true}] only pld:mission/yao/main/finished
advancement grant @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303,scores={race=2},advancements={pld:mission/xian/main/main12=true}] only pld:mission/xian/main/finished
advancement grant @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303,scores={race=3},advancements={pld:mission/zhan/main/main13=true}] only pld:mission/zhan/main/finished
advancement grant @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303,scores={race=4},advancements={pld:mission/ren/main/main12=true}] only pld:mission/ren/main/finished
scoreboard players set @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] gold_chest 1
scoreboard players add @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] instance5_clear 1
execute as @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] store result score @s temp_calc run scoreboard players get @s instance5_clear
tellraw @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] [{"text":" 副本结束！你当前已通关本副本：","color":"gray"},{"score":{"name":"@a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303]","objective":"instance5_clear"},"bold":true,"color":"aqua"},{"text":"次","color":"gray"}]
spawnpoint @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] 3245 128 -1874
tp @a[x=2992,y=0,z=-2000,dx=271,dy=255,dz=303] 3245 128 -1874 270 ~

