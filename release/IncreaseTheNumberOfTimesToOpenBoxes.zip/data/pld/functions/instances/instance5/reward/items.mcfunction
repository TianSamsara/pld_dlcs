loot give @s loot pld:items/instance5_collection
loot give @s loot pld:items/instance5_collection
give @s minecraft:iron_nugget{display:{Lore:['{"translate":"pl.lore.rare5"}','{"translate":"pl.item.lore.acore5a"}','{"translate":"pl.item.lore.acore5b"}'],Name:'{"translate":"pl.item.name.acore5"}'},id:"panling:armor_core_5",HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]}
give @s minecraft:emerald{id:"panling:metal",refined_element:3,display:{Name:'{"translate":"pl.item.name.metal"}'}} 20
give @s minecraft:bone{id:"panling:wood",refined_element:3,display:{Name:'{"translate":"pl.item.name.wood"}'}} 20
give @s minecraft:string{id:"panling:water",refined_element:3,display:{Name:'{"translate":"pl.item.name.water"}'}} 20
give @s minecraft:blaze_rod{id:"panling:fire",refined_element:3,display:{Name:'{"translate":"pl.item.name.fire"}'}} 20
give @s minecraft:magma_cream{id:"panling:earth",refined_element:3,display:{Name:'{"translate":"pl.item.name.earth"}'}} 20
