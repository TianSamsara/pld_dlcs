scoreboard players set @s element_middle_number 0
execute store result score @s element_middle_number run clear @s magma_cream{id:"panling:earth"} 0
execute unless entity @s[scores={element_middle_number=1..}] run tellraw @s {"text":"您的背包中没有土元素","color":"red"}
scoreboard players set @s[scores={element_middle_number=..0}] element_middle_number 0
execute if entity @s[scores={element_middle_number=1..}] store result score @s element_middle_number run clear @s magma_cream{id:"panling:earth"}
execute if entity @s[scores={element_middle_number=1..}] run tellraw @s {"text":"已存储背包中全部土元素","color":"green"}
scoreboard players operation @s element_number_earth += @s element_middle_number
scoreboard players set @s element_middle_number 0