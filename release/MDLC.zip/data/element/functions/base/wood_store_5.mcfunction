scoreboard players set @s element_middle_number 0
execute store result score @s element_middle_number run clear @s bone{id:"panling:wood"} 0
execute unless entity @s[scores={element_middle_number=5..}] run tellraw @s {"text":"您背包中木元素不足5个","color":"red"}
scoreboard players set @s[scores={element_middle_number=..4}] element_middle_number 0
execute if entity @s[scores={element_middle_number=5..}] store result score @s element_middle_number run clear @s bone{id:"panling:wood"} 5
execute if entity @s[scores={element_middle_number=5..}] run tellraw @s {"text":"存储成功","color":"green"}
scoreboard players operation @s element_number_wood += @s element_middle_number
scoreboard players set @s element_middle_number 0