forceload add 184 67 186 69
setblock 186 46 69 minecraft:structure_block[mode=load]{author:"Akiyama_mikagami",ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"element:menubook",posX:-2,posY:-6,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:1b,showboundingbox:1b,sizeX:3,sizeY:6,sizeZ:3}
setblock 186 47 69 redstone_block
setblock 185 46 68 minecraft:dark_oak_slab[type=bottom]
setblock 186 46 69 air
setblock 186 47 69 air
forceload remove 184 67 186 69