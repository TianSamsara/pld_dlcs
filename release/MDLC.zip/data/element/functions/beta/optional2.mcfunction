forceload add 155 70
setblock 155 45 70 minecraft:structure_block[mode=load]{author:"Akiyama_mikagami",ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"element:optional2",posX:0,posY:-4,posZ:0,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:1b,sizeX:5,sizeY:12,sizeZ:10}
setblock 155 46 70 redstone_block destroy
setblock 155 45 70 air destroy
forceload remove 155 70