#预加载计分板 element_dlc_update
scoreboard objectives add element_dlc_installed dummy "便捷元素银行-已安装"
scoreboard objectives add element_dlc_optional1 dummy "便捷元素银行-附加功能1-无损转化"
scoreboard objectives add element_dlc_optional2 dummy "便捷元素银行-附加功能2-伤害测试人偶"
scoreboard objectives add element_dlc_optional3 dummy "便捷元素银行-附加功能3-掌上钱庄"

#加载触发器
scoreboard objectives add element_dlc_install_setting trigger "便捷元素银行-安装选项"

#游戏内设置版本号
scoreboard players operation #system element_dlc_date_ver1 = #element_dlc element_dlc_date_ver1
scoreboard players operation #system element_dlc_date_ver2 = #element_dlc element_dlc_date_ver2
scoreboard players operation #system element_dlc_date_ver3 = #element_dlc element_dlc_date_ver3

#信息
tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §a初始化已完成 §e作者：暁山水鏡"}