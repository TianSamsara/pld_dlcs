scoreboard players set #system element_dlc_installed 1
scoreboard players set #system element_dlc_version 2

scoreboard players reset @a element_dlc_install_setting

scoreboard objectives add element_number_metal dummy "金元素储存量"
scoreboard objectives add element_number_wood dummy "木元素储存量"
scoreboard objectives add element_number_water dummy "水元素储存量"
scoreboard objectives add element_number_fire dummy "火元素储存量"
scoreboard objectives add element_number_earth dummy "土元素储存量"
scoreboard objectives add element_middle_number dummy "计算中间用变量"
scoreboard objectives add element_menu_trigger1 trigger "元素银行-基础功能"

execute if score #system element_dlc_optional1 matches 1 run function element:install_optional1
execute if score #system element_dlc_optional2 matches 1 run function element:install_optional2
execute if score #system element_dlc_optional3 matches 1 run function element:install_optional3

function element:beta/base
execute if score #system element_dlc_optional2 matches 1 run function element:beta/optional2

schedule function element:installmsg 1s