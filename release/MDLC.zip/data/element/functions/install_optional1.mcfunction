scoreboard objectives add element_number_total dummy "通用元素储存量"
scoreboard objectives add element_menu_trigger2 trigger "元素银行-无损元素转换"
scoreboard objectives add 5 dummy
scoreboard players set #system 5 5