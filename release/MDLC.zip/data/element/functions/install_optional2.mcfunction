scoreboard objectives add element_sandbag_type dummy "沙包类型"
scoreboard players set #system element_sandbag_type 0
scoreboard objectives add element_sandbag dummy "沙包更新血量"
scoreboard objectives add element_sandbag_middle dummy "沙包血量中间量"
scoreboard objectives add element_sandbag1 dummy "沙包血量差"
scoreboard objectives add element_sandbag_say dummy "沙包血量显示-整数"
scoreboard objectives add element_sandbag_say_num00 dummy "沙包血量显示-两位小数"
scoreboard objectives add temp1 dummy
scoreboard objectives add 100 dummy
scoreboard players set #system 100 100
scoreboard objectives add 5 dummy
scoreboard players set #system 5 5