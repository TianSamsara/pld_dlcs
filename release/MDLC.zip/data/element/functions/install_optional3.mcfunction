scoreboard objectives add element_money dummy "元素银行-掌上钱庄存款"
scoreboard objectives add element_menu_trigger3 trigger "元素银行-掌上钱庄触发器"
scoreboard objectives add 10 dummy
scoreboard players set #system 10 10
scoreboard objectives add 100 dummy
scoreboard players set #system 100 100
scoreboard objectives add temp1 dummy