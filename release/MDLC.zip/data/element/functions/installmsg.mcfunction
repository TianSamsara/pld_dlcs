tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §a已完成安装 §e作者：暁山水鏡"}
execute if score #system element_dlc_optional1 matches 1 run tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §6附加功能 §2无损元素转换 §a已开启"}
execute if score #system element_dlc_optional2 matches 1 run tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §6附加功能 §e伤害测试人偶 §a已开启"}
execute if score #system element_dlc_optional3 matches 1 run tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §6附加功能 §6掌上皇城钱庄 §a已开启"}