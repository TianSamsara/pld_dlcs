#初始化
scoreboard objectives add element_dlc_version dummy "便捷元素银行-版本号"
scoreboard objectives add element_dlc_date_ver1 dummy "便捷元素银行-日期版本-年"
scoreboard objectives add element_dlc_date_ver2 dummy "便捷元素银行-日期版本-月"
scoreboard objectives add element_dlc_date_ver3 dummy "便捷元素银行-日期版本-日"
#兼容万通
scoreboard objectives add first_xsj_load dummy

#数据包内置版本信息
#element_dlc记载数据包版本 #system记载游戏内版本
scoreboard players set #element_dlc element_dlc_date_ver1 2024
scoreboard players set #element_dlc element_dlc_date_ver2 12
scoreboard players set #element_dlc element_dlc_date_ver3 1

#首次加载
execute unless score #system element_dlc_version matches 1.. run schedule function element:firstload 2s

#加载设置
schedule function element:settings 3s

#大版本更新
execute if score #system element_dlc_version matches 1 run schedule function element:update/msg 3s