clear @p minecraft:written_book{id:"dlc:element_menubook"}

#基础元素银行
function element:base/book

#无损元素转换
execute if score #system element_dlc_optional1 matches 1.. run function element:optional1/book

#掌上钱庄
execute if score #system element_dlc_optional3 matches 1.. run function element:optional3/book