tag @s add ifslot
#判断银行有无储量
execute unless entity @s[scores={element_number_total=64..}] run tag @s remove ifslot
execute unless entity @s[scores={element_number_total=64..}] run tellraw @s {"text":"您在元素银行存入的通用元素不足一组","color":"red"}
#判断背包有无空位
execute if entity @s[tag=ifslot] run give @s glass{id:"panling:placeholder_c",display:{Name:'{"text":" "}'}} 1
execute if entity @s[tag=ifslot] unless entity @s[nbt={Inventory:[{tag:{id:"panling:placeholder_c"}}]}] run tellraw @s {"text":"您的背包空间不足,请先整理背包","color":"red"}
execute if entity @s[tag=ifslot] unless entity @s[nbt={Inventory:[{tag:{id:"panling:placeholder_c"}}]}] run tag @s remove ifslot
#取出元素
execute if entity @s[tag=ifslot] run scoreboard players remove @s element_number_total 64
execute if entity @s[tag=ifslot] run clear @s glass{id:"panling:placeholder_c"}
#兼容万通
execute if entity @s[tag=ifslot] unless score #finish first_xsj_load matches 1 run give @s blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 64
execute if entity @s[tag=ifslot] if score #finish first_xsj_load matches 1 run give @s blaze_rod{id:"panling:fire",refined_element:3,display:{Name:'{"translate":"pl.item.name.fire"}'}} 64
execute if entity @s[tag=ifslot] run tellraw @s {"text":"已取出火元素一组","color":"green"}
kill @e[type=item,nbt={Item:{id:"minecraft:glass",tag:{id:"panling:placeholder_c"}}}]
tag @s remove ifslot