scoreboard players set @s element_middle_number 0
execute store result score @s element_middle_number run clear @s blaze_rod{id:"panling:refined_fire"} 0
execute unless entity @s[scores={element_middle_number=1..}] run tellraw @s {"text":"您的背包中没有精炼火元素","color":"red"}
scoreboard players set @s[scores={element_middle_number=..0}] element_middle_number 0
execute if entity @s[scores={element_middle_number=1..}] store result score @s element_middle_number run clear @s blaze_rod{id:"panling:refined_fire"}
execute if entity @s[scores={element_middle_number=1..}] run tellraw @s {"text":"已存储背包中全部精炼火元素","color":"green"}
scoreboard players operation @s element_middle_number *= #system 5
scoreboard players operation @s element_number_total += @s element_middle_number
scoreboard players set @s element_middle_number 0