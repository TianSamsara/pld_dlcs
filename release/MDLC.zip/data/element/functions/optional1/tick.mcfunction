scoreboard players enable @a[scores={feather_mainland=1}] element_menu_trigger2

execute as @a[scores={feather_mainland=1,element_menu_trigger2=1}] run function element:optional1/metal_get_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=2}] run function element:optional1/metal_get_64
execute as @a[scores={feather_mainland=1,element_menu_trigger2=3}] run function element:optional1/metal_store_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=4}] run function element:optional1/metal_store_all

execute as @a[scores={feather_mainland=1,element_menu_trigger2=5}] run function element:optional1/wood_get_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=6}] run function element:optional1/wood_get_64
execute as @a[scores={feather_mainland=1,element_menu_trigger2=7}] run function element:optional1/wood_store_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=8}] run function element:optional1/wood_store_all

execute as @a[scores={feather_mainland=1,element_menu_trigger2=9}] run function element:optional1/water_get_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=10}] run function element:optional1/water_get_64
execute as @a[scores={feather_mainland=1,element_menu_trigger2=11}] run function element:optional1/water_store_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=12}] run function element:optional1/water_store_all

execute as @a[scores={feather_mainland=1,element_menu_trigger2=13}] run function element:optional1/fire_get_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=14}] run function element:optional1/fire_get_64
execute as @a[scores={feather_mainland=1,element_menu_trigger2=15}] run function element:optional1/fire_store_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=16}] run function element:optional1/fire_store_all

execute as @a[scores={feather_mainland=1,element_menu_trigger2=17}] run function element:optional1/earth_get_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=18}] run function element:optional1/earth_get_64
execute as @a[scores={feather_mainland=1,element_menu_trigger2=19}] run function element:optional1/earth_store_5
execute as @a[scores={feather_mainland=1,element_menu_trigger2=20}] run function element:optional1/earth_store_all

execute as @a[scores={feather_mainland=1,element_menu_trigger2=21}] run function element:optional1/total_info

execute as @a[scores={feather_mainland=1,element_menu_trigger2=26}] run function element:optional1/metal_store_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=27}] run function element:optional1/metal_get_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=28}] run function element:optional1/metal_get_refined_10

execute as @a[scores={feather_mainland=1,element_menu_trigger2=29}] run function element:optional1/wood_store_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=30}] run function element:optional1/wood_get_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=31}] run function element:optional1/wood_get_refined_10

execute as @a[scores={feather_mainland=1,element_menu_trigger2=32}] run function element:optional1/water_store_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=33}] run function element:optional1/water_get_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=34}] run function element:optional1/water_get_refined_10

execute as @a[scores={feather_mainland=1,element_menu_trigger2=35}] run function element:optional1/fire_store_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=36}] run function element:optional1/fire_get_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=37}] run function element:optional1/fire_get_refined_10

execute as @a[scores={feather_mainland=1,element_menu_trigger2=38}] run function element:optional1/earth_store_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=39}] run function element:optional1/earth_get_refined
execute as @a[scores={feather_mainland=1,element_menu_trigger2=40}] run function element:optional1/earth_get_refined_10

scoreboard players reset @a[scores={element_menu_trigger2=1..}] element_menu_trigger2