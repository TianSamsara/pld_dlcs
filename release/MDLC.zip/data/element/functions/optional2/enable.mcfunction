tellraw @a {"text":"§7===================="}
tellraw @a {"text":"§6[额外功能] §2伤害测试人偶 §c§l[点击关闭]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 5"}}
tellraw @a {"text":"§7   确认安装设置后 §a§l[==点我安装数据包==]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 1"}}
scoreboard players set #system element_dlc_optional2 1