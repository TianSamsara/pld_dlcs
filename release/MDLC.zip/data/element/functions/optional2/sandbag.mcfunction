kill @e[tag=sandbag]

execute if score #system element_sandbag_type matches 0 run function element:optional2/summon1
execute if score #system element_sandbag_type matches 1 run function element:optional2/summon2
execute if score #system element_sandbag_type matches 2 run function element:optional2/summon3

scoreboard players set #sandbag element_sandbag_middle 102400