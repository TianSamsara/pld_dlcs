#读取
execute as @e[tag=sandbag,limit=1,sort=nearest] store result score #sandbag element_sandbag run data get entity @s Health 100.0
execute unless entity @e[tag=sandbag,limit=1,sort=nearest] run scoreboard players set #sandbag element_sandbag 0

#比较
execute if score #sandbag element_sandbag < #sandbag element_sandbag_middle run scoreboard players operation #sandbag element_sandbag1 = #sandbag element_sandbag_middle
execute if score #sandbag element_sandbag < #sandbag element_sandbag_middle run scoreboard players operation #sandbag element_sandbag1 -= #sandbag element_sandbag
execute if score #sandbag element_sandbag > #sandbag element_sandbag_middle run scoreboard players operation #sandbag element_sandbag1 = #sandbag element_sandbag
execute if score #sandbag element_sandbag > #sandbag element_sandbag_middle run scoreboard players operation #sandbag element_sandbag1 -= #sandbag element_sandbag_middle 

#受伤则抗性效果倍乘
execute if score #sandbag element_sandbag < #sandbag element_sandbag_middle run scoreboard players operation #sandbag element_sandbag1 *= #system 5

#计算
execute unless score #sandbag element_sandbag = #sandbag element_sandbag_middle run scoreboard players operation #sandbag temp1 = #sandbag element_sandbag1
execute unless score #sandbag element_sandbag = #sandbag element_sandbag_middle run scoreboard players operation #sandbag temp2 = #sandbag element_sandbag1
execute unless score #sandbag element_sandbag = #sandbag element_sandbag_middle run scoreboard players operation #sandbag temp1 /= #system 100
execute unless score #sandbag element_sandbag = #sandbag element_sandbag_middle run scoreboard players operation #sandbag element_sandbag_say = #sandbag temp1
execute unless score #sandbag element_sandbag = #sandbag element_sandbag_middle run scoreboard players operation #sandbag temp1 *= #system 100
execute unless score #sandbag element_sandbag = #sandbag element_sandbag_middle run scoreboard players operation #sandbag temp2 -= #sandbag temp1
execute unless score #sandbag element_sandbag = #sandbag element_sandbag_middle run scoreboard players operation #sandbag element_sandbag_say_num00 = #sandbag temp2

#输出
execute if score #sandbag element_sandbag < #sandbag element_sandbag_middle run tellraw @a[distance=0..6] [{"text":"测试人偶本次受到的伤害为：","color":"yellow"},{"score":{"name":"#sandbag","objective":"element_sandbag_say"},"color":"red","bold":true},{"text":".","color":"yellow"},{"score":{"name":"#sandbag","objective":"element_sandbag_say_num00"},"color":"red","bold":true},{"text":" 点","color":"yellow"}]
execute if score #sandbag element_sandbag > #sandbag element_sandbag_middle run tellraw @a[distance=0..6] [{"text":"测试人偶本次回复的生命为：","color":"yellow"},{"score":{"name":"#sandbag","objective":"element_sandbag_say"},"color":"green","bold":true},{"text":".","color":"yellow"},{"score":{"name":"#sandbag","objective":"element_sandbag_say_num00"},"color":"green","bold":true},{"text":" 点","color":"yellow"}]

#结束
execute unless score #sandbag element_sandbag = #sandbag element_sandbag_middle run scoreboard players operation #sandbag element_sandbag_middle = #sandbag element_sandbag