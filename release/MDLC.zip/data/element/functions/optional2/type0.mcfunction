kill @e[tag=sandbag]
scoreboard players set #system element_sandbag_type 0
tellraw @a[distance=0..6] [{"text":"测试人偶类型已切换为：","color":"green"},{"text":"普通","color":"aqua"}]