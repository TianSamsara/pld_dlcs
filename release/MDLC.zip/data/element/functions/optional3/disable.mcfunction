tellraw @a {"text":"§7===================="}
tellraw @a {"text":"§6[额外功能] §8掌上皇城钱庄 §a§l[点击开启]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 6"}}
tellraw @a {"text":"§7   确认安装设置后 §a§l[==点我安装数据包==]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 1"}}
scoreboard players reset #system element_dlc_optional3