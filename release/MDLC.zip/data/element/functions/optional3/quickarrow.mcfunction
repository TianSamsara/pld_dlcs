scoreboard players set @s temp4 0
scoreboard players set @s element_middle_number 0
execute unless score @s job matches 1 run scoreboard players set @s temp4 1
execute if score @s job matches 1 if score @s arrowinpack matches 640.. run scoreboard players set @s temp4 2
execute unless score @s temp4 matches 1..2 store result score @s temp2 run scoreboard players get @s arrowinpack
execute unless score @s temp4 matches 1..2 run tag @s add ArrowJudge
scoreboard players set @s[tag=ArrowJudge] temp1 640
scoreboard players set @s[tag=ArrowJudge] temp3 16
scoreboard players operation @s[tag=ArrowJudge] temp1 -= @s temp2
scoreboard players operation @s[tag=ArrowJudge] element_middle_number = @s temp1
scoreboard players operation @s[tag=ArrowJudge] temp1 /= @s temp3
scoreboard players operation @s[tag=ArrowJudge] temp2 = @s temp1
scoreboard players operation @s[tag=ArrowJudge] temp2 *= @s temp3
execute as @s[tag=ArrowJudge] unless score @s element_middle_number = @s temp2 run scoreboard players add @s temp1 1
scoreboard players operation @s[tag=ArrowJudge] element_middle_number = @s temp1
execute as @s[tag=ArrowJudge] if score @s element_money < @s element_middle_number run scoreboard players set @s temp4 3
execute as @s[tag=ArrowJudge] if score @s element_money < @s element_middle_number run tag @s remove ArrowJudge
execute as @s[tag=ArrowJudge] run scoreboard players operation @s element_money -= @s element_middle_number
execute as @s[tag=ArrowJudge] run scoreboard players set @s arrowinpack 640
tellraw @s[scores={temp4=1}] {"text":"该功能仅对弓箭手开放","color":"red"}
tellraw @s[scores={temp4=2}] {"text":"您的箭袋已满","color":"red"}
tellraw @s[scores={temp4=3}] {"text":"您的钱庄存款余额不足","color":"red"}
tellraw @s[tag=ArrowJudge] {"text":"您的箭袋已补满","color":"green"}
tag @s remove ArrowJudge