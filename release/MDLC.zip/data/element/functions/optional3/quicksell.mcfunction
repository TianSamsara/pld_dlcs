#归零
scoreboard players set @s element_middle_number 0

#蜘蛛眼
execute store result score @s temp1 run clear @s spider_eye{id:"panling:spider_eye"} 0
scoreboard players operation @s temp1 *= #system 2
scoreboard players operation @s element_middle_number += @s temp1

#兔子皮
execute store result score @s temp1 run clear @s rabbit_hide{id:"panling:rabbit_hide"} 0
scoreboard players operation @s temp1 *= #system 2
scoreboard players operation @s element_middle_number += @s temp1

#皮革
execute store result score @s temp1 run clear @s leather{id:"panling:leather"} 0
scoreboard players operation @s temp1 *= #system 2
scoreboard players operation @s temp1 *= #system 2
scoreboard players operation @s element_middle_number += @s temp1

#煤炭
execute store result score @s temp1 run clear @s coal{id:"panling:coal"} 0
scoreboard players operation @s temp1 *= #system 2
scoreboard players operation @s temp1 *= #system 2
scoreboard players operation @s element_middle_number += @s temp1

#何首乌
execute store result score @s temp1 run clear @s rabbit_foot{id:"panling:hsw"} 0
scoreboard players set @s temp2 20
scoreboard players operation @s temp1 *= @s temp2
scoreboard players operation @s element_middle_number += @s temp1

#箭矢
execute if score @s job matches 1 run scoreboard players set @s temp3 0
execute unless score @s job matches 1 store result score @s temp3 run clear @s arrow 0
execute if score @s temp3 matches 32..63 run clear @s arrow 32
execute if score @s temp3 matches 64..95 run clear @s arrow 64
execute if score @s temp3 matches 96..127 run clear @s arrow 96
execute if score @s temp3 matches 128.. run clear @s arrow 128
execute if score @s temp3 matches 32..63 run scoreboard players set @s temp2 1
execute if score @s temp3 matches 64..95 run scoreboard players set @s temp2 2
execute if score @s temp3 matches 95..127 run scoreboard players set @s temp2 3
execute if score @s temp3 matches 128.. run scoreboard players set @s temp2 4
execute if score @s temp3 matches 32.. run scoreboard players operation @s temp1 = @s temp2
execute if score @s temp3 matches 32.. run scoreboard players operation @s element_middle_number += @s temp1

#结算
scoreboard players operation @s element_money += @s element_middle_number
clear @s spider_eye{id:"panling:spider_eye"}
clear @s rabbit_hide{id:"panling:rabbit_hide"}
clear @s leather{id:"panling:leather"}
clear @s coal{id:"panling:coal"}
clear @s rabbit_foot{id:"panling:hsw"}

#提示
execute if score @s element_middle_number matches 0 run tellraw @s {"text":"您没有可快速出售的杂物","color":"red"}
execute if score @s element_middle_number matches 1.. run tellraw @s [{"text":"已快速售出全部杂物！价值共计 ","color":"green"},{"score":{"name":"@s","objective":"element_middle_number"},"color":"aqua","bold":true},{"text":" 铜钱","color":"green"}]
