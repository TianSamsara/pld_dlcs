tag @s add ifslot
#判断银行有无储量
execute unless entity @s[scores={element_money=5..}] run tag @s remove ifslot
execute unless entity @s[scores={element_money=5..}] run tellraw @s {"text":"您在掌上钱庄的存款不足","color":"red"}
#判断背包有无空位
execute if entity @s[tag=ifslot] run give @s glass{id:"panling:placeholder_c",display:{Name:'{"text":" "}'}} 1
execute if entity @s[tag=ifslot] unless entity @s[nbt={Inventory:[{tag:{id:"panling:placeholder_c"}}]}] run tellraw @s {"text":"你的背包空间不足,请先清理背包","color":"red"}
execute if entity @s[tag=ifslot] unless entity @s[nbt={Inventory:[{tag:{id:"panling:placeholder_c"}}]}] run tag @s remove ifslot
#取出铜钱
execute if entity @s[tag=ifslot] run scoreboard players remove @s element_money 5
execute if entity @s[tag=ifslot] run clear @s glass{id:"panling:placeholder_c"}
execute if entity @s[tag=ifslot] run give @s gold_nugget{id:"panling:copper_cash",display:{Name:'{"translate":"pl.item.name.copper"}'}} 5
execute if entity @s[tag=ifslot] run tellraw @s {"text":"已取出铜钱5枚","color":"green"}
kill @e[type=item,nbt={Item:{id:"minecraft:glass",tag:{id:"panling:placeholder_c"}}}]
tag @s remove ifslot