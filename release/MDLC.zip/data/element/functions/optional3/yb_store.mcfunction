scoreboard players set @s element_middle_number 0
execute store result score @s element_middle_number run clear @s gold_ingot{id:"panling:gold_ingot"} 0
execute unless entity @s[scores={element_middle_number=1..}] run tellraw @s {"text":"您的身上没有元宝","color":"red"}
scoreboard players set @s[scores={element_middle_number=..0}] element_middle_number 0
execute if entity @s[scores={element_middle_number=1..}] store result score @s element_middle_number run clear @s gold_ingot{id:"panling:gold_ingot"}
execute if entity @s[scores={element_middle_number=1..}] run tellraw @s {"text":"已为您存储所有元宝","color":"green"}
scoreboard players operation @s element_middle_number *= #system 10
scoreboard players operation @s element_money += @s element_middle_number
scoreboard players set @s element_middle_number 0