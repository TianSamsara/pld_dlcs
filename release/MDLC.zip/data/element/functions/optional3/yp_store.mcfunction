scoreboard players set @s element_middle_number 0
execute store result score @s element_middle_number run clear @s iron_ingot{id:"panling:silver_ticket"} 0
execute unless entity @s[scores={element_middle_number=1..}] run tellraw @s {"text":"您的身上没有银票","color":"red"}
scoreboard players set @s[scores={element_middle_number=..0}] element_middle_number 0
execute if entity @s[scores={element_middle_number=1..}] store result score @s element_middle_number run clear @s iron_ingot{id:"panling:silver_ticket"}
execute if entity @s[scores={element_middle_number=1..}] run tellraw @s {"text":"已为您存储所有银票","color":"green"}
scoreboard players operation @s element_middle_number *= #system 100
scoreboard players operation @s element_money += @s element_middle_number
scoreboard players set @s element_middle_number 0