#转生清除大陆标记
scoreboard players set @s feather_mainland 0

#清除计分板
execute if score @s element_number_total matches 1.. run scoreboard players set @s element_number_total 0
scoreboard players set @s element_number_metal 0
scoreboard players set @s element_number_wood 0
scoreboard players set @s element_number_water 0
scoreboard players set @s element_number_fire 0
scoreboard players set @s element_number_earth 0
scoreboard players set @s element_money 0