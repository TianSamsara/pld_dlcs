#当前版本信息
execute if score #system element_dlc_installed matches 1.. run tellraw @a [{"text":"§c[MDLC] §b便捷元素银行 §7当前安装版本："},{"score":{"name":"#system","objective":"element_dlc_date_ver1","bold":true},"color":"gold"},{"text":"§6-"},{"score":{"name":"#system","objective":"element_dlc_date_ver2","bold":true},"color":"gold"},{"text":"§6-"},{"score":{"name":"#system","objective":"element_dlc_date_ver3","bold":true},"color":"gold"}]

#小版本更新
execute if score #system element_dlc_version matches 2 unless score #system element_dlc_date_ver2 = #element_dlc element_dlc_date_ver2 run function element:update/small_update_ver2/main

#初次加载设置
execute unless score #system element_dlc_installed matches 1.. run tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §7请选择安装设置："}
execute unless score #system element_dlc_installed matches 1.. run tellraw @a {"text":"§6[额外功能] §8无损元素转化 §a§l[点击开启]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 2"}}
execute unless score #system element_dlc_installed matches 1.. run tellraw @a {"text":"§6[额外功能] §8伤害测试人偶 §a§l[点击开启]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 4"}}
execute unless score #system element_dlc_installed matches 1.. run tellraw @a {"text":"§6[额外功能] §8掌上皇城钱庄 §a§l[点击开启]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 6"}}
execute unless score #system element_dlc_installed matches 1.. run tellraw @a {"text":"§7   确认安装设置后 §a§l[==点我安装数据包==]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 1"}}