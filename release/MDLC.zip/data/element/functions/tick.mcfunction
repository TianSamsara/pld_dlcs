##配置部分

#加载触发器
execute unless score #system element_dlc_installed matches 1.. run function element:tick_pre

#更新
execute if score #system element_dlc_update matches 1.. run function element:update/tick

##功能区

#基础功能
function element:base/tick

#附加功能 无损转化
execute if score #system element_dlc_optional1 matches 1.. run function element:optional1/tick

#附加功能 掌上钱庄
execute if score #system element_dlc_optional3 matches 1.. run function element:optional3/tick