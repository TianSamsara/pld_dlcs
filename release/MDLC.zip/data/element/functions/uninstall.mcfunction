#基本计分板
scoreboard objectives remove element_dlc_install_setting
scoreboard objectives remove element_dlc_installed
scoreboard objectives remove element_dlc_version
scoreboard objectives remove element_dlc_date_ver1
scoreboard objectives remove element_dlc_date_ver2
scoreboard objectives remove element_dlc_date_ver3
scoreboard objectives remove element_dlc_optional1
scoreboard objectives remove element_dlc_optional2
scoreboard objectives remove element_dlc_optional3

#兼容万通
execute unless score #finish first_xsj_load matches 1 run scoreboard objectives remove first_xsj_load

#基础功能
scoreboard objectives remove element_number_metal
scoreboard objectives remove element_number_wood
scoreboard objectives remove element_number_water
scoreboard objectives remove element_number_fire
scoreboard objectives remove element_number_earth
scoreboard objectives remove element_middle_number
scoreboard objectives remove element_menu_trigger1

#卸载建筑
forceload add 184 67 186 69
setblock 185 46 68 air destroy
setblock 186 46 69 minecraft:structure_block[mode=load]{author:"Akiyama_mikagami",ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"element:uninstall",posX:-2,posY:-6,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:1b,showboundingbox:1b,sizeX:3,sizeY:6,sizeZ:3}
setblock 186 47 69 redstone_block
setblock 186 46 69 air
setblock 186 47 69 air
forceload remove 184 67 186 69

#卸载伤害测试
forceload add 155 70
setblock 155 45 70 minecraft:structure_block[mode=load]{author:"Akiyama_mikagami",ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"element:uninstall_optional2",posX:0,posY:-4,posZ:0,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:1b,sizeX:5,sizeY:12,sizeZ:10}
setblock 155 46 70 redstone_block destroy
setblock 155 45 70 air destroy
kill @e[tag=sandbag]
forceload remove 155 70

#不消耗
scoreboard objectives remove element_number_total
scoreboard objectives remove element_menu_trigger2

#人偶
scoreboard objectives remove element_sandbag_type
scoreboard objectives remove element_sandbag
scoreboard objectives remove element_sandbag_middle
scoreboard objectives remove element_sandbag1
scoreboard objectives remove element_sandbag_say
scoreboard objectives remove element_sandbag_say_num00

#钱庄
scoreboard objectives remove element_money
scoreboard objectives remove element_menu_trigger3

#信息
tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §4卸载已准备完毕 删除数据包即可完成卸载"}