scoreboard objectives remove element_dlc_update
execute if score #system element_dlc_optional1 matches 1 run function element:install_optional1
execute if score #system element_dlc_optional2 matches 1 run function element:install_optional2
execute if score #system element_dlc_optional3 matches 1 run function element:install_optional3
function element:beta/base
execute if score #system element_dlc_optional2 matches 1 run function element:beta/optional2
tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §a已完成更新"}

execute if score #system element_dlc_optional1 matches 1 run tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §6附加功能 §2无损元素转换 §a已开启"}
execute if score #system element_dlc_optional2 matches 1 run tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §6附加功能 §e伤害测试人偶 §a已开启"}
execute if score #system element_dlc_optional3 matches 1 run tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §6附加功能 §6掌上皇城钱庄 §a已开启"}

#游戏内设置版本号
scoreboard players set #system element_dlc_version 2
scoreboard players operation #system element_dlc_date_ver1 = #element_dlc element_dlc_date_ver1
scoreboard players operation #system element_dlc_date_ver2 = #element_dlc element_dlc_date_ver2
scoreboard players operation #system element_dlc_date_ver3 = #element_dlc element_dlc_date_ver3