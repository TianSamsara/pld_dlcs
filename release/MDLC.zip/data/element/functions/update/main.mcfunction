#版本号更新
scoreboard players set #system element_dlc_version 2
scoreboard players set #system element_dlc_date_ver1 2024
scoreboard players set #system element_dlc_date_ver2 6
scoreboard players set #system element_dlc_date_ver3 7

#24-2-6更新
scoreboard objectives add 5 dummy
scoreboard players set #system 5 5
scoreboard objectives add 10 dummy
scoreboard players set #system 10 10
scoreboard objectives add 100 dummy
scoreboard players set #system 100 100

#24-6-7更新
scoreboard objectives add element_dlc_optional2 dummy "便捷元素银行-附加功能2-伤害测试人偶"
scoreboard objectives add element_dlc_optional3 dummy "便捷元素银行-附加功能3-掌中钱庄"

#重载附加功能
scoreboard players set #system element_dlc_optional1 0
scoreboard players set #system element_dlc_optional2 0
scoreboard players set #system element_dlc_optional3 0
tellraw @a {"text":"§c[MDLC] §b便捷元素银行 §7请选择更新设置："}
tellraw @a {"text":"§6[额外功能] §8无损元素转化 §a§l[点击开启]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 2"}}
tellraw @a {"text":"§6[额外功能] §8伤害测试人偶 §a§l[点击开启]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 4"}}
tellraw @a {"text":"§6[额外功能] §8掌上皇城钱庄 §a§l[点击开启]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 6"}}
tellraw @a {"text":"§7   确认安装设置后 §a§l[==点我更新数据包==]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_install_setting set 1"}}