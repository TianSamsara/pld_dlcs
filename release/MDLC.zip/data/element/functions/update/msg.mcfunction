scoreboard objectives add element_dlc_optional2 dummy "便捷元素银行-附加功能2-伤害测试人偶"
scoreboard objectives add element_dlc_optional3 dummy "便捷元素银行-附加功能3-掌上钱庄"
scoreboard objectives add element_dlc_update trigger "元素银行-局部变量-更新"
scoreboard players set #system element_dlc_update 1
scoreboard players enable @a element_dlc_update

tellraw @a [{"text":"§c[MDLC] §b便捷元素银行 §a新版本已初始化完成："},{"score":{"name":"#element_dlc","objective":"element_dlc_date_ver1","bold":true},"color":"gold"},{"text":"§6-"},{"score":{"name":"#element_dlc","objective":"element_dlc_date_ver2","bold":true},"color":"gold"},{"text":"§6-"},{"score":{"name":"#element_dlc","objective":"element_dlc_date_ver3","bold":true},"color":"gold"}]

tellraw @a {"text":"§7   确认更新版本后 §e§l[==点我更新数据包==]","clickEvent": {"action": "run_command","value": "/trigger element_dlc_update set 2"}}