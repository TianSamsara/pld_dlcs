#更新信息
tellraw @a [{"text":"§c[MDLC] §b便捷元素银行 §a检测到新版本数据包，自动更新版本："},{"score":{"name":"#element_dlc","objective":"element_dlc_date_ver1","bold":true},"color":"gold"},{"text":"§6-"},{"score":{"name":"#element_dlc","objective":"element_dlc_date_ver2","bold":true},"color":"gold"},{"text":"§6-"},{"score":{"name":"#element_dlc","objective":"element_dlc_date_ver3","bold":true},"color":"gold"}]

#更新版本号
scoreboard players operation #system element_dlc_date_ver1 = #element_dlc element_dlc_date_ver1
scoreboard players operation #system element_dlc_date_ver2 = #element_dlc element_dlc_date_ver2
scoreboard players operation #system element_dlc_date_ver3 = #element_dlc element_dlc_date_ver3

#更新内容

#24-07-26

#（无）