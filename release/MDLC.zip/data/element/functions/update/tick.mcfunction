scoreboard players enable @a element_dlc_install_setting
execute as @a[scores={element_dlc_install_setting=1}] run function element:update/done
execute as @a[scores={element_dlc_install_setting=2}] run function element:optional1/enable
execute as @a[scores={element_dlc_install_setting=3}] run function element:optional1/disable
execute as @a[scores={element_dlc_install_setting=4}] run function element:optional2/enable
execute as @a[scores={element_dlc_install_setting=5}] run function element:optional2/disable
execute as @a[scores={element_dlc_install_setting=6}] run function element:optional3/enable
execute as @a[scores={element_dlc_install_setting=7}] run function element:optional3/disable
scoreboard players reset @a[scores={element_dlc_install_setting=1..}] element_dlc_install_setting

scoreboard players enable @a element_dlc_update
execute as @a[scores={element_dlc_update=2..}] run function element:update/main
scoreboard players set @a[scores={element_dlc_update=2..}] element_dlc_update 1