# 开始穷举！！！

execute if score @s count matches 2048.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 2048
execute if score @s count matches 2048.. run scoreboard players remove @s count 2048

execute if score @s count matches 1024.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 1024
execute if score @s count matches 1024.. run scoreboard players remove @s count 1024 

execute if score @s count matches 512.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 512
execute if score @s count matches 512.. run scoreboard players remove @s count 512 

execute if score @s count matches 256.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 256
execute if score @s count matches 256.. run scoreboard players remove @s count 256 

execute if score @s count matches 128.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 128
execute if score @s count matches 128.. run scoreboard players remove @s count 128 

execute if score @s count matches 64.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 64
execute if score @s count matches 64.. run scoreboard players remove @s count 64 

execute if score @s count matches 32.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 32
execute if score @s count matches 32.. run scoreboard players remove @s count 32 

execute if score @s count matches 16.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 16
execute if score @s count matches 16.. run scoreboard players remove @s count 16 

execute if score @s count matches 8.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 8
execute if score @s count matches 8.. run scoreboard players remove @s count 8 

execute if score @s count matches 4.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 4
execute if score @s count matches 4.. run scoreboard players remove @s count 4 

execute if score @s count matches 2.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 2
execute if score @s count matches 2.. run scoreboard players remove @s count 2 

execute if score @s count matches 1.. run clear @s minecraft:melon_seeds{id:"panling:again_refined_wood"} 1
execute if score @s count matches 1.. run scoreboard players remove @s count 1 

# sb 1.20.1
