#初始化记分板
scoreboard players set @s element.subject.back 36
scoreboard players set @s element.subject.have 0
#获得占位数量
execute store result score @s element.subject.have run data get entity @s Inventory
#扣除装备栏位数值
scoreboard players remove @s[nbt={Inventory:[{Slot:100b}]}] element.subject.have 1
scoreboard players remove @s[nbt={Inventory:[{Slot:101b}]}] element.subject.have 1
scoreboard players remove @s[nbt={Inventory:[{Slot:102b}]}] element.subject.have 1
scoreboard players remove @s[nbt={Inventory:[{Slot:103b}]}] element.subject.have 1
scoreboard players remove @s[nbt={Inventory:[{Slot:-106b}]}] element.subject.have 1
#计算实际空位数
scoreboard players operation @s element.subject.back -= @s element.subject.have

