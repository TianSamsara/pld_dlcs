# 只算足够数量

# 背包空位组转数量
scoreboard players operation @s element.subject.back *= 64 int
# 如果没有足够空位
execute if score @s count > @s element.subject.back run scoreboard players operation @s count = @s element.subject.back

