# 开始穷举！！！

execute if score @s count matches 2048.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 2048
execute if score @s count matches 2048.. run scoreboard players remove @s count 2048 

execute if score @s count matches 1024.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 1024
execute if score @s count matches 1024.. run scoreboard players remove @s count 1024 

execute if score @s count matches 512.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 512
execute if score @s count matches 512.. run scoreboard players remove @s count 512 

execute if score @s count matches 256.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 256
execute if score @s count matches 256.. run scoreboard players remove @s count 256 

execute if score @s count matches 128.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 128
execute if score @s count matches 128.. run scoreboard players remove @s count 128 

execute if score @s count matches 64.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 64
execute if score @s count matches 64.. run scoreboard players remove @s count 64 

execute if score @s count matches 32.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 32
execute if score @s count matches 32.. run scoreboard players remove @s count 32 

execute if score @s count matches 16.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 16
execute if score @s count matches 16.. run scoreboard players remove @s count 16 

execute if score @s count matches 8.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 8
execute if score @s count matches 8.. run scoreboard players remove @s count 8 

execute if score @s count matches 4.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 4
execute if score @s count matches 4.. run scoreboard players remove @s count 4 

execute if score @s count matches 2.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 2
execute if score @s count matches 2.. run scoreboard players remove @s count 2 

execute if score @s count matches 1.. run give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 1
execute if score @s count matches 2.. run scoreboard players remove @s count 1 

# sb 1.20.1
