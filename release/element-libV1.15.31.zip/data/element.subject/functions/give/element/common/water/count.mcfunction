# 开始穷举！！！

execute if score @s count matches 2048.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 2048
execute if score @s count matches 2048.. run scoreboard players remove @s count 2048 

execute if score @s count matches 1024.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 1024
execute if score @s count matches 1024.. run scoreboard players remove @s count 1024 

execute if score @s count matches 512.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 512
execute if score @s count matches 512.. run scoreboard players remove @s count 512 

execute if score @s count matches 256.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 256
execute if score @s count matches 256.. run scoreboard players remove @s count 256 

execute if score @s count matches 128.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 128
execute if score @s count matches 128.. run scoreboard players remove @s count 128 

execute if score @s count matches 64.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 64
execute if score @s count matches 64.. run scoreboard players remove @s count 64 

execute if score @s count matches 32.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 32
execute if score @s count matches 32.. run scoreboard players remove @s count 32 

execute if score @s count matches 16.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 16
execute if score @s count matches 16.. run scoreboard players remove @s count 16 

execute if score @s count matches 8.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 8
execute if score @s count matches 8.. run scoreboard players remove @s count 8 

execute if score @s count matches 4.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 4
execute if score @s count matches 4.. run scoreboard players remove @s count 4 

execute if score @s count matches 2.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 2
execute if score @s count matches 2.. run scoreboard players remove @s count 2 

execute if score @s count matches 1.. run give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 1
execute if score @s count matches 1.. run scoreboard players remove @s count 1 

# sb 1.20.1
