# 开始穷举！！！

execute if score @s count matches 2048.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 2048
execute if score @s count matches 2048.. run scoreboard players remove @s count 2048

execute if score @s count matches 1024.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 1024
execute if score @s count matches 1024.. run scoreboard players remove @s count 1024 

execute if score @s count matches 512.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 512
execute if score @s count matches 512.. run scoreboard players remove @s count 512 

execute if score @s count matches 256.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 256
execute if score @s count matches 256.. run scoreboard players remove @s count 256 

execute if score @s count matches 128.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 128
execute if score @s count matches 128.. run scoreboard players remove @s count 128 

execute if score @s count matches 64.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 64
execute if score @s count matches 64.. run scoreboard players remove @s count 64 

execute if score @s count matches 32.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 32
execute if score @s count matches 32.. run scoreboard players remove @s count 32 

execute if score @s count matches 16.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 16
execute if score @s count matches 16.. run scoreboard players remove @s count 16 

execute if score @s count matches 8.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 8
execute if score @s count matches 8.. run scoreboard players remove @s count 8 

execute if score @s count matches 4.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 4
execute if score @s count matches 4.. run scoreboard players remove @s count 4 

execute if score @s count matches 2.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 2
execute if score @s count matches 2.. run scoreboard players remove @s count 2 

execute if score @s count matches 1.. run give @s magma_cream{id:"panling:refined_earth",element:4,refined_element:1,display:{Name:'{"translate":"pl.item.name.rearth"}',Lore:['{"translate":"pl.item.lore.refined"}']},HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]} 1
execute if score @s count matches 1.. run scoreboard players remove @s count 1 

# sb 1.20.1
