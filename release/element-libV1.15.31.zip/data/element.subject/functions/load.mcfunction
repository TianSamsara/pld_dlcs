




# 								秋夜凝秋霜


# 								霜花开漫天






scoreboard objectives add element.subject.front.relod.tag dummy ["元素学·前置dlc-初始化标记"]

# 初始化计分板

# 设置数据包版本号
scoreboard players set 数据包大版本号 element.subject.front.relod.tag 1
scoreboard players set 数据包中版本号 element.subject.front.relod.tag 15
scoreboard players set 数据包小版本号 element.subject.front.relod.tag 31

# 取消初始化完成标记
scoreboard players set 初始化 element.subject.front.relod.tag 0
# 检查版本号 自动提醒更新
execute if score 现大版本号 element.subject.front.relod.tag = 数据包大版本号 element.subject.front.relod.tag if score 现中版本号 element.subject.front.relod.tag = 数据包中版本号 element.subject.front.relod.tag if score 现小版本号 element.subject.front.relod.tag = 数据包小版本号 element.subject.front.relod.tag run scoreboard players set 初始化 element.subject.front.relod.tag 1

tellraw @a [{"text":"§c[MDLC] §b元素学·前置 §7当前激活安装版本：§6V"},{"score":{"name":"现大版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"},{"text":"."},{"score":{"name":"现中版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"},{"text":"."},{"score":{"name":"现小版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"}]
tellraw @a [{"text":"§c[MDLC] §b元素学·前置 §7当前内置安装版本：§6V"},{"score":{"name":"数据包大版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"},{"text":"."},{"score":{"name":"数据包中版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"},{"text":"."},{"score":{"name":"数据包小版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"}]


# 检查初始化 
execute unless score 初始化 element.subject.front.relod.tag matches 1.. run scoreboard objectives setdisplay sidebar element.subject.front.relod.tag
execute unless score 初始化 element.subject.front.relod.tag matches 1.. run schedule function element.subject:load/once 90t
