# 初始化分割

# 设置版本号
scoreboard players set 现大版本号 element.subject.front.relod.tag 1
scoreboard players set 现中版本号 element.subject.front.relod.tag 15
scoreboard players set 现小版本号 element.subject.front.relod.tag 31

# 计分板
function element.subject:load/scoreboard

# 初始化标记
scoreboard players set 初始化 element.subject.front.relod.tag 1

tellraw @a [{"text":"§c[MDLC] §b元素学·前置 §7当前自动更新版本：§6V"},{"score":{"name":"现大版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"},{"text":"."},{"score":{"name":"现中版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"},{"text":"."},{"score":{"name":"现小版本号","objective":"element.subject.front.relod.tag","bold":true},"color":"gold"}]



scoreboard objectives setdisplay sidebar