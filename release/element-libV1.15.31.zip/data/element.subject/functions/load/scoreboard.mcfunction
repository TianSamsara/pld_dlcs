


scoreboard objectives add element.subject.back dummy ["背包剩余空间"]
scoreboard objectives add element.subject.have dummy ["背包占有空间"]





scoreboard objectives add count dummy ["计数"]




# 秋霜`s dlc通用量
scoreboard objectives add number_middle dummy ["数字"]
scoreboard objectives add number_middle_1 dummy ["数字1"]
scoreboard objectives add number_middle_2 dummy ["数字2"]
scoreboard objectives add number_middle_3 dummy ["数字3"]
scoreboard objectives add number_middle_4 dummy ["数字4"]
scoreboard objectives add number_middle_5 dummy ["数字5"]

scoreboard objectives add dz dummy ["锻造"]



# 初始化数字
scoreboard players set 1 int 1
scoreboard players set 2 int 2
scoreboard players set 4 int 4
scoreboard players set 5 int 5
scoreboard players set 8 int 8
scoreboard players set 10 int 10
scoreboard players set 12 int 12
scoreboard players set 16 int 16
scoreboard players set 24 int 24
scoreboard players set 32 int 32
scoreboard players set 40 int 40
scoreboard players set 48 int 48
scoreboard players set 56 int 56
scoreboard players set 64 int 64
scoreboard players set 128 int 128
scoreboard players set 256 int 256
scoreboard players set 512 int 512
scoreboard players set 1024 int 1024
scoreboard players set 2048 int 2048
scoreboard players set 4096 int 4096
scoreboard players set 8192 int 8192
scoreboard players set 16384 int 16384
scoreboard players set 32768 int 32768

