# @s 目标玩家

# 延迟 1 刻，实现类似刻循环的效果
tag @s add betterd_inventory_changed
schedule function better_dream:advancements/inventory_changed_delayed 1