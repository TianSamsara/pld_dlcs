# @a[tag=betterd_inventory_changed] 目标玩家

execute as @a[tag=betterd_inventory_changed] run function better_dream:equipment_lock/equipment/armor/set_bonus/inventory_changed_delayed

# 进度事件执行完毕
advancement revoke @a only better_dream:common/inventory_changed
tag @a remove betterd_inventory_changed