# 水木五阶生命倍率增加
# 先删除原版，再重新添加修改版
attribute @s generic.max_health modifier remove 12-1-4-1-0
execute as @s[tag=wood_set_4b,scores={dragon=1}] run attribute @s generic.max_health modifier add 12-1-4-1-0 "木圣兽套属性-爽盘修改" 0.4 multiply_base
attribute @s generic.max_health modifier remove 12-2-4-1-0
execute as @s[tag=water_set_4b,scores={turtle=1}] run attribute @s generic.max_health modifier add 12-2-4-1-0 "水圣兽套属性-爽盘修改" 0.4 multiply_base