# 金二件套增幅率
scoreboard players set #system armor_set_bonus_0_2 16

# 火二件套增幅血量百分比限制
scoreboard players set #system armor_set_bonus_3_2_hp 60
# 火二件套增幅率
scoreboard players set #system armor_set_bonus_3_2_0 25
scoreboard players set #system armor_set_bonus_3_2_1 25
scoreboard players set #system armor_set_bonus_3_2_2 25

# 土四件套增幅率
scoreboard players set #system armor_set_bonus_4_4_1 35
scoreboard players set #system armor_set_bonus_4_4_2 35