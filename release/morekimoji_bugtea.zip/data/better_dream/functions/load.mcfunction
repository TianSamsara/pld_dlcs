function better_dream:system/zf/zfload
function better_dream:system/archer_damage/weapon_skill/load
function better_dream:equipment_lock/equipment/armor/set_bonus/load

# 重华晶冷却刷新优化
scoreboard objectives add better_using_tpstone minecraft.used:minecraft.warped_fungus_on_a_stick ["爽盘优化-重华晶使用标记"]
scoreboard objectives add better_tpstone_resetcool_timer dummy ["爽盘优化-重华晶刷新冷却等待确认"]

# 版本更新检测
scoreboard objectives add betterd_optimize dummy
scoreboard players set #version betterd_optimize 1