# 四阶
data modify entity @s Offers.Recipes[8].buyB.Count set value 4
data modify entity @s Offers.Recipes[9].buyB.Count set value 4
data modify entity @s Offers.Recipes[10].buyB.Count set value 4
data modify entity @s Offers.Recipes[11].buyB.Count set value 4
data modify entity @s Offers.Recipes[12].buyB.Count set value 4
# 五阶
data modify entity @s Offers.Recipes[13].buyB.Count set value 2
data modify entity @s Offers.Recipes[14].buyB.Count set value 2
data modify entity @s Offers.Recipes[15].buyB.Count set value 2
data modify entity @s Offers.Recipes[16].buyB.Count set value 2
data modify entity @s Offers.Recipes[17].buyB.Count set value 2