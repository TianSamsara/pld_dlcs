# 三阶炼丹炉数值增强
data modify entity @s Offers.Recipes[{sell:{tag:{id:"panling:furnace3"}}}].sell.tag.PLattributes.base.atk_pt set value 12
data modify entity @s Offers.Recipes[{sell:{tag:{id:"panling:furnace3"}}}].sell.tag.display.Lore[5] set value '[{"translate":"pl.attribute.element_power"},{"text":"12","color":"white","italic":false}]'