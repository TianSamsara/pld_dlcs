# 五阶元素
data modify entity @s Offers.Recipes[5].buyB.Count set value 1

# 五阶千炼
execute as @s[x=82,y=46,z=153,distance=..20] run function better_dream:npcs/middle/tong9/item