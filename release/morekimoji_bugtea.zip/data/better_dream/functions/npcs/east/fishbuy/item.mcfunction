# 这里暂不使用索引值，以免与万通及其集成的爽盘发生冲突
# 对应原版 NPC 索引值 4
data modify entity @s Offers.Recipes[{buy:{tag:{id:"panling:tropical_fish"},Count:1b},sell:{tag:{id:"panling:old_lock"}}}].buy.Count set value 2
# 对应原版 NPC 索引值 5、6
data modify entity @s Offers.Recipes[{buy:{tag:{id:"panling:tropical_fish"},Count:4b}}].buy.Count set value 2