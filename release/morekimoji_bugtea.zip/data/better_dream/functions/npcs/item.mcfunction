# 新手武器

	# 铁匠铺武器销售员
	# (除 pld:npcs/yao/yaotong2	2648 96 865)
	# pld:npcs/middle/tong2	86 46 140
	# pld:npcs/east/tong2	586 33 61
	# pld:npcs/south/tong2	-24 48 866
	# pld:npcs/qiansi/tong2	-717 102 510
	execute as @s[x=2648,y=96,z=865,distance=20..,nbt={CustomName:'{"translate":"pl.npc.name.tong2"}'}] run function better_dream:npcs/common/tong2/item

	# 资源中心工作人员	pld:npcs/shen/shentong1	3282 115 359
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.shentong1"}'}] run function better_dream:npcs/common/tong2/item

	# 仙器铺兑换员	pld:npcs/xian/xiantong1	3236 67 885
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.xiantong1"}'}] run function better_dream:npcs/common/tong2/item

	# 战备资源部部员	pld:npcs/zhan/zhantong1	3287 23 -242
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.zhantong1"}'}] run function better_dream:npcs/common/tong2/item

	# 铁匠铺兑换员
	# pld:npcs/yao/yaotong1	2649 96 863
	# pld:npcs/ren/rentong1	1737 160 92
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.tong1"}'}] run function better_dream:npcs/common/tong2/item

# 装备材料

	# 装备锻造师
	# pld:npcs/middle/tong9	1741 160 92
	# pld:npcs/ren/rentong3	82 46 153
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.tong9"}'}] run function better_dream:npcs/common/tong9/item

	# 资源中心装备管理员	pld:npcs/shen/shentong3	3290 115 359
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.shentong3"}'}] run function better_dream:npcs/common/tong9/item

	# 铁匠铺装备销售员	pld:npcs/yao/yaotong3	2646 96 865
	execute as @s[x=2646,y=96,z=865,distance=..20,nbt={CustomName:'{"translate":"pl.npc.name.tong3"}'}] run function better_dream:npcs/common/tong9/item

	# 仙器铺装备销售员	pld:npcs/xian/xiantong3	3236 67 877
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.xiantong3"}'}] run function better_dream:npcs/common/tong9/item

	# 战备资源部装备管理员	pld:npcs/zhan/zhantong3	3288 23 -264
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.zhantong3"}'}] run function better_dream:npcs/common/tong9/item

# 武器材料

	# 武器锻造师
	# pld:npcs/middle/tong10	81 46 151
	# pld:npcs/ren/rentong2		1739 160 92
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.tong10"}'}] run function better_dream:npcs/common/tong10/item

	# 资源中心武器管理员	pld:npcs/shen/shentong2	3290 115 360
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.shentong2"}'}] run function better_dream:npcs/common/tong10/item

	# 铁匠铺武器销售员	pld:npcs/yao/yaotong2	2648 96 865
	execute as @s[x=2648,y=96,z=865,distance=..20,nbt={CustomName:'{"translate":"pl.npc.name.tong2"}'}] run function better_dream:npcs/common/tong10/item

	# 仙器铺仙器销售员	pld:npcs/xian/xiantong2	3234 67 877
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.xiantong2"}'}] run function better_dream:npcs/common/tong10/item

	# 战备资源部武器管理员	pld:npcs/zhan/zhantong2	3284 23 -264
	execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.zhantong2"}'}] run function better_dream:npcs/common/tong10/item

# 南北杂货批发	pld:npcs/middle/tong11	101 46 185
execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.tong11"}'}] run function better_dream:npcs/middle/tong11/item

# 喜欢奇特水产的老人	pld:npcs/east/fishbuy	554 34 39
execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.fishbuy"}'}] run function better_dream:npcs/east/fishbuy/item
