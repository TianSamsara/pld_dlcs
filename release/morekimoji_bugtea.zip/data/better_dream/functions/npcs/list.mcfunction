# 古董收购员	pld:npcs/middle/tong14	84 47 112
execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.tong14"}'}] run function better_dream:npcs/middle/tong14/list

# 喜欢奇特水产的老人	pld:npcs/east/fishbuy	554 34 39
execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.fishbuy"}'}] run function better_dream:npcs/east/fishbuy/list

# 神匠-无名	pld:npcs/penglai/trader_legend_forge	-21 48 -921
execute as @s[nbt={CustomName:'{"translate":"pl.npc.name.trader_legend_forge"}'}] run function better_dream:npcs/penglai/trader_legend_forge/list