# 南北杂货批发
# 金钥匙降价
data modify entity @s Offers.Recipes[6].buy.Count set value 3