# 五阶千炼
data modify entity @s Offers.Recipes[6].buyB.Count set value 3
data modify entity @s Offers.Recipes[7].buyB.Count set value 3
data modify entity @s Offers.Recipes[8].buyB.Count set value 3
data modify entity @s Offers.Recipes[9].buyB.Count set value 3