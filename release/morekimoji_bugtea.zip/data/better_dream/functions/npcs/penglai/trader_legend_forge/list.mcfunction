# 盘铁和信物互换
data modify entity @s Offers.Recipes insert 1 from entity @s Offers.Recipes[0]
data modify entity @s Offers.Recipes[1].buy set from entity @s Offers.Recipes[0].sell
data modify entity @s Offers.Recipes[1].sell set from entity @s Offers.Recipes[0].buy