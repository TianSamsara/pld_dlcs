# crossbow5 单层追加倍率
scoreboard players set #system weapon_skill_crossbow5_multiplier 100