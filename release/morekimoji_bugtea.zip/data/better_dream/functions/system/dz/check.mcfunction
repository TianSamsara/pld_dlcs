# 检查已有物品槽位数量
execute store result score #temp temp run data get block ~ ~ ~ Items
# 新锻造的装备
execute if score #temp temp matches 1 if score @p dzsuccess matches 5 if data block ~ ~ ~ Items[{Slot:5b}] run function better_dream:system/dz/main
# 现有装备
execute if score #temp temp matches 1 unless score @p dzsuccess matches 5 if data block ~ ~ ~ Items[{Slot:6b}] run function better_dream:system/dz/main

scoreboard players reset #temp temp