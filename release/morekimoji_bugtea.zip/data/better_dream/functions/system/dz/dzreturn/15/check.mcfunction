# 现有装备基础属性更新成功
execute as @p[scores={dzsuccess=15}] positioned ~-3 ~-1 ~ if block ~ ~ ~ minecraft:dispenser run function better_dream:system/dz/dzreturn/15/main
execute as @p[scores={dzsuccess=15}] positioned ~3 ~-1 ~ if block ~ ~ ~ minecraft:dispenser run function better_dream:system/dz/dzreturn/15/main