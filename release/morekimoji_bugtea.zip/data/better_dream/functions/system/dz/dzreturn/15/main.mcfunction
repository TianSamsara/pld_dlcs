# 移动成品到输出槽位
data modify block ~ ~ ~ Items[0].Slot set value 5b

# 提示
tellraw @p {"text": "§7[更爽的盘灵] 现有装备基础属性更新成功！"}
playsound minecraft:block.anvil.use block @a[distance=..5] ~ ~ ~

scoreboard players set @p dzsuccess 0