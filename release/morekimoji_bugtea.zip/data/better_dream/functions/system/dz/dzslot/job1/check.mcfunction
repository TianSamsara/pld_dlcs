# 弓箭手附灵等级限制解除（装备标签）

execute if data block ~ ~ ~ Items[{tag:{rare:4}}] run function better_dream:system/dz/dzslot/job1/rare4
execute if data block ~ ~ ~ Items[{tag:{rare:5}}] run function better_dream:system/dz/dzslot/job1/rare5_6
execute if data block ~ ~ ~ Items[{tag:{rare:6}}] run function better_dream:system/dz/dzslot/job1/rare5_6