data modify block ~ ~ ~ Items[0].tag.canenchant set value 2

# 如果未附灵则修改 Lore
# 槽位 5 为新锻造，不包含制作者标签
execute unless data block ~ ~ ~ Items[0].tag.enchant_id run data modify block ~ ~ ~ Items[{Slot:5b}].tag.display.Lore[-3] set value '[{"translate":"pl.enchant"},{"translate":"pl.enchant.canenchant2"}]'
# 槽位 6 为现有装备基础属性更新，包含制作者标签
execute unless data block ~ ~ ~ Items[0].tag.enchant_id run data modify block ~ ~ ~ Items[{Slot:6b}].tag.display.Lore[-4] set value '[{"translate":"pl.enchant"},{"translate":"pl.enchant.canenchant2"}]'

execute if data block ~ ~ ~ Items[{Slot:6b}] run scoreboard players set @p dzsuccess 15