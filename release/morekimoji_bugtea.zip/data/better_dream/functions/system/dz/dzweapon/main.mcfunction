#三宝玉如意
execute if data block ~ ~ ~ Items[{tag:{id:"panling:axe5"}}] run function better_dream:system/dz/dzweapon/patches/axe5
#昆仑飞仙
execute if data block ~ ~ ~ Items[{tag:{id:"panling:sword5"}}] run function better_dream:system/dz/dzweapon/patches/sword5

#锁魂炉
execute if data block ~ ~ ~ Items[{tag:{id:"panling:furnace4"}}] run function better_dream:system/dz/dzweapon/patches/furnace4
#七煞鼎
execute if data block ~ ~ ~ Items[{tag:{id:"panling:furnace5"}}] run function better_dream:system/dz/dzweapon/patches/furnace5

#混元神鼎
execute if data block ~ ~ ~ Items[{tag:{id:"panling:furnace6"}}] run function better_dream:system/dz/dzweapon/patches/furnace6