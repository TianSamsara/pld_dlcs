#三宝玉如意
data modify block ~ ~ ~ Items[0].tag.PLattributes.base.atk_pt set value 18
data modify block ~ ~ ~ Items[0].tag.display.Lore[5] set value '[{"translate":"pl.attribute.weapon_attack0"},{"text":"18","color":"white","italic":false},{"text":"  "},{"translate":"pl.attribute.weapon_attack_speed"},{"text":"2.0","color":"white","italic":false}]'

execute if data block ~ ~ ~ Items[{Slot:6b}] run scoreboard players set @p dzsuccess 15