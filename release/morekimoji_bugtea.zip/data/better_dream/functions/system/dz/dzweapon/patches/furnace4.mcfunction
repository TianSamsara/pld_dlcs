#锁魂炉
data modify block ~ ~ ~ Items[0].tag.PLattributes.base.atk_pt set value 16
data modify block ~ ~ ~ Items[0].tag.display.Lore[5] set value '[{"translate":"pl.attribute.element_power"},{"text":"16","color":"white","italic":false}]'

execute if data block ~ ~ ~ Items[{Slot:6b}] run scoreboard players set @p dzsuccess 15