#七煞鼎
data modify block ~ ~ ~ Items[0].tag.PLattributes.base.atk_pt set value 21
data modify block ~ ~ ~ Items[0].tag.display.Lore[5] set value '[{"translate":"pl.attribute.element_power"},{"text":"21","color":"white","italic":false}]'

execute if data block ~ ~ ~ Items[{Slot:6b}] run scoreboard players set @p dzsuccess 15