#混元神鼎
data modify block ~ ~ ~ Items[0].tag.PLattributes.base.atk_pt set value 27.0
data modify block ~ ~ ~ Items[0].tag.display.Lore[6] set value '[{"translate":"pl.attribute.element_power"},{"text":"27.0","color":"white","italic":false}]'

execute if data block ~ ~ ~ Items[{Slot:6b}] run scoreboard players set @p dzsuccess 15