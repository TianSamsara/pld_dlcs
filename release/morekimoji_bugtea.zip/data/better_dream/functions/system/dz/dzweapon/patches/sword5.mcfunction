#昆仑飞仙
data modify block ~ ~ ~ Items[0].tag.PLattributes.base.atk_pt set value 14
data modify block ~ ~ ~ Items[0].tag.display.Lore[5] set value '[{"translate":"pl.attribute.weapon_attack0"},{"text":"14","color":"white","italic":false},{"text":"  "},{"translate":"pl.attribute.weapon_attack_speed"},{"text":"1.6","color":"white","italic":false}]'

execute if data block ~ ~ ~ Items[{Slot:6b}] run scoreboard players set @p dzsuccess 15