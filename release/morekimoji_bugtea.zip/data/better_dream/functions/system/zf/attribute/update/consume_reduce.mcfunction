# 初始阵法不消耗率
scoreboard players add @s zf_consume_reduce 20