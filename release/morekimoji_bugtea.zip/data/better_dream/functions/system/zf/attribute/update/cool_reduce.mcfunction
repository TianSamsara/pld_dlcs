# 初始阵法冷却缩减率
scoreboard players add @s zf_cool_reduce 20