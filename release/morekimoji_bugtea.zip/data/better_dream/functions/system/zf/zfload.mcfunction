# 阵法冷却缩减系统上限
scoreboard players set #system_limit zf_cool_reduce 90

# 阵法不消耗率系统上限
scoreboard players set #system_limit zf_consume_reduce 90