# 重华晶冷却刷新优化
execute if score #system tick_operation matches 3 as @a run function better_dream:system/tpsystem/5ticks_player
# 调试
# execute as @a unless entity @s[scores={using_tpstone=0}] run tellraw @s [{"score": {"name": "#system", "objective": "tick_operation"}}, " ", {"score": {"name": "@s", "objective": "using_tpstone"}}, " ", {"score": {"name": "@s", "objective": "better_using_tpstone"}}]