scoreboard players set @s vertigo_5ticks 20
data merge entity @s {NoAI:1b}
