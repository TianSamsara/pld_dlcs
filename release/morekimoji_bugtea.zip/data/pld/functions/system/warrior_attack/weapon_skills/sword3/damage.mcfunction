#伤害
#获得玩家最大生命值
execute store result score @s entity_4max_health run attribute @s generic.max_health get 10000
#获得所需伤害量
scoreboard players operation #temp entity_hurt_temp = @s entity_4max_health


