execute at @a[scores={dr=114}] as @a[scores={dr=114}] if score @s gold_chest = #systemlq lq run tag @s add lq
function ddw:book/drbook2 