execute at @e[tag=lq] run tag @a[limit=1,sort=nearest,scores={gold_chest=0}] add blq 
function ddw:book/drbook3 