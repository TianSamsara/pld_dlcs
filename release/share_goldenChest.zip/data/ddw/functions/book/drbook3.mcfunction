scoreboard players set @a[tag=blq] gold_chest 1
function ddw:book/drbook4 