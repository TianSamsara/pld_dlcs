execute at @a[tag=lq] run tellraw @a[scores={dr=114}] "§4【分享开箱次数】§3已给予可能的目标金钥匙使用权"
execute at @a[tag=!lq] run tellraw @a[scores={dr=114}] "§4【分享开箱次数】§3你没有开箱次数了"
execute at @e[scores={dr=114}] as @e[tag=lq] run tag @s[tag=!blq] add yuanbai
execute at @a[scores={gold_chest=1}] run function ddw:book/loadd2
execute at @a[tag=blq] run tellraw @a[tag=blq] "§4【分享开箱次数】§3你获得了一次额外的开箱子机会"
function ddw:book/drbook5