scoreboard players set @a[tag=lq] gold_chest 0
scoreboard players set @a[scores={dr=114}] dr 0
tag @a remove blq
tag @a remove lq
scoreboard players enable @a dr