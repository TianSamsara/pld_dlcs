tellraw @a[tag=yuanbao] "§2由于你的慷慨老天赐予你五个§e金元宝"
give @a[tag=yuanbao] minecraft:gold_ingot{display:{Name:'{"translate":"pl.item.name.gold"}'},id:"panling:gold_ingot"} 5
tag @a remove yuanbao