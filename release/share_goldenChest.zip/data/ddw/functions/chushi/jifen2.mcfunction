scoreboard objectives add lq dummy "lq"
scoreboard players set #systemlq lq 1