fill 24 46 155 24 50 151 minecraft:reinforced_deepslate
setblock 24 48 153 minecraft:coal_ore
setblock 25 48 153 minecraft:birch_button[face=wall,facing=east,powered=false]
