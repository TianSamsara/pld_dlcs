scoreboard players set @a[tag=!drcs] dr 0
tag @a[tag=!drcs] add drcs