#当前正在加载大佬带带我
function ddw:chushi/lingqu
tellraw @a "§4[共享宝箱次数] §2加载成功  §3作者:兲SAMSARA  §e请前往钱庄附近领取菜单"
function ddw:chushi/jifen
function ddw:chushi/jifen2