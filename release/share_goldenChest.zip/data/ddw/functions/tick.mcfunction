execute if block 25 48 153 minecraft:birch_button[face=wall,facing=east,powered=true] run function ddw:chushi/tag
execute if block 25 48 153 minecraft:birch_button[face=wall,facing=east,powered=true] run function ddw:book/loadd
execute at @a[scores={dr=114}] run function ddw:book/drbook1
scoreboard players enable @a dr
execute at @a[tag=!drcs] run function ddw:chushi/tag2