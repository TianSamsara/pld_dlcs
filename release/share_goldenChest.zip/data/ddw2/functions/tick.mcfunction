execute if block 190 54 89 minecraft:stone_button[face=wall,facing=north,powered=true] run function ddw:book/drbook
execute if score @s dr = 114 run function ddw:book/drbook2