#scoreboard players enable
scoreboard players enable @a initialize_the_load

scoreboard players set #system_limit_first initialize_the_load 1

function load:display/fitst