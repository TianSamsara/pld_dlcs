#function xsj:system/zf/tick
#function xsj:system/shulker_box/tick
#记分板-职业
#初次加载设置 execute unless score #system element_dlc_installed matches 1..

scoreboard players set #system_limit_end initialize_the_load 1

#scoreboard players set #system_limit_1 initialize_the_load 1
#scoreboard players set #system_limit_2 initialize_the_load 1

execute if score #system_limit_1 initialize_the_load matches 1 run function load:xsj/qk_op/load
execute if score #system_limit_2 initialize_the_load matches 1 run function load:wonderful_pld/load
#execute if score #system_limit_3 initialize_the_load matches 1 run function load:xsj/qk_op/load
#移除
#scoreboard objectives remove initialize_the_load
scoreboard players enable @a initialize_the_end