#function xsj:system/zf/tick
#function xsj:system/shulker_box/tick
#记分板-职业
#初次加载设置 execute unless score #system element_dlc_installed matches 1..
scoreboard players set #system_limit_1 initialize_the_load 0
scoreboard players set #system_limit_2 initialize_the_load 0
scoreboard players set #system_limit_3 initialize_the_load 0

tellraw @a {"text":"    §c[DLC] §e§l万通-集合DLC §b请选择设置："}
tellraw @a {"text":"§7============================"}
tellraw @a {"text":"§6[额外功能.1] §b万通货斋   §a§l[=点击开启=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 1"}}
tellraw @a {"text":"§6[额外功能.2] §b更爽盘灵   §a§l[=点击开启=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 2"}}
#tellraw @a {"text":"§6[额外功能.3]  §b罪如歌    §a§l§m[=点击开启=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 3"}}
tellraw @a {"text":"§7============================"}
tellraw @a {"text":"           §c请确认安装设置后     ","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 100"}}
tellraw @a {"text":"       §a§l[==激活所选数据包==]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 100"}}
tellraw @a {"text":"§7============================"}
scoreboard players set #system_limit_end initialize_the_load 0
