#function xsj:system/zf/tick
#function xsj:system/shulker_box/tick
#记分板-职业
#初次加载设置 execute unless score #system element_dlc_installed matches 1..

tellraw @a {"text":"    §c[DLC] §e§l万通-集合DLC §b请选择设置："}
tellraw @a {"text":"§7============================"}
