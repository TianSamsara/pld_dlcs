#function xsj:system/zf/tick
#function xsj:system/shulker_box/tick
#记分板-职业
#初次加载设置 execute unless score #system element_dlc_installed matches 1..
tellraw @a {"text":"§7============================"}
tellraw @a {"text":"           §c请确认安装设置后     "}
tellraw @a {"text":"       §a§l[==激活所选数据包==]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 100"}}
tellraw @a {"text":"§7============================"}

