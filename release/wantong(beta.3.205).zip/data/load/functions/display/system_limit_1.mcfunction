
execute if score #system_limit_1 initialize_the_load matches 0 run tellraw @a {"text":"§6[额外功能.1] §b万通货斋   §a§l[=点击开启=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 1"}}

execute if score #system_limit_1 initialize_the_load matches 1 run tellraw @a {"text":"§6[额外功能.1] §b万通货斋   §c§l[=点击关闭=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 10"}}
#scoreboard players set #system_limit_1 initialize_the_load 0
