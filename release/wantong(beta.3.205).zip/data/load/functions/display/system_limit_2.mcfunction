
execute if score #system_limit_2 initialize_the_load matches 0 run tellraw @a {"text":"§6[额外功能.2] §b更爽盘灵   §a§l[=点击开启=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 2"}}

execute if score #system_limit_2 initialize_the_load matches 1 run tellraw @a {"text":"§6[额外功能.2] §b更爽盘灵   §c§l[=点击关闭=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 20"}}

#scoreboard players set #system_limit_2 initialize_the_load 0