
execute if score #system_limit_3 initialize_the_load matches 0 run tellraw @a {"text":"§6[额外功能.3]  §b罪如歌    §a§l[§m=点击开启=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 0"}}

execute if score #system_limit_3 initialize_the_load matches 1 run tellraw @a {"text":"§6[额外功能.3]  §b罪如歌     §c§l[§m=点击关闭=]","clickEvent": {"action": "run_command","value": "/trigger initialize_the_load set 0"}}
#scoreboard players set #system_limit_3 initialize_the_load 1