#function xsj:system/zf/tick
#function xsj:system/shulker_box/tick
#记分板-职业
#初次加载设置 execute unless score #system element_dlc_installed matches 1..
#

execute if score @s initialize_the_load matches 100 run function load:display/end

execute if score @s initialize_the_load matches 1 run scoreboard players set #system_limit_1 initialize_the_load 1
execute if score @s initialize_the_load matches 2 run scoreboard players set #system_limit_2 initialize_the_load 1
execute if score @s initialize_the_load matches 3 run scoreboard players set #system_limit_3 initialize_the_load 1
execute if score @s initialize_the_load matches 10 run scoreboard players set #system_limit_1 initialize_the_load 0
execute if score @s initialize_the_load matches 20 run scoreboard players set #system_limit_2 initialize_the_load 0
execute if score @s initialize_the_load matches 30 run scoreboard players set #system_limit_3 initialize_the_load 0

execute if score #system_limit_end initialize_the_load matches 0 run function load:display/fitst_display

execute if score #system_limit_end initialize_the_load matches 0 run function load:display/system_limit_1

execute if score #system_limit_end initialize_the_load matches 0 run function load:display/system_limit_2
#unction load:display/system_limit_3
execute if score #system_limit_end initialize_the_load matches 0 run function load:display/fitst_end_display

scoreboard players set @s initialize_the_load 0 