

execute if score #system_limit_1 initialize_the_load matches 1 run scoreboard players set #finish first_xsj_load 1
execute if score #system_limit_2 initialize_the_load matches 1 run scoreboard players set #finish first_wonderful_pld_load 1

#execute as @a run function load:xsj/remove_check 
#execute unless score #finish first_xsj_load matches 1.. run function load:xsj/qk/load
#execute unless score #finish first_wonderful_pld_load matches 1.. run function wonderful_pld:load