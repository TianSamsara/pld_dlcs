#/setblock -188 63 18 minecraft:stone_pressure_plate[powered=false]
#/setblock -102 45 285 minecraft:stone_pressure_plate[powered=false]

scoreboard objectives add initialize_the_load trigger ["初始化加载标准"]
scoreboard objectives add initialize_the_end trigger ["初始化加载_卸载标准"]
#scoreboard objectives add initialize_the_load trigger ["初始化加载标准"]

#初始化加载记分板-必须加载-可以不用，不能没有

scoreboard objectives add element_number_total dummy "通用元素储存量"
scoreboard objectives add element_menu_trigger2 trigger "元素银行-无损元素转换"

function xsj:load
#function wonderful_pld:load

scoreboard objectives add first_wonderful_pld_load dummy ["更爽盘灵_初始化加载"]
scoreboard objectives add first_xsj_load dummy ["万通货斋_初始化加载"]

execute unless score #no first_xsj_load matches 1..2 run scoreboard players set #no first_xsj_load 1
execute unless score #finish first_xsj_load matches 0..1 run scoreboard players set #finish first_xsj_load 0
execute unless score #finish first_wonderful_pld_load matches 0..1 run scoreboard players set #finish first_wonderful_pld_load 0

execute unless score #system_limit_first initialize_the_load matches 1 run schedule function load:display 2s

execute if score #system_limit_first initialize_the_load matches 1 if score #system_limit_end initialize_the_load matches 0 run schedule function load:display/tick 2s

execute if score #system_limit_end initialize_the_load matches 1 run schedule function load:end 2s
#execute unless score #finish first_xsj_load matches 1.. run function load:xsj/qk/load
#execute unless score #finish first_wonderful_pld_load matches 1.. run function wonderful_pld:load