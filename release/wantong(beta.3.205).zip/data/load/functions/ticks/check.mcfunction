#function xsj:system/zf/tick
#function xsj:system/shulker_box/tick
#记分板-职业
#scoreboard players set @s ldjl 0

execute if score @s first_xsj_load matches 1 run return 0

execute if score #finish first_xsj_load matches 1 run scoreboard players set @s first_xsj_load 1



