
#say 1

          execute as @a run function load:ticks/tick_middle


