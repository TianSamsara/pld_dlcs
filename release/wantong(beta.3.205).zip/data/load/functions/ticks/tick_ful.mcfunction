
#schedule function load:wonderful_pld/tick 1s