
#say 1
scoreboard players add #system_dlc_tick tick_count 1 

execute if score #system_limit_first initialize_the_load matches 1.. run scoreboard players enable @s initialize_the_load

execute if score #system_limit_end initialize_the_load matches 0 if score #system_limit_first initialize_the_load matches 1.. if score @s initialize_the_load matches 1.. run function load:display/tick

execute if score #finish first_xsj_load matches 1 run function load:ticks/tick_xsj

#execute if score #finish first_wonderful_pld_load matches 1 run function load:ticks/tick_ful

execute if score #finish first_xsj_load matches 1 if score @s job matches 2 if score #system_dlc_tick tick_count matches 20 run function xsj:system/zf/tick

execute if score #system_dlc_tick tick_count matches 20 run function load:ticks/tick_set

execute if score #system_dlc_tick tick_count matches 21.. run scoreboard players set #system_dlc_tick tick_count 0 
