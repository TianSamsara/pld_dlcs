#function xsj:system/zf/tick
#function xsj:system/shulker_box/tick
#记分板-职业
#scoreboard players set @s ldjl 0
execute if score #finish first_xsj_load matches 1 run function load:ticks/check
execute if score #finish first_wonderful_pld_load matches 1 run function load:ticks/check2





