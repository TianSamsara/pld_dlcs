#乾坤袋使用

#execute unless entity @s[nbt={Inventory:[{tag:{id:"dlc:qiankun_dai"}}]}] run scoreboard players set @s qiankundai_main 0

execute if score @s qiankundai matches 1 run function xsj:qiankun/main
execute if score #system_dlc_tick tick_count matches 20 run function xsj:qiankun/auto_cun/1s

#execute unless score @s instance3_8f matches 0..1 run scoreboard players set @s instance3_8f 0
execute unless score @s instance3_8f matches 1 if entity @s[x=2640,y=30,z=-960,dx=150,dy=47,dz=150] run function xsj:system/instances3/tick

#execute if entity @s[x=2640,y=30,z=-960,dx=150,dy=47,dz=150] if score @s instance3_8f matches 0 run function xsj:system/instances3/tick
#execute if score @s xsj_right_click_check matches 1.. if entity @s[nbt={SelectedItem:{tag:{fab_id:"fab_main",}}}] run say 1
execute if score @s xsj_right_click_check matches 1.. if entity @s[nbt={SelectedItem:{tag:{fab_id:"fab_main",}}}] run function xsj:system/fab/check

execute if score @s fab_tick1_1 matches 0.. run scoreboard players remove @s fab_tick1_1 1
execute if score @s fab_tick4_1 matches 0.. run scoreboard players remove @s fab_tick4_1 1
execute if score @s fab_tick4_2 matches 0.. run scoreboard players remove @s fab_tick4_2 1
#execute if score @s fab_tick2_1 matches 0.. run scoreboard players remove @s fab_tick2_1 1
#execute if score @s fab_tick2_2 matches 0.. run scoreboard players remove @s fab_tick2_2 1
execute if score @s fab_tick4_1 matches 0 run function xsj:system/tick/fabtick/tick1_2
execute if score @s fab_tick4_2 matches 0 run function xsj:system/tick/fabtick/tick2_1
#execute if score @s fab_tick2_1 matches 0 run function xsj:system/tick/fabtick/tick2_1
#execute if score @s fab_tick2_2 matches 0 run function xsj:system/tick/fabtick/tick2_2

#execute if score #system_dlc_tick tick_count matches 20 run function xsj:system/processed/adv
#execute if score #system_dlc_tick tick_count matches 10 run function xsj:system/dz1/dabao/main_xy
#schedule function xsj:system/tick 1s