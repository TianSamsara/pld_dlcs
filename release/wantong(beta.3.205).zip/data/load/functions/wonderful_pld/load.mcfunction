

function pld:system/zf/zfload
function pld:system/warrior_attack/load
function pld:system/archer_damage/weapon_skill/load

schedule function load:wonderful_pld/qk/1 1s