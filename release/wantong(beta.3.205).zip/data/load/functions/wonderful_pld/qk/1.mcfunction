
## 皇城


# 加载区块
# 货斋及中心广场
#forceload add 144 32 223 113
# 铁匠铺
forceload add 111 175 48 80

schedule function load:wonderful_pld/qk/1_load 1s