
## 皇城


# 刷新实体
kill @e[tag=panling,type=minecraft:villager]

forceload add 111 175 48 80

schedule function load:wonderful_pld/qk/end 1s

