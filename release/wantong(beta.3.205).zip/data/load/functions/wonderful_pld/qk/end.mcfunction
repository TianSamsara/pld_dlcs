
## 皇城


say §a§l爽盘加载结束
scoreboard players set #finish first_wonderful_pld_load 1

