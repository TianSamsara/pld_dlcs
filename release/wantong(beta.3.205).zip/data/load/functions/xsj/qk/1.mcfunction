
## 种族

# 人 刷新实体
kill @e[tag=panling,type=minecraft:villager]

# 仙 加载区块
forceload add 3247 895 3216 864
forceload add 3280 991 3295 976
forceload add 3215 848 3200 863
forceload add 3231 831 3216 816

schedule function load:xsj/qk/1_load 1s