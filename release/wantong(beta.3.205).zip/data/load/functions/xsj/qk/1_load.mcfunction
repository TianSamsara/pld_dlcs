
## 种族

# 人 卸载区块
forceload remove 1743 111 1728 80
forceload remove 1600 112 1615 127
forceload remove 1616 96 1631 111

# 仙 刷新实体
kill @e[tag=panling,type=minecraft:villager]

# 神 加载区块
forceload add 3280 352 3343 383

schedule function load:xsj/qk/1_load2 1s