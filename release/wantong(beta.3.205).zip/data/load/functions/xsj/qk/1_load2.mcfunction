
## 种族

# 仙 卸载区块
forceload remove 3247 895 3216 864
forceload remove 3280 991 3295 976
forceload remove 3215 848 3200 863
forceload remove 3231 831 3216 816

# 神 刷新实体
kill @e[tag=panling,type=minecraft:villager]

# 妖 加载区块
forceload add 2735 848 2720 863
forceload add 2655 912 2640 927
forceload add 2671 911 2640 848

schedule function load:xsj/qk/1_load3 1s