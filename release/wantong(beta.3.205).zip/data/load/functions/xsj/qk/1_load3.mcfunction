
## 种族

# 神 卸载区块
forceload remove 3280 352 3343 383

# 妖 刷新实体
kill @e[tag=panling,type=minecraft:villager]

# 战神 加载区块
forceload add 3248 -304 3311 -224
forceload add 3279 -160 3264 -144

schedule function load:xsj/qk/1_load4 1s