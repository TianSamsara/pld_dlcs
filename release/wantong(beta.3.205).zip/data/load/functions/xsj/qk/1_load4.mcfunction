
## 种族

# 妖 卸载区块
forceload remove 2735 848 2720 863
forceload remove 2655 912 2640 927
forceload remove 2671 911 2640 848

# 战神 刷新实体
kill @e[tag=panling,type=minecraft:villager]

schedule function load:xsj/qk/1_load5 1s