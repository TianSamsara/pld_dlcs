
## 种族

# 战神 卸载区块
forceload remove 3248 -304 3311 -224
forceload remove 3279 -160 3264 -144

schedule function load:xsj/qk/2 2s