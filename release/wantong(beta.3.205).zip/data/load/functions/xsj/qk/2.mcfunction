
## 副本


# 加载区块
# 镇妖塔
forceload add -177 -161 -224 -208
forceload add 2656 -944 2671 -929
# 圣山
forceload add -17 -928 -32 -913
# 火魔
forceload add -289 784 -304 799
# 始皇
forceload add 608 -129 623 -144
# 哭谷
forceload add -689 -625 -704 -656




schedule function load:xsj/qk/2_load 2s