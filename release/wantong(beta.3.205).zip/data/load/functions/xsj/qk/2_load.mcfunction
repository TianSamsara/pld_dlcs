
## 副本


# 刷新实体
kill @e[tag=panling,type=minecraft:villager]


# 镇妖塔
# 结构
	setblock -208 49 -176 air
	setblock -208 49 -176 minecraft:structure_block[mode=load]{author:"wu_lonely",ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"xsj:instance3_select2",posX:0,posY:1,posZ:0,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:1b,sizeX:17,sizeY:10,sizeZ:15}

	setblock -208 50 -176 air
	setblock -208 50 -176 minecraft:redstone_block

	execute if block -208 49 -176 minecraft:structure_block{name:"xsj:instance3_select2",} run say §a§l镇妖塔结构加载
# 末影箱
	setblock -184 65 -176 minecraft:ender_chest[facing=west,waterlogged=false]
	setblock -184 65 -184 minecraft:ender_chest[facing=west,waterlogged=false]
	setblock -196 65 -183 minecraft:ender_chest[facing=east,waterlogged=false]
	setblock -196 65 -177 minecraft:ender_chest[facing=east,waterlogged=false]
	setblock -195 52 -185 minecraft:ender_chest[facing=west,waterlogged=false]
	# 金砖
	setblock 2659 70 -939 minecraft:ender_chest[facing=east,waterlogged=false]


# 末影箱
# 圣山
setblock -27 48 -922 minecraft:ender_chest[facing=east,waterlogged=false]
#setblock -24 48 -925 minecraft:ender_chest[facing=south,waterlogged=false]
# 火魔
setblock -295 11 796 minecraft:ender_chest[facing=south,waterlogged=false]
# 始皇
setblock 612 10 -142 minecraft:ender_chest[facing=east,waterlogged=false]
# 哭谷
setblock -691 109 -648 minecraft:ender_chest[facing=south,waterlogged=false]




schedule function load:xsj/qk/2_load2 2s