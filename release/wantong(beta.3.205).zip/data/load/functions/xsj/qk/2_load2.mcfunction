
## 副本


# 卸载区块
# 镇妖塔
forceload remove -177 -161 -224 -208
forceload remove 2656 -944 2671 -929
# 圣山
forceload remove -17 -928 -32 -913
# 火魔
forceload remove -289 784 -304 799
# 始皇
forceload remove 608 -129 623 -144
# 哭谷
forceload remove -689 -625 -704 -656


# 末影箱
# 圣山
	# 门口
	forceload add -208 -880 -193 -865
	setblock -199 113 -867 minecraft:ender_chest[facing=west,waterlogged=false]
	setblock -207 113 -867 minecraft:ender_chest[facing=east,waterlogged=false]
	forceload remove -208 -880 -193 -865
	# 山内
	forceload add -192 -832 -177 -817
	setblock -184 101 -831 minecraft:ender_chest[facing=north,waterlogged=false]
	forceload remove -192 -832 -177 -817
	# 出生点
	forceload add 3248 -1872 3263 -1841
	setblock 3250 127 -1859 minecraft:ender_chest[facing=south,waterlogged=false]
	setblock 3250 127 -1855 minecraft:ender_chest[facing=north,waterlogged=false]
	forceload remove 3248 -1872 3263 -1841
# 火魔金砖
	forceload add 1136 912 1151 927
	setblock 1151 24 924 minecraft:ender_chest[facing=north,waterlogged=false]
	setblock 1149 24 924 minecraft:ender_chest[facing=north,waterlogged=false]
	forceload remove 1136 912 1151 927
# 始皇金砖
	forceload add 2832 -431 2847 -416
	setblock 2840 29 -412 minecraft:ender_chest[facing=east,waterlogged=false]
	setblock 2840 29 -416 minecraft:ender_chest[facing=east,waterlogged=false]
	forceload remove 2832 -431 2847 -416
# 哭谷金砖
	forceload add 928 1312 943 1327
	setblock 938 159 1319 minecraft:ender_chest[facing=east,waterlogged=false]
	setblock 942 159 1319 minecraft:ender_chest[facing=west,waterlogged=false]
	forceload remove 928 1312 943 1327




schedule function load:xsj/qk/3 2s