
## 货物


# 加载区块
# 墓园
forceload add 175 -560 144 -545
# 雨竹
forceload add -384 -401 -304 -463
# 陈大夫
forceload add -113 128 -127 143
# 姜太公
forceload add -592 448 -577 463
# 温泉客栈
forceload add -480 336 -449 367
# 王员外
forceload add -273 384 -287 399
forceload add -336 607 -321 592
# 天道碑
forceload add 64 784 270 847
# 山神庙
forceload add 847 111 832 96




schedule function load:xsj/qk/3_load 1s