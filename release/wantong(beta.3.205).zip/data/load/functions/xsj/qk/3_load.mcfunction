
## 货物


# 刷新实体
kill @e[tag=panling,type=minecraft:villager]


# 末影箱
# 墓园
setblock 160 55 -547 minecraft:ender_chest[facing=south,waterlogged=false]
# 雨竹
setblock -321 115 -423 minecraft:ender_chest[facing=east,waterlogged=false]
setblock -355 101 -442 minecraft:ender_chest[facing=west,waterlogged=false]
# 陈大夫
setblock -120 47 138 minecraft:ender_chest[facing=west,waterlogged=false]
# 姜太公
setblock -590 104 457 minecraft:ender_chest[facing=north,waterlogged=false]
# 温泉客栈
setblock -461 95 359 minecraft:ender_chest[facing=east,waterlogged=false]
# 王员外
setblock -285 54 395 minecraft:ender_chest[facing=east,waterlogged=false]
# 客栈
setblock -323 58 583 minecraft:ender_chest[facing=east,waterlogged=false]
# 天道碑
setblock 122 49 803 minecraft:ender_chest[facing=south,waterlogged=false]
# 山神庙
setblock 832 40 106 minecraft:ender_chest[facing=east,waterlogged=false]




schedule function load:xsj/qk/3_load2 1s