
## 货物


# 卸载区块
# 墓园
forceload remove 175 -560 144 -545
# 雨竹
forceload remove -384 -401 -304 -463
# 陈大夫
forceload remove -113 128 -127 143
# 姜太公
forceload remove -592 448 -577 463
# 温泉客栈
forceload remove -480 336 -449 367
# 王员外
forceload remove -273 384 -287 399
forceload remove -336 607 -321 592
# 天道碑
forceload remove 64 784 270 847
# 山神庙
forceload remove 847 111 832 96




schedule function load:xsj/qk/4 2s