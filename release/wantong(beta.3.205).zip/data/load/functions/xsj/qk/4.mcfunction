
## 皇城


# 加载区块
# 货斋及中心广场
forceload add 144 32 223 113
# 铁匠铺
forceload add 111 175 48 80
# ?
forceload add 63 32 79 16




schedule function load:xsj/qk/4_load 2s