
## 皇城


# 刷新实体
kill @e[tag=panling,type=minecraft:villager]


# 货斋
setblock 186 39 69 air
setblock 186 39 69 minecraft:structure_block[mode=load]{author:"wu_lonely",ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"xsj:shui3",posX:0,posY:1,posZ:0,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:1b,sizeX:26,sizeY:16,sizeZ:27}

setblock 186 40 69 air
setblock 186 40 69 minecraft:redstone_block

execute if block 186 39 69 minecraft:structure_block{name:"xsj:shui3",} run say §a§l万通结构加载


# 铁匠铺
setblock 88 29 145 air
setblock 88 29 145 minecraft:structure_block[mode=load]{author:"?",ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"xsj:dzs3",posX:0,posY:1,posZ:0,powered:0b,rotation:"CLOCKWISE_90",seed:0L,showair:0b,showboundingbox:1b,sizeX:23,sizeY:11,sizeZ:11}

setblock 88 30 145 air
setblock 88 30 145 minecraft:redstone_block
execute if block 88 29 145 minecraft:structure_block{name:"xsj:dzs3",} run say §a§l铁匠铺结构加载
#setblock 86 29 145 minecraft:structure_block[mode=load]{author:"?",ignoreEntities:1b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"xsj:dzs3",posX:0,posY:1,posZ:0,powered:0b,rotation:"CLOCKWISE_90",seed:0L,showair:0b,showboundingbox:1b,sizeX:23,sizeY:10,sizeZ:11}

setblock 83 46 150 minecraft:ender_chest[facing=north,waterlogged=false]


# 末影箱
# 中心广场
setblock 182 42 54 minecraft:ender_chest[facing=south,waterlogged=false]
setblock 170 42 60 minecraft:ender_chest[facing=east,waterlogged=false]
setblock 176 42 72 minecraft:ender_chest[facing=north,waterlogged=false]
setblock 188 42 66 minecraft:ender_chest[facing=west,waterlogged=false]
setblock 176 42 54 minecraft:ender_chest[facing=south,waterlogged=false]
setblock 170 42 66 minecraft:ender_chest[facing=east,waterlogged=false]
setblock 182 42 72 minecraft:ender_chest[facing=north,waterlogged=false]
setblock 188 42 60 minecraft:ender_chest[facing=west,waterlogged=false]
# 瓜棚
setblock 156 44 51 minecraft:ender_chest[facing=north,waterlogged=false]




schedule function load:xsj/qk/4_load2 2s