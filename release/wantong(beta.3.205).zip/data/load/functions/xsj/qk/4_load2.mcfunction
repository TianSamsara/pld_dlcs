
## 皇城


# 卸载区块
# 货斋及中心广场
forceload remove 144 32 223 113
# 铁匠铺
forceload remove 111 175 48 80
# ?
forceload remove 63 32 79 16


# 炼丹房箱子 / 末影箱
forceload add 240 16 271 47
setblock 257 50 22 minecraft:ender_chest[facing=south,waterlogged=false]
setblock 256 50 27 minecraft:chest[facing=north,type=single,waterlogged=false]
setblock 257 50 27 minecraft:chest[facing=north,type=single,waterlogged=false]
setblock 258 50 27 minecraft:chest[facing=north,type=single,waterlogged=false]
forceload remove 240 16 271 47




schedule function load:xsj/qk/5 2s