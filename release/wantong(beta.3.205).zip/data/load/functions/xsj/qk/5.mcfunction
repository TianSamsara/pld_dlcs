
# 加载区块
# 老战士
forceload add -833 432 -848 447
# 老猎人
forceload add 496 47 511 32
# 孤文
#forceload add 725 -17 767 -32
# 渡船
#forceload add -192 16 -177 31
# 太上老君
forceload add 336 -705 351 -720
forceload add 1391 447 1376 431
# 赤澄
forceload add 159 144 144 159




schedule function load:xsj/qk/5_load 1s