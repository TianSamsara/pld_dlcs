
# 刷新实体
kill @e[tag=panling,type=minecraft:villager]

# 太上老君
setblock 340 33 -719 minecraft:ender_chest[facing=west,waterlogged=false]




schedule function load:xsj/qk/5_load2 1s