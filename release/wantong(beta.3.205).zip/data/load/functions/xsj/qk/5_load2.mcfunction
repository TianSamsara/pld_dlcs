
# 卸载区块
# 老战士
forceload remove -833 432 -848 447
# 老猎人
forceload remove 496 47 511 32
# 孤文
#forceload remove 725 -17 767 -32
# 渡船
#forceload remove -192 16 -177 31
# 太上老君
forceload remove 336 -705 351 -720
forceload remove 1391 447 1376 432
# 赤澄
forceload remove 159 144 144 159




schedule function load:xsj/qk/6 2s