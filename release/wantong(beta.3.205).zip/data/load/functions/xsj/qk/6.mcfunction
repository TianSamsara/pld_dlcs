
## 罪如歌副本

# 加载区块
# 火本
forceload add -561 720 -592 751
# 冰本
forceload add -112 -224 -97 -209




schedule function load:xsj/qk/6_load 1s