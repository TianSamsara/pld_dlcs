
## 罪如歌副本

# 刷新实体
kill @e[tag=panling,type=minecraft:villager]

# 末影箱
# 火本
setblock -592 71 731 minecraft:ender_chest[facing=east,waterlogged=false]
# 冰本
setblock -106 33 -218 minecraft:ender_chest[facing=east,waterlogged=false]




schedule function load:xsj/qk/6_load2 1s