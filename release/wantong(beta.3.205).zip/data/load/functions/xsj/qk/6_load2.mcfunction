
## 罪如歌副本

# 卸载区块
# 火本
forceload remove -561 720 -592 751
# 冰本
forceload remove -112 -224 -97 -209




schedule function load:xsj/qk/load_end 2s