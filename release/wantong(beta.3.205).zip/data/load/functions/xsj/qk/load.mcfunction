
# 初始化 NPC 差价跑商开关


## 种族

# 人 加载区块
forceload add 1743 111 1728 80
forceload add 1600 112 1615 127
forceload add 1616 96 1631 111

schedule function load:xsj/qk/1 1s