
#奈何桥
forceload add 192 -1776 207 -1761
setblock 207 54 -1773 minecraft:ender_chest[facing=south,waterlogged=false]
setblock 203 54 -1773 minecraft:ender_chest[facing=south,waterlogged=false]
forceload remove 192 -1776 207 -1761

#蜘蛛女王
forceload add 512 336 527 351
setblock 519 38 341 minecraft:ender_chest[facing=west,waterlogged=false]
forceload remove 512 336 527 351
#渔夫
forceload add 544 32 559 47
setblock 553 34 37 minecraft:ender_chest[facing=south,waterlogged=false]
forceload remove 544 32 559 47
#绿洲马贼长
forceload add -144 736 -129 751
setblock -132 54 742 minecraft:ender_chest[facing=east,waterlogged=false]
forceload remove -144 736 -129 751

#女娲
forceload add 1664 -240 1679 -225
setblock 1664 25 -230 minecraft:ender_chest[facing=west,waterlogged=false]
forceload remove 1664 -240 1679 -225
#盘古
forceload add 2848 320 2863 335
setblock 2853 25 334 minecraft:ender_chest[facing=west,waterlogged=false]
forceload remove 2848 320 2863 335
#蚩尤
forceload add 2848 -192 2863 -177
setblock 2850 25 -185 minecraft:ender_chest[facing=west,waterlogged=false]
forceload remove 2848 -192 2863 -177
#刷新实体
#kill @e[tag=panling,type=minecraft:villager]
#tp @e[tag=panling,type=minecraft:villager] ~ ~-1000 ~

forceload add 0 0

setblock 0 0 0 air
setblock 0 1 0 air
setblock 0 2 0 air

setblock 0 0 0 shulker_box
setblock 0 1 0 shulker_box
setblock 0 2 0 shulker_box
forceload remove 0 0
#罪如歌npc刷新修改
#/setblock 159 41 42 minecraft:repeating_command_block[conditional=false,facing=up]{Command:"function dlc:main/npc",CustomName:'{"text":"@"}',LastExecution:336204429L,LastOutput:'{"extra":[{"translate":"commands.function.success.single","with":["3","dlc:main/npc"]}],"text":"[13:02:57] "}',SuccessCount:4,TrackOutput:1b,UpdateLastExecution:1b,auto:0b,conditionMet:1b,powered:0b}
#setblock 159 41 42 minecraft:command_block[conditional=false,facing=up]{Command:"function dlc:main/npc",}


# 刷新罪如歌 NPC（如果有）
function dlc:dlcnpc


say §a§l万通加载结束
scoreboard players set #finish first_xsj_load 1

#schedule function load:xsj/qk/load_remove 1s

#function load:xsj/qk/load-xian2
#function yyt:beta/begin/setblock 157 55 -550 waystones:waystone[facing=north,half=upper,origin=player,waterlogged=false]{UUID:[I;-8001290,170937499,-1808471558,-606056828]}