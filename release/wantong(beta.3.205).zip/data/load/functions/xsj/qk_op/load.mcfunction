scoreboard objectives add xsj_sneak_check minecraft.custom:minecraft.sneak_time ["shift标记"]
scoreboard objectives add xsj_right_click_check minecraft.used:minecraft.carrot_on_a_stick ["右键标记"]

 function load:xsj/qk/load