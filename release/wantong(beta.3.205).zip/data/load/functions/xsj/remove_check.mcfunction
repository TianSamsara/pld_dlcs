#function xsj:system/zf/tick
#function xsj:system/shulker_box/tick
#记分板-职业
#scoreboard players set @s ldjl 0

execute unless score @s instance3_8f matches 1 run scoreboard players set @s instance3_8f 0

execute unless score @s element_number_total matches 0.. run scoreboard players set @s element_number_total 0
execute unless score @s element_number_total matches 0.. run scoreboard players set @s element_number_total 0

scoreboard players set @s weapon_skill_axe56_5ticks 0

scoreboard players set @s weapon_skill_sword56_5ticks 0
scoreboard players set @s weapon_skill_sword56_next_5ticks 0
scoreboard players set @s weapon_skill_sword56_as_5ticks 0

scoreboard players set @s weapon_skill_bow56_5ticks 0
scoreboard players set @s weapon_skill_bow56_lvl 0


