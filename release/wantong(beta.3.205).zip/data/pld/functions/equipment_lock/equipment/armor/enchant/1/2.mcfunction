execute unless score #finish first_wonderful_pld_load matches 1 if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments append value {id:"minecraft:protection",lvl:1s}
execute unless score #finish first_wonderful_pld_load matches 1 if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run scoreboard players set @s equipment_all_protection_multiply_base 4

execute if score #finish first_wonderful_pld_load matches 1 if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments append value {id:"minecraft:protection",lvl:2s}
execute if score #finish first_wonderful_pld_load matches 1 if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run scoreboard players set @s equipment_all_protection_multiply_base 8

execute unless block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments append value {id:"minecraft:protection",lvl:2s}
execute unless block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run scoreboard players set @s equipment_all_protection_multiply_base 8