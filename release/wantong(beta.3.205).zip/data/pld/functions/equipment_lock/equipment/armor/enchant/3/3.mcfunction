execute unless score #finish first_wonderful_pld_load matches 1 if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments append value {id:"projectile_protection",lvl:1}
execute unless score #finish first_wonderful_pld_load matches 1 if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run scoreboard players add @s equipment_arrow_protection_multiply_base 8

execute if score #finish first_wonderful_pld_load matches 1 if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments append value {id:"projectile_protection",lvl:3}
execute if score #finish first_wonderful_pld_load matches 1 if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run scoreboard players add @s equipment_arrow_protection_multiply_base 24

execute unless block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments append value {id:"projectile_protection",lvl:3}
execute unless block ~ 255 ~ chest{Items:[{Slot:0b,tag:{limit:1}}]} run scoreboard players add @s equipment_arrow_protection_multiply_base 24

