data modify storage pld:system Temp_player_new_mails append value {sent:"天道",is_taked:0b,title:'{"translate":"pl.chest_menu.system_lost.name"}',content:['{"translate":"pl.chest_menu.system_lost.lore.a"}','{"translate":"pl.chest_menu.system_lost.lore.b"}'],attached_items:[]}
loot replace block 0 -1 0 container.0 loot pld:items/armor_core_5
execute if score #finish first_xsj_load matches 0 run loot replace block 0 -1 0 container.1 loot pld:items/instance2_collection
execute if score #finish first_xsj_load matches 1 run loot replace block 0 -1 0 container.1 loot xsj:items/instance2_collection
data modify block 0 -1 0 Items[1].Count set value 2b
loot replace block 0 -1 0 container.2 loot pld:items/fire
data modify block 0 -1 0 Items[2].Count set value 20b
#loot replace block 0 -1 0 container.3 loot xsj:items/ticket
#data modify block 0 -1 0 Items[3].Count set value 8b

data modify storage pld:system Temp_player_new_mails[0].attached_items append from block 0 -1 0 Items[0]
data modify storage pld:system Temp_player_new_mails[0].attached_items append from block 0 -1 0 Items[1]
data modify storage pld:system Temp_player_new_mails[0].attached_items append from block 0 -1 0 Items[2]
#data modify storage pld:system Temp_player_new_mails[0].attached_items append from block 0 -1 0 Items[3]

function pld:system/chest_menu/screen/3_mails/get_mails/personal

