data merge block 0 0 0 {Items:[]}
give @s minecraft:iron_nugget{display:{Lore:['{"translate":"pl.lore.rare5"}','{"translate":"pl.item.lore.acore5a"}','{"translate":"pl.item.lore.acore5b"}'],Name:'{"translate":"pl.item.name.acore5"}'},id:"panling:armor_core_5",HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]}

execute if score #finish first_xsj_load matches 0 run loot replace block 0 0 0 container.0 loot pld:items/instance3_collection
execute if score #finish first_xsj_load matches 1 run loot replace block 0 0 0 container.0 loot xsj:items/instance3_collection
data modify block 0 0 0 Items[0].Count set value 2b
loot give @s mine 0 0 0 minecraft:diamond_pickaxe{isShulkerMarker:1b}

#loot give @s loot xsj:items/ticket3

give @s minecraft:magma_cream{id:"panling:earth",display:{Name:'{"translate":"pl.item.name.earth"}'}} 25
give @s minecraft:emerald{id:"panling:metal",display:{Name:'{"translate":"pl.item.name.metal"}'}} 25
give @s minecraft:bone{id:"panling:wood",display:{Name:'{"translate":"pl.item.name.wood"}'}} 25
give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 25
give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 25

