data merge block 0 0 0 {Items:[]}
execute if score #finish first_xsj_load matches 0 run loot replace block 0 0 0 container.0 loot pld:items/instance4_collection
execute if score #finish first_xsj_load matches 1 run loot replace block 0 0 0 container.0 loot xsj:items/instance4_collection
data modify block 0 0 0 Items[0].Count set value 2b
loot give @s mine 0 0 0 minecraft:diamond_pickaxe{isShulkerMarker:1b}

loot give @s loot xsj:items/ticket2

give @s minecraft:iron_nugget{display:{Lore:['{"translate":"pl.lore.rare5"}','{"translate":"pl.item.lore.acore5a"}','{"translate":"pl.item.lore.acore5b"}'],Name:'{"translate":"pl.item.name.acore5"}'},id:"panling:armor_core_5",HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]}
give @s minecraft:paper{CustomModelData:1,display:{Lore:['{"translate":"pl.item.lore.element_ticka"}','{"translate":"pl.item.lore.element_tickb"}'],Name:'{"translate":"pl.item.name.element_tick"}'},id:"panling:element_tick"} 5
#give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 20