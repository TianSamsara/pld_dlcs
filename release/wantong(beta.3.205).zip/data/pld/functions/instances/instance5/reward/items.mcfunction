data merge block 0 0 0 {Items:[]}
loot replace block 0 0 0 container.0 loot pld:items/instance5_collection
data modify block 0 0 0 Items[0].Count set value 2b
loot give @s mine 0 0 0 minecraft:diamond_pickaxe{isShulkerMarker:1b}

#loot give @s loot xsj:items/ticket3

give @s minecraft:iron_nugget{display:{Lore:['{"translate":"pl.lore.rare5"}','{"translate":"pl.item.lore.acore5a"}','{"translate":"pl.item.lore.acore5b"}'],Name:'{"translate":"pl.item.name.acore5"}'},id:"panling:armor_core_5",HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}]}
give @s minecraft:paper{CustomModelData:1,display:{Lore:['{"translate":"pl.item.lore.element_ticka"}','{"translate":"pl.item.lore.element_tickb"}'],Name:'{"translate":"pl.item.name.element_tick"}'},id:"panling:element_tick"} 25

#give @s minecraft:emerald{id:"panling:metal",display:{Name:'{"translate":"pl.item.name.metal"}'}} 20
#give @s minecraft:bone{id:"panling:wood",display:{Name:'{"translate":"pl.item.name.wood"}'}} 20
#give @s minecraft:string{id:"panling:water",display:{Name:'{"translate":"pl.item.name.water"}'}} 20
#give @s minecraft:blaze_rod{id:"panling:fire",display:{Name:'{"translate":"pl.item.name.fire"}'}} 20
#give @s minecraft:magma_cream{id:"panling:earth",display:{Name:'{"translate":"pl.item.name.earth"}'}} 20
