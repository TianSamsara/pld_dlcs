#scoreboard players set @s kirins 1
#loot replace block 0 -1 0 container.0 loot xsj:legend/shengwu/5
#data modify storage pld:system Temp_player_new_mails[0].attached_items append from block 0 -1 0 Items[0]
#function pld:system/chest_menu/screen/3_mails/get_mails/personal
