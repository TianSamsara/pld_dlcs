#输入 @s archer_damage_should *（1+0.05*lvl）

execute if score #finish first_wonderful_pld_load matches 0 run scoreboard players set #temp temp 5
execute if score #finish first_wonderful_pld_load matches 1 run scoreboard players set #temp temp 10
scoreboard players operation #temp temp *= @s weapon_skill_bow6_lvl
scoreboard players add #temp temp 100
scoreboard players operation @s archer_damage_should *= #temp temp
scoreboard players set #temp temp 100
scoreboard players operation @s archer_damage_should /= #temp temp