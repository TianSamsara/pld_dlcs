#核心处是核心、部位材料处是装备
execute if score #finish first_wonderful_pld_load matches 0 run function wonderful_pld:system/dz/dzlegend/main
execute if score #finish first_wonderful_pld_load matches 1 run function wonderful_pld:system/dz/dzlegend/main2

#如果有洗炼石
execute unless data block ~ ~ ~ Items[{Slot:5b}] if data block ~ ~ ~ {Items:[{Slot:0b,Count:1b,tag:{id:"panling:refine_stone_legend",slot:0}},{Slot:3b,tag:{rare:6,slot:0}}]} run function pld:system/dz/dzlegend/refine/main
execute unless data block ~ ~ ~ Items[{Slot:5b}] if data block ~ ~ ~ {Items:[{Slot:0b,Count:1b,tag:{id:"panling:refine_stone_legend",slot:1}},{Slot:3b,tag:{rare:6,slot:1}}]} run function pld:system/dz/dzlegend/refine/main
execute unless data block ~ ~ ~ Items[{Slot:5b}] if data block ~ ~ ~ {Items:[{Slot:0b,Count:1b,tag:{id:"panling:refine_stone_legend",slot:2}},{Slot:3b,tag:{rare:6,slot:2}}]} run function pld:system/dz/dzlegend/refine/main
execute unless data block ~ ~ ~ Items[{Slot:5b}] if data block ~ ~ ~ {Items:[{Slot:0b,Count:1b,tag:{id:"panling:refine_stone_legend",slot:3}},{Slot:3b,tag:{rare:6,slot:3}}]} run function pld:system/dz/dzlegend/refine/main

