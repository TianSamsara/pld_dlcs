# #system temp3 = slot
# limit=0
# element=0

#tellraw @p [{"text":"当前系统检测:","color":"green","bold": true},{"score": {"name": "#system","objective": "temp3"}}]
#tellraw @p [{"text":"当前系统检测:","color":"green","bold": true},{"score": {"name": "#xsj","objective": "temp"}}]
#tellraw @p [{"text":"当前系统检测:","color":"green","bold": true},{"score": {"name": "#xsj","objective": "temp3"}}]

execute if score #system temp3 matches 0 if score #xsj temp matches 0 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.helmet60.0"}'
execute if score #system temp3 matches 1 if score #xsj temp matches 0 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.chestplate60.0"}'
execute if score #system temp3 matches 2 if score #xsj temp matches 0 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.leggings60.0"}'
execute if score #system temp3 matches 3 if score #xsj temp matches 0 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.boots60.0"}'

#execute if score #system temp3 matches 1 if score #xsj temp matches 11..12 if score #xsj temp3 matches 0 run say 4

#execute if score #system temp3 matches 0 if score #xsj temp matches 11..12 unless score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run data modify storage pld:system dzTemp set value '{"translate":"dlc.lore.armor.balance.helmet.0"}'
#execute if score #system temp3 matches 1 if score #xsj temp matches 11..12 unless score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run data modify storage pld:system dzTemp set value '{"translate":"dlc.lore.armor.balance.chest.0"}'
#execute if score #system temp3 matches 2 if score #xsj temp matches 11..12 unless score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run data modify storage pld:system dzTemp set value '{"translate":"dlc.lore.armor.balance.legs.0"}'
#execute if score #system temp3 matches 3 if score #xsj temp matches 11..12 unless score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run data modify storage pld:system dzTemp set value '{"translate":"dlc.lore.armor.balance.boots.0"}'

#execute if score #system temp3 matches 0 if score #xsj temp3 matches 1 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.helmet6e.3"}'
execute if score #system temp3 matches 1 if score #xsj temp2 matches 1 if score #xsj temp3 matches 1 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.chestplate6e.3"}'

