# #system temp3 = slot
# limit=1
# element=0

execute if score #system temp3 matches 0 if score #xsj temp matches 0 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.helmet61.0"}'
execute if score #system temp3 matches 1 if score #xsj temp matches 0 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.chestplate61.0"}'
execute if score #system temp3 matches 2 if score #xsj temp matches 0 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.leggings61.0"}'
execute if score #system temp3 matches 3 if score #xsj temp matches 0 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.boots61.0"}'

#execute if score #system temp3 matches 0 if score #xsj temp matches 11..12 unless score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run data modify storage pld:system dzTemp set value '{"translate":"dlc.lore.armor.balance.helmet.1"}'
#execute if score #system temp3 matches 1 if score #xsj temp matches 11..12 unless score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run data modify storage pld:system dzTemp set value '{"translate":"dlc.lore.armor.balance.chest.1"}'
#execute if score #system temp3 matches 2 if score #xsj temp matches 11..12 unless score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run data modify storage pld:system dzTemp set value '{"translate":"dlc.lore.armor.balance.legs.1"}'
#execute if score #system temp3 matches 3 if score #xsj temp matches 11..12 unless score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run data modify storage pld:system dzTemp set value '{"translate":"dlc.lore.armor.balance.boots.1"}'

#execute if score #system temp3 matches 0 if score #xsj temp3 matches 1 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.helmet6e.3"}'
execute if score #system temp3 matches 2 if score #xsj temp2 matches 1 if score #xsj temp3 matches 2 run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.leggings6e.3"}'