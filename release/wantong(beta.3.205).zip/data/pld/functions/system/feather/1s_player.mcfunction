#tellraw wu_lonely {"text":"","extra":[{"text":"☯☯☯","color":"red"},{"selector":"@s","color":"yellow"},{"translate":"feather_mainland","color":"red"}]}

execute as @s[scores={feather_mainland=1}] run function pld:system/feather/main

function pld:system/feather/passive

#移除大陆速度属性
execute as @s[scores={feather_mainland=-1}] run attribute @s generic.movement_speed modifier remove 8-8-8-8-8
execute as @s unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4}}]}] run attribute @s generic.movement_speed modifier remove 8-8-8-8-9
execute as @s if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4}}]}] run attribute @s generic.movement_speed modifier remove 8-8-8-8-8
execute as @s unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather"}}]}] run attribute @s generic.movement_speed modifier remove 8-8-8-8-8

execute as @s unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather"}}]}] run scoreboard players set @s feather_lvl 0


