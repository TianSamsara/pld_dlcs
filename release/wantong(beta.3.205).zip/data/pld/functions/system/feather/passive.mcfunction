#移除被动属性
execute unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:1}}]}] unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6}}]}] run scoreboard players set @s archer_damage1_feather 0
execute unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:2}}]}] unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6}}]}] run scoreboard players set @s feather_zf_str 0
execute unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:3}}]}] unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6}}]}] run scoreboard players set @s attack_damage1_feather 0
execute unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:4}}]}] unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6}}]}] run attribute @s generic.max_health modifier remove 8-8-8-8-8
execute unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:5}}]}] unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6}}]}] run attribute @s generic.armor modifier remove 8-8-8-8-8

execute unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6}}]}] run attribute @s generic.armor_toughness modifier remove 8-8-8-8-8
execute unless entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6}}]}] run attribute @s generic.attack_damage modifier remove 8-8-8-8-8

#给予玩家被动属性
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:3,feather_lvl:0}}]}] run scoreboard players set @s attack_damage1_feather 15
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:1,feather_lvl:0}}]}] run scoreboard players set @s archer_damage1_feather 10
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:2,feather_lvl:0}}]}] run scoreboard players set @s feather_zf_str 10
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:4,feather_lvl:0}}]}] run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 2 add
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:5,feather_lvl:0}}]}] run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 2 add

execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:3,feather_lvl:1}}]}] run scoreboard players set @s attack_damage1_feather 30
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:1,feather_lvl:1}}]}] run scoreboard players set @s archer_damage1_feather 15
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:2,feather_lvl:1}}]}] run scoreboard players set @s feather_zf_str 15
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:4,feather_lvl:1}}]}] run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 4 add
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:5,feather_lvl:1}}]}] run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 2.5 add

execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:3,feather_lvl:2}}]}] run scoreboard players set @s attack_damage1_feather 45
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:1,feather_lvl:2}}]}] run scoreboard players set @s archer_damage1_feather 20
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:2,feather_lvl:2}}]}] run scoreboard players set @s feather_zf_str 20
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:4,feather_lvl:2}}]}] run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 6 add
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:5,feather_lvl:2}}]}] run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 3 add

execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:3,feather_lvl:3}}]}] run scoreboard players set @s attack_damage1_feather 60
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:1,feather_lvl:3}}]}] run scoreboard players set @s archer_damage1_feather 25
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:2,feather_lvl:3}}]}] run scoreboard players set @s feather_zf_str 25
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:4,feather_lvl:3}}]}] run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 8 add
execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:5,feather_lvl:3}}]}] run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 3.5 add

#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:3,feather_lvl:3}}]}] run scoreboard players set @s attack_damage1_feather 60
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:1,feather_lvl:3}}]}] run scoreboard players set @s archer_damage1_feather 25
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:2,feather_lvl:3}}]}] run scoreboard players set @s feather_zf_str 4
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:4,feather_lvl:3}}]}] run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 8 add
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:5,feather_lvl:3}}]}] run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 3.5 add

execute if score @s feather_lvl matches 1 run scoreboard players set @s attack_damage1_feather 75
execute if score @s feather_lvl matches 1 run scoreboard players set @s archer_damage1_feather 50
execute if score @s feather_lvl matches 1 run scoreboard players set @s feather_zf_str 50

execute if score @s feather_lvl matches 2 run scoreboard players set @s attack_damage1_feather 90
execute if score @s feather_lvl matches 2 run scoreboard players set @s archer_damage1_feather 60
execute if score @s feather_lvl matches 2 run scoreboard players set @s feather_zf_str 60
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6,feather-endlvl:1}}]}] run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 10 add
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6,feather-endlvl:1}}]}] run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 4 add

execute if score @s feather_lvl matches 3 run scoreboard players set @s attack_damage1_feather 120
execute if score @s feather_lvl matches 3 run scoreboard players set @s archer_damage1_feather 80
execute if score @s feather_lvl matches 3 run scoreboard players set @s feather_zf_str 80
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6,feather-endlvl:2}}]}] run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 10 add
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6,feather-endlvl:2}}]}] run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 4 add

execute if score @s feather_lvl matches 4 run scoreboard players set @s attack_damage1_feather 150
execute if score @s feather_lvl matches 4 run scoreboard players set @s archer_damage1_feather 100
execute if score @s feather_lvl matches 4 run scoreboard players set @s feather_zf_str 100
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6,feather-endlvl:3}}]}] run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 10 add
#execute if entity @s[nbt={Inventory:[{tag:{id:"panling:feather",lvl:4,brunch:6,feather-endlvl:3}}]}] run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 4 add

execute if score @s feather_lvl matches 1 run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 10 add
execute if score @s feather_lvl matches 2 run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 12 add
execute if score @s feather_lvl matches 3 run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 16 add
execute if score @s feather_lvl matches 4 run attribute @s generic.max_health modifier add 8-8-8-8-8 "羽毛被动-生命" 20 add

execute if score @s feather_lvl matches 1 run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 4 add
execute if score @s feather_lvl matches 2 run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 6 add
execute if score @s feather_lvl matches 3 run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 8 add
execute if score @s feather_lvl matches 4 run attribute @s generic.armor modifier add 8-8-8-8-8 "羽毛被动-盔甲" 10 add

execute if score @s feather_lvl matches 1 run attribute @s generic.armor_toughness modifier add 8-8-8-8-8 "羽毛被动-盔甲韧性" 1 add
execute if score @s feather_lvl matches 2 run attribute @s generic.armor_toughness modifier add 8-8-8-8-8 "羽毛被动-盔甲韧性" 2 add
execute if score @s feather_lvl matches 3 run attribute @s generic.armor_toughness modifier add 8-8-8-8-8 "羽毛被动-盔甲韧性" 3 add
execute if score @s feather_lvl matches 4 run attribute @s generic.armor_toughness modifier add 8-8-8-8-8 "羽毛被动-盔甲韧性" 4 add

#-########################################################################################################################################
#execute if entity @s if score @s WeaponSlot1 matches 1 unless predicate pld:effect_check/regeneration run effect give @s regeneration 5 1
#execute if entity @s if score @s WeaponSlot1 matches 1 if score @s hp_precent <= #system 40 run effect give @s resistance 5 1

#execute if entity @s if score @s WeaponSlot1 matches 1 if entity @a[distance=..6] unless predicate pld:effect_check/resistance run effect give @s resistance 5 0

#execute if entity @s if score @s WeaponSlot1 matches 1 if score @s hp_precent >= #system 75 run effect give @e[distance=..6,tag=monster] slowness 5 1

#execute if entity @s if score @s WeaponSlot2 matches 1 run effect give @s absorption infinite 3
