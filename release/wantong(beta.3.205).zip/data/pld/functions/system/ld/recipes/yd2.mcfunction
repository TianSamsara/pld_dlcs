#洛神丹 -yd2

#万通
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 2 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:string",Count:8b,tag:{id:"panling:water"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:10b,tag:{id:"panling:yd2",CustomPotionColor:2039713,CustomPotionEffects:[{Id:29b,Amplifier:0b,Duration:12000},{Id:30b,Amplifier:0b,Duration:12000}],display:{Name:'{"translate":"pl.item.potion.yd2"}'}}}]}

#原版
execute unless score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 2 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:string",Count:10b,tag:{id:"panling:water"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:10b,tag:{id:"panling:yd2",CustomPotionColor:2039713,CustomPotionEffects:[{Id:29b,Amplifier:0b,Duration:12000},{Id:30b,Amplifier:0b,Duration:12000}],display:{Name:'{"translate":"pl.item.potion.yd2"}'}}}]}
