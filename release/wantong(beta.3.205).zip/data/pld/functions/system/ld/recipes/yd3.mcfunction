#混元一气丹 -yd3

#万通

#初级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 2 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:magma_cream",Count:12b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:2b,tag:{id:"panling:yd3",lvl:1,CustomPotionColor:14270531,CustomPotionEffects:[{Id:11b,Amplifier:0b,Duration:18000},{Id:12b,Amplifier:0b,Duration:18000},{Id:22b,Amplifier:0b,Duration:18000},],display:{Name:'{"translate":"pl.item.potion.yd31"}'}}}]}
#中级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 2 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy2"}},{Slot:1b,id:"minecraft:magma_cream",Count:24b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:3b,tag:{id:"panling:yd3",lvl:2,CustomPotionColor:14270531,CustomPotionEffects:[{Id:11b,Amplifier:0b,Duration:24000},{Id:12b,Amplifier:0b,Duration:24000},{Id:22b,Amplifier:0b,Duration:24000},],display:{Name:'{"translate":"pl.item.potion.yd32"}'}}}]}
#高级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 2 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy3"}},{Slot:1b,id:"minecraft:magma_cream",Count:48b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:5b,tag:{id:"panling:yd3",lvl:3,CustomPotionColor:14270531,CustomPotionEffects:[{Id:11b,Amplifier:0b,Duration:30000},{Id:12b,Amplifier:0b,Duration:30000},{Id:22b,Amplifier:0b,Duration:30000},],display:{Name:'{"translate":"pl.item.potion.yd33"}'}}}]}

execute if score #finish first_xsj_load matches 1 run return 0

#原版

#初级
execute if score @p[tag=ld_tag] ld_count matches 2 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:magma_cream",Count:15b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:2b,tag:{id:"panling:yd3",lvl:1,CustomPotionColor:14270531,CustomPotionEffects:[{Id:11b,Amplifier:0b,Duration:18000},{Id:12b,Amplifier:0b,Duration:18000},{Id:22b,Amplifier:0b,Duration:18000},],display:{Name:'{"translate":"pl.item.potion.yd31"}'}}}]}
#中级
execute if score @p[tag=ld_tag] ld_count matches 2 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy2"}},{Slot:1b,id:"minecraft:magma_cream",Count:30b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:3b,tag:{id:"panling:yd3",lvl:2,CustomPotionColor:14270531,CustomPotionEffects:[{Id:11b,Amplifier:0b,Duration:24000},{Id:12b,Amplifier:0b,Duration:24000},{Id:22b,Amplifier:0b,Duration:24000},],display:{Name:'{"translate":"pl.item.potion.yd32"}'}}}]}
#高级
execute if score @p[tag=ld_tag] ld_count matches 2 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy3"}},{Slot:1b,id:"minecraft:magma_cream",Count:45b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:3b,tag:{id:"panling:yd3",lvl:3,CustomPotionColor:14270531,CustomPotionEffects:[{Id:11b,Amplifier:0b,Duration:30000},{Id:12b,Amplifier:0b,Duration:30000},{Id:22b,Amplifier:0b,Duration:30000},],display:{Name:'{"translate":"pl.item.potion.yd33"}'}}}]}
