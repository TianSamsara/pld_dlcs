#辟谷丹 -yd4

#万通

#初级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:bone",Count:8b,tag:{id:"panling:wood"}},{Slot:2b,id:"minecraft:magma_cream",Count:8b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:5b,tag:{id:"panling:yd4",lvl:1,CustomPotionColor:16262179,CustomPotionEffects:[{Id:20b,Amplifier:0b,Duration:1200},{Id:23b,Amplifier:1b,Duration:1}],display:{Name:'{"translate":"pl.item.potion.yd41"}'}}}]}
#中级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy2"}},{Slot:1b,id:"minecraft:bone",Count:16b,tag:{id:"panling:wood"}},{Slot:2b,id:"minecraft:magma_cream",Count:16b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:20b,tag:{id:"panling:yd4",lvl:2,CustomPotionColor:16262179,CustomPotionEffects:[{Id:10b,Amplifier:1b,Duration:1200},{Id:23b,Amplifier:5b,Duration:1}],display:{Name:'{"translate":"pl.item.potion.yd42"}'}}}]}
#高级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy3"}},{Slot:1b,id:"minecraft:bone",Count:32b,tag:{id:"panling:wood"}},{Slot:2b,id:"minecraft:magma_cream",Count:32b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:20b,tag:{id:"panling:yd4",lvl:3,CustomPotionColor:16262179,CustomPotionEffects:[{Id:10b,Amplifier:1b,Duration:1200},{Id:23b,Amplifier:9b,Duration:1}],display:{Name:'{"translate":"pl.item.potion.yd43"}'}}}]}

execute if score #finish first_xsj_load matches 1 run return 0

#原版

#初级
execute if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:bone",Count:5b,tag:{id:"panling:wood"}},{Slot:2b,id:"minecraft:magma_cream",Count:5b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:2b,tag:{id:"panling:yd4",lvl:1,CustomPotionColor:16262179,CustomPotionEffects:[{Id:10b,Amplifier:0b,Duration:1200},{Id:23b,Amplifier:1b,Duration:1}],display:{Name:'{"translate":"pl.item.potion.yd41"}'}}}]}
#中级
execute if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy2"}},{Slot:1b,id:"minecraft:bone",Count:10b,tag:{id:"panling:wood"}},{Slot:2b,id:"minecraft:magma_cream",Count:10b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:5b,tag:{id:"panling:yd4",lvl:2,CustomPotionColor:16262179,CustomPotionEffects:[{Id:10b,Amplifier:1b,Duration:1200},{Id:23b,Amplifier:5b,Duration:1}],display:{Name:'{"translate":"pl.item.potion.yd42"}'}}}]}
#高级
execute if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy3"}},{Slot:1b,id:"minecraft:bone",Count:15b,tag:{id:"panling:wood"}},{Slot:2b,id:"minecraft:magma_cream",Count:15b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:8b,tag:{id:"panling:yd4",lvl:3,CustomPotionColor:16262179,CustomPotionEffects:[{Id:10b,Amplifier:1b,Duration:1200},{Id:23b,Amplifier:9b,Duration:1}],display:{Name:'{"translate":"pl.item.potion.yd43"}'}}}]}
