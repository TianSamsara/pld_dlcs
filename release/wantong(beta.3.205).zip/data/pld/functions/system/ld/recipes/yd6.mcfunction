#玄甲丹 -yd6

#万通

#初级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:emerald",Count:8b,tag:{id:"panling:metal"}},{Slot:2b,id:"minecraft:magma_cream",Count:8b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:5b,tag:{id:"panling:yd6",lvl:1,CustomPotionColor:10044730,CustomPotionEffects:[{Id:11b,Amplifier:0b,Duration:600},{Id:22b,Amplifier:1b,Duration:18000},{Id:2b,Amplifier:0b,Duration:600}],display:{Name:'{"translate":"pl.item.potion.yd61"}'}}}]}
#中级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy2"}},{Slot:1b,id:"minecraft:emerald",Count:16b,tag:{id:"panling:metal"}},{Slot:2b,id:"minecraft:magma_cream",Count:16b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:10b,tag:{id:"panling:yd6",lvl:2,CustomPotionColor:10044730,CustomPotionEffects:[{Id:11b,Amplifier:1b,Duration:600},{Id:22b,Amplifier:2b,Duration:18000},{Id:2b,Amplifier:1b,Duration:600}],display:{Name:'{"translate":"pl.item.potion.yd62"}'}}}]}
#高级
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy3"}},{Slot:1b,id:"minecraft:emerald",Count:32b,tag:{id:"panling:metal"}},{Slot:2b,id:"minecraft:magma_cream",Count:32b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:10b,tag:{id:"panling:yd6",lvl:3,CustomPotionColor:10044730,CustomPotionEffects:[{Id:11b,Amplifier:2b,Duration:600},{Id:22b,Amplifier:3b,Duration:18000},{Id:2b,Amplifier:2b,Duration:600}],display:{Name:'{"translate":"pl.item.potion.yd63"}'}}}]}

execute if score #finish first_xsj_load matches 1 run return 0

#原版

#初级
execute if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:emerald",Count:5b,tag:{id:"panling:metal"}},{Slot:2b,id:"minecraft:magma_cream",Count:5b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:8b,tag:{id:"panling:yd6",lvl:1,CustomPotionColor:10044730,CustomPotionEffects:[{Id:11b,Amplifier:1b,Duration:600},{Id:22b,Amplifier:1b,Duration:18000},{Id:2b,Amplifier:0b,Duration:600}],display:{Name:'{"translate":"pl.item.potion.yd61"}'}}}]}
#中级
execute if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy2"}},{Slot:1b,id:"minecraft:emerald",Count:10b,tag:{id:"panling:metal"}},{Slot:2b,id:"minecraft:magma_cream",Count:10b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:12b,tag:{id:"panling:yd6",lvl:2,CustomPotionColor:10044730,CustomPotionEffects:[{Id:11b,Amplifier:2b,Duration:600},{Id:22b,Amplifier:2b,Duration:18000},{Id:2b,Amplifier:1b,Duration:600}],display:{Name:'{"translate":"pl.item.potion.yd62"}'}}}]}
#高级
execute if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy3"}},{Slot:1b,id:"minecraft:emerald",Count:15b,tag:{id:"panling:metal"}},{Slot:2b,id:"minecraft:magma_cream",Count:15b,tag:{id:"panling:earth"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:15b,tag:{id:"panling:yd6",lvl:3,CustomPotionColor:10044730,CustomPotionEffects:[{Id:11b,Amplifier:3b,Duration:600},{Id:22b,Amplifier:3b,Duration:18000},{Id:2b,Amplifier:2b,Duration:600}],display:{Name:'{"translate":"pl.item.potion.yd63"}'}}}]}
