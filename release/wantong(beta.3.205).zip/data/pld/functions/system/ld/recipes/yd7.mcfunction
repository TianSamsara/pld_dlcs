#万灵丹 -yd7

#万通
execute if score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:emerald",Count:4b,tag:{id:"panling:metal"}},{Slot:2b,id:"minecraft:bone",Count:4b,tag:{id:"panling:wood"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:10b,tag:{id:"panling:yd7",CustomPotionColor:2293580,CustomPotionEffects:[{Id:8b,Amplifier:1b,Duration:12000},{Id:28b,Amplifier:0b,Duration:12000}],display:{Name:'{"translate":"pl.item.potion.yd7"}'}}}]}

#原版
execute unless score #finish first_xsj_load matches 1 if score @p[tag=ld_tag] ld_count matches 3 if block ~ ~ ~ minecraft:hopper{Items:[{Slot:0b,id:"minecraft:poisonous_potato",Count:1b,tag:{id:"panling:yy1"}},{Slot:1b,id:"minecraft:emerald",Count:5b,tag:{id:"panling:metal"}},{Slot:2b,id:"minecraft:bone",Count:5b,tag:{id:"panling:wood"}}]} run data merge block ~ ~ ~ {Items:[{Slot:2b,id:"minecraft:potion",Count:10b,tag:{id:"panling:yd7",CustomPotionColor:2293580,CustomPotionEffects:[{Id:8b,Amplifier:1b,Duration:12000},{Id:28b,Amplifier:0b,Duration:12000}],display:{Name:'{"translate":"pl.item.potion.yd7"}'}}}]}
