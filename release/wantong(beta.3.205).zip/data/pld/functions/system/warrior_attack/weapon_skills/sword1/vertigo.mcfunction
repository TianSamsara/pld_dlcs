execute if score #finish first_wonderful_pld_load matches 0 run scoreboard players set @s vertigo_5ticks 10
execute if score #finish first_wonderful_pld_load matches 1 run scoreboard players set @s vertigo_5ticks 20
data merge entity @s {NoAI:1b}
