execute if score @s zf_cool_again_earth matches 0.. run function xsj:system/zf/zf_cool_again/5

execute unless score @s zf_cool_again_earth matches 0.. run function pld:system/zf/shifang/main/again_refined/again_refined_earth_main
