execute if score @s zf_cool_again_fire matches 0.. run function xsj:system/zf/zf_cool_again/4

execute unless score @s zf_cool_again_fire matches 0.. run function xsj:system/zf/shifang/main/again_refined/element/fire/again_fire
execute unless score @s zf_cool_again_fire matches 0.. run function xsj:system/zf/shifang/main/again_refined/again_refined_fire_main

execute unless score @s zf_cool_again_fire matches 0.. run function pld:system/zf/shifang/main/again_refined/again_refined_fire_main
