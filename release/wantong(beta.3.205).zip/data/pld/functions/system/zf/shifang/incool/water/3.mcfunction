execute if score @s zf_cool_again_water matches 0.. run function xsj:system/zf/zf_cool_again/2


execute unless score @s zf_cool_again_water matches 0.. run function xsj:system/zf/shifang/main/again_refined/again_refined_water_main

execute unless score @s zf_cool_again_water matches 0.. run function pld:system/zf/shifang/main/again_refined/again_refined_water_main
