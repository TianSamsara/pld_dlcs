execute if score @s zf_cool_again_wood matches 0.. run function xsj:system/zf/zf_cool_again/3

execute unless score @s zf_cool_again_wood matches 0.. run function xsj:system/zf/shifang/main/again_refined/element/wood/again_wood

execute unless score @s zf_cool_again_wood matches 0.. run function pld:system/zf/shifang/main/again_refined/again_refined_wood_main
