execute unless score #finish first_wonderful_pld_load matches 1 run return 0

# 弓箭手附灵等级限制解除（最终生效）

# 1-2
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:1,enchant_lvl:2,limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments[{id:"minecraft:protection"}].lvl set value 2s
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:1,enchant_lvl:2,limit:1}}]} run scoreboard players add @s equipment_all_protection_multiply_base 4
# 1-3
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:1,enchant_lvl:3,limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments[{id:"minecraft:protection"}].lvl set value 3s
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:1,enchant_lvl:3,limit:1}}]} run scoreboard players add @s equipment_all_protection_multiply_base 8

# 2-2
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:2,enchant_lvl:2,limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments[{id:"fire_protection"}].lvl set value 3
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:2,enchant_lvl:2,limit:1}}]} run scoreboard players add @s equipment_fire_protection_multiply_base 8
# 2-3
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:2,enchant_lvl:3,limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments[{id:"fire_protection"}].lvl set value 4
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:2,enchant_lvl:3,limit:1}}]} run scoreboard players add @s equipment_fire_protection_multiply_base 16

# 3-2
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:3,enchant_lvl:2,limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments[{id:"projectile_protection"}].lvl set value 2
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:3,enchant_lvl:2,limit:1}}]} run scoreboard players add @s equipment_arrow_protection_multiply_base 8
# 3-3
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:3,enchant_lvl:3,limit:1}}]} run data modify block ~ 255 ~ Items[0].tag.Enchantments[{id:"projectile_protection"}].lvl set value 3
execute if block ~ 255 ~ chest{Items:[{Slot:0b,tag:{enchant_id:3,enchant_lvl:3,limit:1}}]} run scoreboard players add @s equipment_arrow_protection_multiply_base 16
