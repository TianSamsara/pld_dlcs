#根据等级区分下一级

execute if score #temp temp matches 2 run function wonderful_pld:system/dz/dzslot/element/2/2
execute if score #temp temp matches 3 run function wonderful_pld:system/dz/dzslot/element/2/3
execute if score #temp temp matches 4 run function wonderful_pld:system/dz/dzslot/element/2/4
execute if score #temp temp matches 5 run function wonderful_pld:system/dz/dzslot/element/2/5
