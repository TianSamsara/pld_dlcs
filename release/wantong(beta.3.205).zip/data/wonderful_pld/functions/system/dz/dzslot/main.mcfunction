#判定通过，按照limit rare element slot 给出枚举结果
#limit slot Slot:6b tag给出
#element Slot:0b tag.id给出
#rare 记分板#temp temp给出


#根据元素区分5个分支
execute if score #temp temp4 matches 0 run function pld:system/dz/dzslot/element/metal
execute if score #temp temp4 matches 1 run function pld:system/dz/dzslot/element/wood
execute if score #temp temp4 matches 2 run function pld:system/dz/dzslot/element/water
execute if score #temp temp4 matches 3 run function pld:system/dz/dzslot/element/fire
execute if score #temp temp4 matches 4 run function pld:system/dz/dzslot/element/earth






#execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:6b,id:"minecraft:glowstone_dust",Count:1b,tag:{id:"panling:material_helmet"}}]} run function pld:system/dz/dzslot/dzhelmet
#execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:6b,id:"minecraft:glowstone_dust",Count:1b,tag:{id:"panling:material_chestplate"}}]} run function pld:system/dz/dzslot/dzchestplate
#execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:6b,id:"minecraft:glowstone_dust",Count:1b,tag:{id:"panling:material_leggings"}}]} run function pld:system/dz/dzslot/dzleggings
#execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:6b,id:"minecraft:glowstone_dust",Count:1b,tag:{id:"panling:material_boots"}}]} run function pld:system/dz/dzslot/dzboots

