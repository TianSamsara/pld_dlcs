

#根据种族以及补给情况发放邮件
execute unless score @s race matches 0 if score @s supply_add_shen matches 1 run function wonderful_pld:system/supply/mails/0/normal
execute unless score @s race matches 1 if score @s supply_add_yao matches 1 run function wonderful_pld:system/supply/mails/1/normal
execute unless score @s race matches 2 if score @s supply_add_xian matches 1 run function wonderful_pld:system/supply/mails/2/normal
execute unless score @s race matches 3 if score @s supply_add_zhan matches 1 run function wonderful_pld:system/supply/mails/3/normal
execute unless score @s race matches 4 if score @s supply_add_ren matches 1 run function wonderful_pld:system/supply/mails/4/normal




#scoreboard players set @s supply5ticks 36000

