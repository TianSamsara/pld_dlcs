#===========================不消耗率 百分比提升===========================#

execute if score #finish first_wonderful_pld_load matches 1 run scoreboard players operation @s zf_consume_reduce += 20 percent
