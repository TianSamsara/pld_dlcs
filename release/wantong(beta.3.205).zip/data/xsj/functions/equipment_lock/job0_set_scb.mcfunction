
execute if data entity @s Inventory[{tag:{act:1,id:"panling:axe56"}}] run scoreboard players set @s weapon_rare 7
execute if data entity @s Inventory[{tag:{act:1,id:"panling:sword56"}}] run scoreboard players set @s weapon_rare 7

execute if data entity @s Inventory[{tag:{act:1,id:"panling:axe56"}}] run scoreboard players set @s weapon_branch 0
execute if data entity @s Inventory[{tag:{act:1,id:"panling:sword56"}}] run scoreboard players set @s weapon_branch 1

execute if data entity @s Inventory[{tag:{act:1,id:"panling:axe6"}}] run scoreboard players set @s weapon_rare 6
execute if data entity @s Inventory[{tag:{act:1,id:"panling:axe6"}}] run scoreboard players set @s weapon_branch 1
