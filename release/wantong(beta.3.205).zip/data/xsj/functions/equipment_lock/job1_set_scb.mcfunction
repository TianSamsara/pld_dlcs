
execute if data entity @s Inventory[{tag:{act:1,id:"panling:bow56"}}] run scoreboard players set @s weapon_rare 7
execute if data entity @s Inventory[{tag:{act:1,id:"panling:crossbow56"}}] run scoreboard players set @s weapon_rare 7

execute if data entity @s Inventory[{tag:{act:1,id:"panling:bow56"}}] run scoreboard players set @s weapon_branch 0
execute if data entity @s Inventory[{tag:{act:1,id:"panling:crossbow56"}}] run scoreboard players set @s weapon_branch 1

