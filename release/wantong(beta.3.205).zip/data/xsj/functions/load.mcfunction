function xsj:qiankun/load
function xsj:system/weapon_skills/load
function xsj:system/fab/load
function xsj:system/zf/load
#function xsj:system/tick

scoreboard players set 1 percent 1
scoreboard players set 2 percent 2
scoreboard players set 3 percent 3
scoreboard players set 4 percent 4
scoreboard players set 5 percent 5

scoreboard players set 10 percent 10
scoreboard players set 15 percent 15
scoreboard players set 20 percent 20
scoreboard players set 25 percent 25
scoreboard players set 30 percent 30
scoreboard players set 35 percent 35
scoreboard players set 45 percent 45
scoreboard players set 50 percent 50
scoreboard players set 60 percent 60
scoreboard players set 75 percent 75
scoreboard players set 80 percent 80
scoreboard players set 90 percent 90

scoreboard players set 16 percent 16
scoreboard players set 32 percent 32
scoreboard players set 64 percent 64
scoreboard players set 128 percent 128
scoreboard players set 256 percent 256
scoreboard players set 384 percent 384
scoreboard players set 768 percent 768
scoreboard players set 1024 percent 1024
scoreboard players set 1536 percent 1536
scoreboard players set 2048 percent 2048
scoreboard players set 3072 percent 3072
scoreboard players set 6144 percent 6144

scoreboard players set 100 percent 100
scoreboard players set 110 percent 110
scoreboard players set 120 percent 120
scoreboard players set 150 percent 150
scoreboard players set 200 percent 200
scoreboard players set 250 percent 250
scoreboard players set 300 percent 300
scoreboard players set 350 percent 350
scoreboard players set 400 percent 400
scoreboard players set 450 percent 450
scoreboard players set 500 percent 500
scoreboard players set 550 percent 550
scoreboard players set 600 percent 600
scoreboard players set 700 percent 700
scoreboard players set 750 percent 750
scoreboard players set 800 percent 800
scoreboard players set 900 percent 900
scoreboard players set 1000 percent 1000
scoreboard players set 1250 percent 1250
scoreboard players set 1500 percent 1500
scoreboard players set 1750 percent 1750
scoreboard players set 2000 percent 2000

scoreboard objectives add instance3_8f dummy ["镇妖塔是否通过第八层"]
scoreboard objectives add ldjl dummy ["精炼元素记录标记"]







