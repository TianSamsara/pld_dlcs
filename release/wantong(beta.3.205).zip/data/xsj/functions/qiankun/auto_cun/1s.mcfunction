execute if score @s qiankundai_main matches 1 if score @s auto_cunchu matches 1 run function xsj:qiankun/auto_cun/auto_cun
execute if score @s qiankundai_main matches 1 if score @s auto_cunchu matches 2 run function xsj:qiankun/auto_cun/auto_cun3
execute if score @s qiankundai_main matches 1 if score @s auto_cunchu matches 3 run function xsj:qiankun/auto_cun/auto_cun4

execute if score #system element_dlc_optional1 matches 1.. unless score @s element_dlc_optional1 matches 1.. run function xsj:qiankun/auto_cun/set


execute if entity @s[advancements={xsj:crafting/dz1=true}] run advancement revoke @s only pld:mission/ren/main/feather

execute if entity @s[advancements={xsj:crafting/dz1=true}] run advancement revoke @s only pld:mission/ren/main/feather
#schedule function xsj:qiankun/auto_cun/1s 1s