function xsj:qiankun/cun/metal
function xsj:qiankun/cun/wood
function xsj:qiankun/cun/water
function xsj:qiankun/cun/fire
function xsj:qiankun/cun/earth
#function xsj:/qiankun/cun/element_tick
#function xsj:/qiankun/cun/relive_stone