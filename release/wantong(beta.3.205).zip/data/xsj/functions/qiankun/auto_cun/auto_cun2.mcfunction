#function xsj:/qiankun/cun/element_tick
function xsj:qiankun/cun/q_silver_ticket
function xsj:qiankun/cun/q_copper_cash
function xsj:qiankun/cun/q_gold_ingot
#function xsj:/qiankun/cun/relive_stone