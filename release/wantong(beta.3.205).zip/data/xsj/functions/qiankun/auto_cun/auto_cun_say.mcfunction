#开关
scoreboard players add @s auto_cunchu 1
execute if score @s auto_cunchu matches 4 run scoreboard players set @s auto_cunchu 0

#喊话
execute if score @s auto_cunchu matches 3 run tellraw @s [{"translate":"dlc.qkd.yuansu_cun.5.4"}]
execute if score @s auto_cunchu matches 2 run tellraw @s [{"translate":"dlc.qkd.yuansu_cun.5.3"}]
execute if score @s auto_cunchu matches 1 run tellraw @s [{"translate":"dlc.qkd.yuansu_cun.5.2"}]
execute if score @s auto_cunchu matches 0 run tellraw @s [{"translate":"dlc.qkd.yuansu_cun.5.1"}]

scoreboard players reset @s auto_cunchu_choose