execute if score @s element_dlc_optional1 matches 1.. run return 1

execute if score @s yuansu_count matches 1.. run scoreboard players operation @s element_number_total += @s yuansu_count

scoreboard players set @s element_dlc_optional1 1

#schedule function xsj:qiankun/auto_cun/1s 1s