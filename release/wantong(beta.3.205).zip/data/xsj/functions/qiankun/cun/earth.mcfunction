
execute store result score @s cunchu_middle run clear @s magma_cream{id:"panling:earth"}
scoreboard players operation @s element_number_total += @s cunchu_middle
scoreboard players reset @s cunchu_middle