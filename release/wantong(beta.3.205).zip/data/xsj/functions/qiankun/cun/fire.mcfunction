
execute store result score @s cunchu_middle run clear @s blaze_rod{id:"panling:fire"}
scoreboard players operation @s element_number_total += @s cunchu_middle
scoreboard players reset @s cunchu_middle