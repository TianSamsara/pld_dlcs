execute store result score @s cunchu_middle_t run clear @s gold_nugget{id:"panling:copper_cash"}
scoreboard players operation @s yinpiao_count += @s cunchu_middle_t
scoreboard players reset @s cunchu_middle_t