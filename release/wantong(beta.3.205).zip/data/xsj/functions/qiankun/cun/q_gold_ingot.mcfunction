execute store result score @s cunchu_middle_b run clear @s gold_ingot{id:"panling:gold_ingot"}
scoreboard players operation @s cunchu_middle_b *= 10 percent
scoreboard players operation @s yinpiao_count += @s cunchu_middle_b
scoreboard players reset @s cunchu_middle_b
