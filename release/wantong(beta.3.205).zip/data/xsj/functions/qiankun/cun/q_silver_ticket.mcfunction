execute store result score @s cunchu_middle_p run clear @s iron_ingot{id:"panling:silver_ticket"}
scoreboard players operation @s cunchu_middle_p *= 100 percent
scoreboard players operation @s yinpiao_count += @s cunchu_middle_p
scoreboard players reset @s cunchu_middle_p