execute store result score @s cunchu_middle_t run clear @s paper{id:"panling:vantone_tick"}
scoreboard players operation @s vantone_tick_count += @s cunchu_middle_t
scoreboard players reset @s cunchu_middle_t