
execute store result score @s cunchu_middle run clear @s bone{id:"panling:wood"}
scoreboard players operation @s element_number_total += @s cunchu_middle
scoreboard players reset @s cunchu_middle