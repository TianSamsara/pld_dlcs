#给予乾坤袋的使用

#scoreboard players enable @s yuansu_metal
#scoreboard players enable @s yuansu_wood 
#scoreboard players enable @s yuansu_water
#scoreboard players enable @s yuansu_fire 
#scoreboard players enable @s yuansu_earth
#scoreboard players enable @s yuansu_quan
#scoreboard players enable @s relive_stone
#scoreboard players enable @s wupin_cun

execute if score @s qiankundai_main matches 1.. if score @s qiankundai matches 1.. run scoreboard players set @s ldl6success 0

execute if score @s ldl6success matches 0 run function xsj:qiankun/l6_check2

execute if score #system element_dlc_optional1 matches 1.. run function xsj:qiankun/yuansutb