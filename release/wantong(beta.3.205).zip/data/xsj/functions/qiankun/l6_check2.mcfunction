#给予乾坤袋的使用

#scoreboard players enable @s yuansu_metal
#scoreboard players enable @s yuansu_wood 
#scoreboard players enable @s yuansu_water
#scoreboard players enable @s yuansu_fire 
#scoreboard players enable @s yuansu_earth
#scoreboard players enable @s yuansu_quan
#scoreboard players enable @s relive_stone
#scoreboard players enable @s wupin_cun
#成功
execute if score @s yuansu_lvl matches 1 if score @s element_number_total matches 1.. run scoreboard players remove @s element_number_total 1

execute if score @s yuansu_lvl matches 2 unless score @s ldjl matches 1 if score @s element_number_total matches 5.. run scoreboard players remove @s element_number_total 5
execute if score @s yuansu_lvl matches 2 if score @s ldjl matches 1 if score @s element_number_total matches 4.. run scoreboard players remove @s element_number_total 4

execute if score @s yuansu_lvl matches 3 unless score @s ldjl matches 1 if score @s element_number_total matches 40.. run scoreboard players remove @s element_number_total 40
execute if score @s yuansu_lvl matches 3 if score @s ldjl matches 1 if score @s element_number_total matches 32.. run scoreboard players remove @s element_number_total 32

#失败
execute if score @s yuansu_lvl matches 1 unless score @s element_number_total matches 1.. run scoreboard players set @s ldl6success 1

execute if score @s yuansu_lvl matches 2 unless score @s ldjl matches 1 unless score @s element_number_total matches 5.. run scoreboard players set @s ldl6success 1
execute if score @s yuansu_lvl matches 2 if score @s ldjl matches 1 unless score @s element_number_total matches 4.. run scoreboard players set @s ldl6success 1

execute if score @s yuansu_lvl matches 3 unless score @s ldjl matches 1 unless score @s element_number_total matches 40.. run scoreboard players set @s ldl6success 1
execute if score @s yuansu_lvl matches 3 if score @s ldjl matches 1 unless score @s element_number_total matches 32.. run scoreboard players set @s ldl6success 1


execute if score @s ldl6success matches 0 run tellraw @s [{"text": "你当前剩余","color": "green"},{"score":{"name": "@s","objective": "element_number_total"},"color": "yellow"},{"text": "个元素","color": "green"}]
