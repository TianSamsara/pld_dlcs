#绑定
scoreboard objectives add qiankundai dummy ["乾坤袋"]
scoreboard objectives add qiankundai_main dummy ["乾坤袋携带"]
#对话选择
scoreboard objectives add cunchu_middle dummy ["存储转换"]
scoreboard objectives add cunchu_middle_t dummy ["存储转换1"]
scoreboard objectives add cunchu_middle_b dummy ["存储转换2"]
scoreboard objectives add cunchu_middle_p dummy ["存储转换3"]
scoreboard objectives add wupin_look trigger ["查看余额"]

scoreboard objectives add yuansu_lvl dummy ["取出元素等级"]

#scoreboard objectives add relive_stone trigger ["取出重生石"]
#scoreboard objectives add yuansu_metal trigger ["取出元素"]
#scoreboard objectives add yuansu_wood trigger ["取出木元素"]
#scoreboard objectives add yuansu_water trigger ["取出水元素"]
#scoreboard objectives add yuansu_fire trigger ["取出火元素"]
#scoreboard objectives add yuansu_earth trigger ["取出土元素"]
#scoreboard objectives add yuansu_quan trigger ["取出元素兑换券"]

scoreboard objectives add element_number_total dummy "通用元素储存量"
scoreboard objectives add element_dlc_optional1 dummy "便捷元素银行-附加功能1-无损转化"

scoreboard objectives add yuansu_out trigger ["乾坤袋接口"]
scoreboard objectives add yinpiao_out trigger ["取出银票"]

scoreboard objectives add refined_yuansu_out1 trigger ["元素转换中间量1"]
scoreboard objectives add refined_yuansu_out2 trigger ["元素转换中间量2"]

scoreboard objectives add yuansu dummy ["元素转换中间量"]
scoreboard objectives add yinpiao dummy ["银票转换中间量"]
scoreboard objectives add yinpiao_main dummy ["银票执行检测"]

#存储数量
scoreboard objectives add element_number_total dummy ["元素存储数量"]
scoreboard objectives add yinpiao_count dummy ["银票存储数量"]
scoreboard objectives add vantone_tick_count dummy ["万通存储数量"]
#scoreboard objectives add relive_stone_count dummy ["重生石数量"]

#自动存储
scoreboard objectives add auto_cunchu_choose trigger ["自动存储模式选项"]
scoreboard objectives add auto_cunchu dummy ["自动存储模式"]

#scoreboard objectives add 64 dummy
#scoreboard players set 64 percent 64

scoreboard players set 1 percent 1
scoreboard players set 10 percent 10
scoreboard players set 64 percent 64
scoreboard players set 100 percent 100