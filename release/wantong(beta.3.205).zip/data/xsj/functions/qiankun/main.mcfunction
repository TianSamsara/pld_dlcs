#给予乾坤袋的使用

#scoreboard players enable @s yuansu_metal
#scoreboard players enable @s yuansu_wood 
#scoreboard players enable @s yuansu_water
#scoreboard players enable @s yuansu_fire 
#scoreboard players enable @s yuansu_earth
#scoreboard players enable @s yuansu_quan
#scoreboard players enable @s relive_stone
#scoreboard players enable @s wupin_cun
scoreboard players set @s qiankundai_main 0
execute store result score @s qiankundai_main run clear @s written_book{id:"dlc:qiankun_dai"} 0
execute unless score @s qiankundai_main matches 1.. run return 0

scoreboard players enable @s yuansu_out
scoreboard players enable @s yinpiao_out

scoreboard players enable @s wupin_look
scoreboard players enable @s auto_cunchu_choose

#scoreboard players set @s qiankundai_main 1

#乾坤袋给予物品检测
execute if score @s qiankundai_main matches 1 as @s run function xsj:qiankun/tick