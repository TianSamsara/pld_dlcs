

execute if score @s auto_cunchu matches 1.. run function xsj:qiankun/qu_main/main_say

execute if score @s yuansu_out matches 11..15 if score @s element_number_total matches ..63 run tellraw @s [{"text": "当前剩余元素不足一组","color": "red"},{"text": "无法取出","color": "red"}]
execute if score @s yuansu_out matches 11..15 unless score @s element_number_total matches ..63 run function xsj:qiankun/qu_main/main_yuansu

execute if score @s yuansu_out matches 41..45 if score @s element_number_total matches ..255 run tellraw @s [{"text": "当前剩余元素不足","color": "red"},{"text": "无法取出","color": "red"}]
execute if score @s yuansu_out matches 41..45 unless score @s element_number_total matches ..255 run function xsj:qiankun/qu_main/main_yuansu2

execute if score #system element_dlc_optional1 matches 1.. run function xsj:qiankun/yuansutb

execute unless score @s yuansu_out matches 16..30 run return 1

execute if score @s yuansu_out matches 16..20 if score @s yinpiao_count matches ..1 run tellraw @s [{"text": "当前铜钱数量为空","color": "red"}]
execute if score @s yuansu_out matches 16..20 unless score @s yinpiao_count matches ..1 run function xsj:qiankun/qu_main/main_tongqian

execute if score @s yuansu_out matches 21..25 if score @s yinpiao_count matches ..10 run tellraw @s [{"text": "当前铜钱数量甚至无法取出一个元宝","color": "red"}]
execute if score @s yuansu_out matches 21..25 unless score @s yinpiao_count matches ..10 run function xsj:qiankun/qu_main/main_yuanbao

execute if score @s yuansu_out matches 26.. if score @s yinpiao_count matches ..99 run tellraw @s [{"text": "当前铜钱数量甚至无法取出一张银票","color": "red"}]
execute if score @s yuansu_out matches 26..30 unless score @s yinpiao_count matches ..99 run function xsj:qiankun/qu_main/main_yinpiao

#execute if score @s yuansu_out matches 31.. if score @s yinpiao_count matches ..4 run tellraw @s [{"text": "当前剩余元素甚至无法取出一个精炼元素","color": "red"}]
#execute if score @s yuansu_out matches 31..55 unless score @s yinpiao_count matches ..4 run function xsj:qiankun/qu_main/main_yinpiao

#execute if score @s yuansu_out matches 56.. if score @s vantone_tick_count matches ..0 run tellraw @s [{"text": "当前万通宝符数量为空","color": "red"}]
#execute if score @s yuansu_out matches 56..60 unless score @s vantone_tick_count matches ..0 run function xsj:qiankun/qu_main/main_yinpiao