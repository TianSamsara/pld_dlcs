

#关自动
scoreboard players set @s auto_cunchu 0
tellraw @s {"translate": "dlc.qkd.yuansu_cun.5.1"}



