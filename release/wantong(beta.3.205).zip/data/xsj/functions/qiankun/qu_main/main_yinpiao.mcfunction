
execute if score @s yuansu_out matches 26 run scoreboard players set @s yinpiao_out 1
execute if score @s yuansu_out matches 27 run scoreboard players set @s yinpiao_out 10
execute if score @s yuansu_out matches 28 run scoreboard players set @s yinpiao_out 16
execute if score @s yuansu_out matches 29 run scoreboard players set @s yinpiao_out 32
execute if score @s yuansu_out matches 30 run scoreboard players set @s yinpiao_out 64

scoreboard players operation @s yinpiao = @s yinpiao_out
scoreboard players operation @s yinpiao_out *= 100 percent
#tellraw @s [{"text": "你当前剩余","color": "green"},{"score":{"name": "@s","objective": "yinpiao_out"},"color": "yellow"},{"text": "","color": "green"}]


execute if score @s yinpiao_out <= @s yinpiao_count run function xsj:qiankun/out/yinpiao_out
execute if score @s yinpiao_main matches 0 if score @s yinpiao_out > @s yinpiao_count run tellraw @s [{"text": "当前铜钱数量无法取出对应数量的银票","color": "red"}]
scoreboard players set @s yinpiao_main 0