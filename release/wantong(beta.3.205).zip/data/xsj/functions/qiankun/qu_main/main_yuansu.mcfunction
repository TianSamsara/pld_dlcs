
execute if score @s yuansu_out matches 11 unless score @s element_number_total matches ..63 run function xsj:qiankun/out/yuansu_metal
execute if score @s yuansu_out matches 12 unless score @s element_number_total matches ..63 run function xsj:qiankun/out/yuansu_wood
execute if score @s yuansu_out matches 13 unless score @s element_number_total matches ..63 run function xsj:qiankun/out/yuansu_water
execute if score @s yuansu_out matches 14 unless score @s element_number_total matches ..63 run function xsj:qiankun/out/yuansu_fire
execute if score @s yuansu_out matches 15 unless score @s element_number_total matches ..63 run function xsj:qiankun/out/yuansu_earth

