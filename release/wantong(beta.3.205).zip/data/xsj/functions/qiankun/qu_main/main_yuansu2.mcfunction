
scoreboard players set @s yuansu 9

execute if score @s ldjl matches 1 if score @s element_number_total matches 256.. run scoreboard players set @s yuansu 10
execute unless score @s ldjl matches 1 if score @s element_number_total matches 320.. run scoreboard players set @s yuansu 10


execute if score @s yuansu matches 9 run tellraw @s [{"text": "当前剩余元素","color": "red"},{"text": "无法炼制精炼元素","color": "red"}]

execute if score @s yuansu matches 10 run function xsj:qiankun/qu_main/main_yuansu3

scoreboard players set @s yuansu 0