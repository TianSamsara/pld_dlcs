
execute if score @s yuansu_out matches 41 run function xsj:qiankun/out/metal
execute if score @s yuansu_out matches 42 run function xsj:qiankun/out/wood
execute if score @s yuansu_out matches 43 run function xsj:qiankun/out/water
execute if score @s yuansu_out matches 44 run function xsj:qiankun/out/fire
execute if score @s yuansu_out matches 45 run function xsj:qiankun/out/earth