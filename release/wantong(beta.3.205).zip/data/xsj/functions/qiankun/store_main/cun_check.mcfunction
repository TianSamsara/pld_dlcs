execute if score @s yuansu_out matches 1 if score @s yuansu matches 1 run function xsj:qiankun/cun/metal

execute if score @s yuansu_out matches 2 if score @s yuansu matches 2 run function xsj:qiankun/cun/wood

execute if score @s yuansu_out matches 3 if score @s yuansu matches 3 run function xsj:qiankun/cun/water

execute if score @s yuansu_out matches 4 if score @s yuansu matches 4 run function xsj:qiankun/cun/fire

execute if score @s yuansu_out matches 5 if score @s yuansu matches 5 run function xsj:qiankun/cun/earth

execute if score @s yuansu_out matches 6 if score @s yuansu matches 6 run function xsj:qiankun/cun/q_copper_cash

execute if score @s yuansu_out matches 7 if score @s yuansu matches 7 run function xsj:qiankun/cun/q_gold_ingot

execute if score @s yuansu_out matches 8 if score @s yuansu matches 8 run function xsj:qiankun/cun/q_silver_ticket

#function xsj:/qiankun/cun/element_tick
#function xsj:/qiankun/cun/relive_stone

#execute if score @s yuansu_out matches 11 if score @s yuansu matches 1 run function xsj:qiankun/cun/metal

#execute if score @s yuansu_out matches 12 if score @s yuansu matches 2 run function xsj:qiankun/cun/wood

#execute if score @s yuansu_out matches 13 if score @s yuansu matches 3 run function xsj:qiankun/cun/water

#execute if score @s yuansu_out matches 14 if score @s yuansu matches 4 run function xsj:qiankun/cun/fire

#execute if score @s yuansu_out matches 15 if score @s yuansu matches 5 run function xsj:qiankun/cun/earth

#execute if score @s yuansu_out matches 16 if score @s yuansu matches 6 run function xsj:qiankun/cun/q_copper_cash
