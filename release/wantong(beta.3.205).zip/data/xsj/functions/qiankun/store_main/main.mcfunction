#检测接口
execute if score @s yuansu_out matches 1 unless entity @s[nbt={Inventory:[{tag:{id:"panling:metal",}}]}] run tellraw @s {"translate": "dlc.qkd.yuansu_cun.0.1"}
execute if score @s yuansu_out matches 2 unless entity @s[nbt={Inventory:[{tag:{id:"panling:wood",}}]}] run tellraw @s {"translate": "dlc.qkd.yuansu_cun.0.1"}
execute if score @s yuansu_out matches 3 unless entity @s[nbt={Inventory:[{tag:{id:"panling:water",}}]}] run tellraw @s {"translate": "dlc.qkd.yuansu_cun.0.1"}
execute if score @s yuansu_out matches 4 unless entity @s[nbt={Inventory:[{tag:{id:"panling:fire",}}]}] run tellraw @s {"translate": "dlc.qkd.yuansu_cun.0.1"}
execute if score @s yuansu_out matches 5 unless entity @s[nbt={Inventory:[{tag:{id:"panling:earth",}}]}] run tellraw @s {"translate": "dlc.qkd.yuansu_cun.0.1"}
execute if score @s yuansu_out matches 6 unless entity @s[nbt={Inventory:[{tag:{id:"panling:copper_cash",}}]}] run tellraw @s {"translate": "dlc.qkd.yuansu_cun.0.1"}
execute if score @s yuansu_out matches 7 unless entity @s[nbt={Inventory:[{tag:{id:"panling:gold_ingot",}}]}] run tellraw @s {"translate": "dlc.qkd.yuansu_cun.0.1"}
execute if score @s yuansu_out matches 8 unless entity @s[nbt={Inventory:[{tag:{id:"panling:silver_ticket",}}]}] run tellraw @s {"translate": "dlc.qkd.yuansu_cun.0.1"}

execute if score @s yuansu_out matches 1 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:metal",}}]}] run scoreboard players set @s yuansu 1
execute if score @s yuansu_out matches 2 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:wood",}}]}] run scoreboard players set @s yuansu 2
execute if score @s yuansu_out matches 3 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:water",}}]}] run scoreboard players set @s yuansu 3
execute if score @s yuansu_out matches 4 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:fire",}}]}] run scoreboard players set @s yuansu 4
execute if score @s yuansu_out matches 5 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:earth",}}]}] run scoreboard players set @s yuansu 5

execute if score @s yuansu_out matches 6 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:copper_cash",}}]}] run scoreboard players set @s yuansu 6
execute if score @s yuansu_out matches 7 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:gold_ingot",}}]}] run scoreboard players set @s yuansu 7
execute if score @s yuansu_out matches 8 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:silver_ticket",}}]}] run scoreboard players set @s yuansu 8

execute if score @s yuansu matches 1..8 run function xsj:qiankun/store_main/cun_check
execute if score @s yuansu_out matches 9 run function xsj:qiankun/auto_cun/auto_cun
execute if score @s yuansu_out matches 10 run function xsj:qiankun/auto_cun/auto_cun2

execute if score #system element_dlc_optional1 matches 1.. run function xsj:qiankun/yuansutb

#execute if score @s yuansu_out matches 61 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:refined_metal",}}]}] run scoreboard players set @s yuansu 11
#execute if score @s yuansu_out matches 62 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:refined_wood",}}]}] run scoreboard players set @s yuansu 12
#execute if score @s yuansu_out matches 63 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:refined_water",}}]}] run scoreboard players set @s yuansu 13
#execute if score @s yuansu_out matches 64 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:refined_fire",}}]}] run scoreboard players set @s yuansu 14
#execute if score @s yuansu_out matches 65 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:refined_earth",}}]}] run scoreboard players set @s yuansu 15
#execute if score @s yuansu_out matches 66 unless score @s yuansu_out matches 9..10 if entity @s[nbt={Inventory:[{tag:{id:"panling:vantone_tick",}}]}] run scoreboard players set @s yuansu 16
#/setblock 1308 25 -381 minecraft:hopper[enabled=true,facing=down]{Items:[{Count:64b,Slot:0b,id:"minecraft:paper",tag:{Enchantments:[{id:"minecraft:unbreaking",lvl:1s}],HideFlags:63,display:{Lore:['{"translate":"pl.item.lore.vantone_tick.a"}','{"translate":"pl.item.lore.vantone_tick.b"}'],Name:'{"translate":"pl.item.name.vantone_tick"}'},id:"panling:vantone_tick"}}],TransferCooldown:0}
#execute if score @s yuansu matches 11..15 run function xsj:qiankun/store_main/cun_check
#execute if score @s yuansu_oyuansuut matches 16 run function xsj:qiankun/auto_cun/auto_cun

scoreboard players set @s yuansu 0