#取出物品数量检测
#execute if score @s relive_stone matches 1..63 if score @s relive_stone <= @s relive_stone_count run function xsj:qiankun/out/relive_stone
function pld:system/test_inv/invmain

#同步两者
#execute if score #system element_dlc_optional1 matches 1.. run function xsj:qiankun/yuansutb

#存取总库
#存
execute if score @s yuansu_out matches 1..10 run function xsj:qiankun/store_main/main
execute if score @s yuansu_out matches 61..100 run function xsj:qiankun/store_main/main

#取
#没空间
execute if score @s yuansu_out matches 11..60 if score @s inv_remain matches 0 run tellraw @s {"translate": "dlc.qkd.yuansu_cun.1.1"}
#检测
execute if score @s yuansu_out matches 11..60 if score @s inv_remain matches 1.. run function xsj:qiankun/qu_main/main


 
#execute if score @s yuansu_quan matches 1..127 run scoreboard players operation @s yuansu_quan *= #system 4
#execute if score @s yuansu_quan matches 1..508 if score @s yuansu_quan <= @s element_number_total run function xsj:qiankun/out/yuansu_quan

#余额查询
execute if score @s wupin_look matches 1.. run function xsj:qiankun/wupin_look

#自动存储选择
execute if score @s auto_cunchu_choose matches 1 run function xsj:qiankun/auto_cun/auto_cun_say

scoreboard players set @s yuansu_out 0