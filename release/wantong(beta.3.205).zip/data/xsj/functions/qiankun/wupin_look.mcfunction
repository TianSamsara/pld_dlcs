execute if score @s wupin_look matches 1 run tellraw @s [{"text": "你当前剩余","color": "green"},{"score":{"name": "@s","objective": "element_number_total"},"color": "yellow"},{"text": "个元素","color": "green"},{"text": "  "},{"score":{"name": "@s","objective": "yinpiao_count"},"color": "yellow"},{"text": "个铜钱","color": "green"},{"text": "  "},{"text": "你当前剩余","color": "green"},{"score":{"name": "@s","objective": "vantone_tick_count"},"color": "yellow"},{"text": "张万通宝符","color": "green"}]

#execute if score @s wupin_look matches 2 run tellraw @s [{"text": "你当前剩余","color": "green"},{"score":{"name": "@s","objective": "yinpiao_count"},"color": "yellow"},{"text": "个铜钱","color": "green"},{"text": "  "}]

#xecute if score @s wupin_look matches 2 run tellraw @s [{"text": "你当前剩余","color": "green"},{"score":{"name": "@s","objective": "vantone_tick_count"},"color": "yellow"},{"text": "张万通宝符","color": "green"},{"text": "  "}]

scoreboard players set @s wupin_look 0