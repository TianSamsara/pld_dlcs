execute unless score @s element_number_total matches 0.. run return 1
scoreboard players operation @s element_number_total -= @s yuansu_out