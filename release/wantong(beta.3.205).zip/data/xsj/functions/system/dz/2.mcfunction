#标签化函数组-打包配方
#/setblock 80 34 149 minecraft:stone_button[face=wall,facing=east,powered=false]

execute positioned 81 32 149 if block ~ ~ ~ minecraft:dispenser run function xsj:system/dz/check
#say 2
advancement revoke @s only xsj:crafting/dz2