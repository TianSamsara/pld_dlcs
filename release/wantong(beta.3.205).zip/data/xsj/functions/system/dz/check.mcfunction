#如果原装备有附灵等级，需要同步

execute if score #finish first_xsj_load matches 1 run function xsj:system/dz/main

#同步附灵
#execute if score #system temp matches 1 run function pld:system/dz/dzslot/enchant_clone/to_armor