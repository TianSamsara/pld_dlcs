execute unless data block ~ ~ ~ Items[{Slot:5b}] store result score #xsj temp run data get block ~ ~ ~ Items
execute store result score #xsj temp2 run data get block ~ ~ ~ Items[{Slot:6b}].tag.xy
execute store result score #xsj temp3 run data get block ~ ~ ~ Items[{Slot:6b}].tag.xyrare

#execute if score #xsj temp matches 2 run execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:iron_nugget",Count:1b}]} unless score @p dzsuccess matches 5 run function xsj:system/dz/dz5armor/main

execute if score #xsj temp matches 2 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:iron_nugget",Count:1b}]} unless score @p dzsuccess matches 5 run function xsj:system/dz/dz5armor/main0

execute if score #xsj temp matches 3 if score #xsj temp2 matches 1 if score #xsj temp3 matches 0 run execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:iron_nugget",Count:1b}]} unless score @p dzsuccess matches 5 run function xsj:system/dz/dz5armor/main1

execute if score #xsj temp matches 3 if score #xsj temp2 matches 1 if score #xsj temp3 matches 1 run execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:iron_nugget",Count:1b}]} unless score @p dzsuccess matches 5 run function xsj:system/dz/dz5armor/main2

execute if score #xsj temp matches 3 if score #xsj temp2 matches 1 if score #xsj temp3 matches 2 run execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:raw_gold",Count:1b}]} unless score @p dzsuccess matches 5 run function xsj:system/dz/dz5armor/main3

#execute if score #xsj temp matches 3 run execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:iron_nugget",Count:1b}]} unless score @p dzsuccess matches 5 run function xsj:system/dz/dz5armor/main2

#tellraw @p [{"text":"当前词条初级检测:","color":"green","bold": true},{"score": {"name": "#legend_id","objective": "temp"}}]
execute if score #xsj temp matches 2 if score #xsj temp2 matches 1 if score #xsj temp3 matches 3 run execute unless data block ~ ~ ~ Items[{Slot:5b}] if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:sugar",Count:1b}]} unless score @p dzsuccess matches 5 run function xsj:system/dz/dz5armor/main5

#tellraw @p [{"text":"当前系统检测:","color":"green","bold": true},{"score": {"name": "#xsj","objective": "temp2"}}]
#tellraw @p [{"text":"当前系统检测:","color":"green","bold": true},{"score": {"name": "#xsj","objective": "temp3"}}]
#tellraw @p [{"text":"当前系统检测:","color":"green","bold": true},{"score": {"name": "#legend_id","objective": "temp"}}]

#如果原装备有附灵等级，需要同步o function xsj:system/dz/main
#scoreboard players set #temp temp -1
#execute store success score #temp temp run data get block ~ ~ ~ Items.[{Slot:5b}].tag.enchant_id
#execute if score #temp temp matches 1 run functin pld:system/dz/dzslot/enchant_clone/to_temp
#同步附灵
#execute if score #temp temp matches 1 run function pld:system/dz/dzslot/enchant_clone/to_armor

scoreboard players reset #xsj temp
scoreboard players reset #xsj temp2
scoreboard players reset #xsj temp3

#/setblock 85 32 163 minecraft:hopper[enabled=true,facing=down]{CustomName:'{"translate":"pl.name.rh and db"}',Items:[{Count:1b,Slot:0b,id:"minecraft:phantom_membrane",tag:{Enchantments:[{id:"minecraft:protection21",lvl:1s}],HideFlags:63,core_iron_weapon6:1,display:{Lore:['{"translate":"pl.lore.rare6"}','{"translate":"pl.lore.limit_lvl_50"}','{"translate":"pl.item.lore.core_iron_weapon_processed.21.a"}','{"translate":"pl.item.lore.core_iron_weapon_processed.21.b"}','{"translate":"pl.item.lore.core_iron_weapon_processed.21.c"}','{"translate":"pl.item.lore.core_iron_weapon_processed.21.d"}','{"translate":"pl.item.lore.core_iron_weapon_processed.21.e"}','{"translate":"pl.item.lore.core_iron_weapon_processed.21.f"}'],Name:'{"translate":"pl.item.name.core_iron_weapon_processed.21"}'},id:"core_iron_weapon_processed"}},{Count:1b,Slot:1b,id:"minecraft:phantom_membrane",tag:{Enchantments:[{id:"minecraft:protection",lvl:1s}],HideFlags:63,core_iron_weapon6:2,display:{Lore:['{"translate":"pl.lore.rare6"}','{"translate":"pl.lore.limit_lvl_50"}','{"translate":"pl.item.lore.core_iron_weapon_processed.22.a"}','{"translate":"pl.item.lore.core_iron_weapon_processed.22.b"}','{"translate":"pl.item.lore.core_iron_weapon_processed.22.c"}','{"translate":"pl.item.lore.core_iron_weapon_processed.22.d"}','{"translate":"pl.item.lore.core_iron_weapon_processed.22.e"}','{"translate":"pl.item.lore.core_iron_weapon_processed.22.f"}'],Name:'{"translate":"pl.item.name.core_iron_weapon_processed.22"}'},id:"core_iron_weapon_processed"}},{Count:1b,Slot:2b,id:"minecraft:firework_star",tag:{Enchantments:[{id:"minecraft:protection",lvl:1s}],HideFlags:63,display:{Lore:['{"translate":"in.dream.collection.lore.a"}','{"translate":"in.dream.collection.lore.b"}','{"translate":"in.dream.collection.lore.c"}'],Name:'{"translate":"in.dream.collection.name"}'},dlc:"collection",id:"dlc:instances/dream/functions/collection"}}],TransferCooldown:0}
#execute if score #xsj temp matches 1 run function xsj:system/dz/dzslot/enchant_clone/to_armor
