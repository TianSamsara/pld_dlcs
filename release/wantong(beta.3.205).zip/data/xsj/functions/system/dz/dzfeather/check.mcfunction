#配方需求 2个位置
execute unless data block ~ ~ ~ Items[{Slot:5b}] store result score #xsj temp run data get block ~ ~ ~ Items
execute store result score #system temp2 run data get block ~ ~ ~ Items[{Slot:3b}].tag.feather-lvl
execute store result score #system temp3 run data get block ~ ~ ~ Items[{Slot:3b}].tag.feather_endlvl
#execute store result score #system temp3 run data get block ~ ~ ~ Items[{Slot:3b}].Count


execute if score #xsj temp matches 3 if score #system temp2 matches 0.. if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:4,}}]} run function xsj:system/dz/dzfeather/main1

execute if score #xsj temp matches 3 if score #system temp3 matches 0.. if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:4,}}]} run function xsj:system/dz/dzfeather/main2

execute if score #xsj temp matches 2 if score #system temp3 matches 0.. if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,Count:1b,tag:{lvl:1}},{Slot:3b,Count:1b,tag:{lvl:4,}}]} run function xsj:system/dz/dzfeather/main3

#execute if score #xsj temp matches 3 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:4,feather-lvl:1}}]} run function xsj:system/dz/dzfeather/main1

#execute if score #xsj temp matches 3 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:4,feather_endlvl:1}}]} run function xsj:system/dz/dzfeather/main2


#execute if score #xsj temp matches 3 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:4,feather-lvl:2}}]} run function xsj:system/dz/dzfeather/main1

#execute if score #xsj temp matches 3 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:4,feather_endlvl:2}}]} run function xsj:system/dz/dzfeather/main2


#execute if score #xsj temp matches 3 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:4,feather-lvl:3}}]} run function xsj:system/dz/dzfeather/main1

#execute if score #xsj temp matches 3 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:4,feather_endlvl:3}}]} run function xsj:system/dz/dzfeather/main2

#execute if score #xsj temp matches 4 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{lvl:1}}]} run function xsj:system/dz/dzfeather/main

#execute if score #xsj temp matches 3 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{id:"panling:purple_jade"}}]} run function xsj:system/dz/dzfeather/main

#execute if score #xsj temp matches 3 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,Count:1b,tag:{id:"panling:crystal_dew"}},{Slot:6b,Count:1b,tag:{id:"panling:convert_material"}}]} run function xsj:system/dz/dzfeather/main

#execute if score #xsj temp matches 2 if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:1b,tag:{book:1b}}]} run function xsj:system/dz/dzfeather/main4
#{Items:[{Count:1b,Slot:0b,id:"minecraft:nether_wart",tag:{HideFlags:63,display:{Lore:['{"translate":"pl.item.lore.convert_material.a"}','{"translate":"pl.item.lore.convert_material.b"}','{"translate":"pl.item.lore.convert_material.c"}'],Name:'{"translate":"pl.item.name.convert_material"}'},id:"panling:convert_material"}}]}

scoreboard players reset #xsj temp