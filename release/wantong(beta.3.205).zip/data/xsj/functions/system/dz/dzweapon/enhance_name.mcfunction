
execute if data storage pld:system {dzTemp:"panling:furnace61"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.furnace61"}'
execute if data storage pld:system {dzTemp:"panling:furnace62"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.furnace62"}'
execute if data storage pld:system {dzTemp:"panling:furnace63"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.furnace63"}'

execute if data storage pld:system {dzTemp:"panling:bow56"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.bow5.6"}'
execute if data storage pld:system {dzTemp:"panling:crossbow56"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.crossbow5.6"}'

execute if data storage pld:system {dzTemp:"panling:axe56"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.axe5.6"}'
execute if data storage pld:system {dzTemp:"panling:sword56"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.sword5.6"}'

execute if data storage pld:system {dzTemp:"panling:furnace56"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.furnace5.6"}'
#execute if data storage pld:system {dzTemp:"panling:furnace6"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.furnace6"}'
#'{"translate":"pl.item.name.furnace6"}'
#execute if data storage pld:system {dzTemp:"panling:furnace"} run data modify storage pld:system dzTemp set value '{"translate":"pl.item.name.furnace"}'