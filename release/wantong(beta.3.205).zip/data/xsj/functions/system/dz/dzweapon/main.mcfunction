scoreboard players set #system dzoutput -1

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{level:6s,job:2b,core_iron_weapon6:1}},{Count:16b,Slot:0b,tag:{dlc:"collection",id:"dream:collection"}}]} run scoreboard players set #system dzoutput 621

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{level:6s,job:2b,core_iron_weapon6:2}},{Count:16b,Slot:0b,tag:{dlc:"collection",id:"fairy:collection"}}]} run scoreboard players set #system dzoutput 622

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{level:6s,job:2b,core_iron_weapon6:4}},{Slot:0b,id:"minecraft:cyan_dye",Count:2b,tag:{id:"dlc:ice_balance_item"}},{Slot:6b,id:"minecraft:gray_dye",Count:2b,tag:{id:"dlc:fire_balance_item"}}]} run scoreboard players set #system dzoutput 623

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:2b,tag:{id:"dlc:legend_stone"}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{dlc:"collection",id:"sins:collection"}}]} run scoreboard players set #system dzoutput 624



execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,enhance_lvl:3,branch:0,limit:0}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 5100

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,enhance_lvl:3,branch:1,limit:0}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 5101


execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,enhance_lvl:3,branch:0,limit:1}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 5110

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,enhance_lvl:3,branch:1,limit:1}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 5111

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,enhance_lvl:3,limit:2}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 5120



execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,saint_weapon:1,branch:0,limit:0,}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 700

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,saint_weapon:1,branch:1,limit:0,}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 701

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,saint_weapon:1,branch:0,limit:1,}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 710

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,saint_weapon:1,branch:1,limit:1,}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 711

execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,id:"minecraft:phantom_membrane",Count:1b,tag:{id:"panling:core_weapon_processed",saint:1}},{Slot:6b,Count:1b,tag:{type:1,saint_weapon:1,limit:2,}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{instance:1}}]} run scoreboard players set #system dzoutput 721

#execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:3b,Count:2b,tag:{level:6s,job:2b,core_iron_weapon6:4}},{Slot:0b,id:"minecraft:orange_dye",Count:16b,tag:{dlc:"collection",id:"sins:collection"}}]} run scoreboard players set #system dzoutput 624

#tellraw @p [{"text":"当前core_weapon检测:","color":"green","bold": true},{"score": {"name": "#system","objective": "dzoutput"}}]

execute unless score #system dzoutput matches -1 unless data block ~ ~ ~ {Items:[{Slot:6b,tag:{type:1}}]} run function xsj:system/dz/dzweapon/recipes620

execute unless score #system dzoutput matches -1 if score #system dzoutput matches 624 if data block ~ ~ ~ {Items:[{Slot:6b,tag:{type:1}}]} run function pld:system/dz/dzweapon/enhance/check
execute unless score #system dzoutput matches -1 if score #system dzoutput matches 700..721 if data block ~ ~ ~ {Items:[{Slot:6b,tag:{type:1}}]} run function pld:system/dz/dzweapon/enhance/check

execute unless score #system dzoutput matches -1 if score #system dzoutput matches 5000.. if data block ~ ~ ~ {Items:[{Slot:6b,tag:{type:1,enhance_lvl:3,}}]} run function xsj:system/dz/dzweapon/recipes5000


