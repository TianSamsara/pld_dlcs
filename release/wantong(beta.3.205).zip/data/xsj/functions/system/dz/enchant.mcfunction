#如果原装备有附灵等级，需要同步
scoreboard players set #system temp -1
execute store success score #system temp run data get block ~ ~ ~ Items.[{Slot:6b}].tag.enchant_id
execute if score #system temp matches 1 run function pld:system/dz/dzslot/enchant_clone/to_temp
#同步附灵
#execute if score #system temp matches 1 run function pld:system/dz/dzslot/enchant_clone/to_armor