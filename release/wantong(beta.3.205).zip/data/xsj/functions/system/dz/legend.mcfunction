#将核心处的装备丢到slot5里
#把0、3位置清理掉
#data remove block ~ ~ ~ Items.[{Slot:0b}]
#把物品丢到5
#data modify block ~ ~ ~ Items[{Slot:3b}].Slot set value 5b

#幸运玩家 @p[tag=legend_check]
#tag @p add legend_check

#按照已有id赋值
#execute as @p[tag=legend_check] run function pld:system/dz/dzlegend/refine/check_id
#tellraw @p [{"text":"当前词条2级检测:","color":"green","bold": true},{"score": {"name": "#legend_id","objective": "temp"}}]
#随机获得id
#execute if block ~-3 ~2 ~ chest positioned ~-3 ~2 ~ run function pld:system/dz/dzlegend/tagset/loot
#根据tagid追加词条&legend_id
# #system temp4 = tagid
execute if score #legend_id temp matches 0 run function xsj:system/dz/modify/0
execute if score #legend_id temp matches 1 run function xsj:system/dz/modify/1
execute if score #legend_id temp matches 2 run function xsj:system/dz/modify/2
execute if score #legend_id temp matches 3 run function xsj:system/dz/modify/3
execute if score #legend_id temp matches 4 run function xsj:system/dz/modify/4
execute if score #legend_id temp matches 5 run function xsj:system/dz/modify/5
execute if score #legend_id temp matches 6 run function xsj:system/dz/modify/6
#处理后缀
# #system temp = limit
execute store result score #system temp run data get block ~ ~ ~ Items[{Slot:5b}].tag.limit
# #system temp2 = element
execute store result score #system temp2 run data get block ~ ~ ~ Items[{Slot:5b}].tag.element
# #system temp3 = slot
execute store result score #system temp3 run data get block ~ ~ ~ Items[{Slot:5b}].tag.slot
##system temp4 = tagid
execute store result score #xsj temp run data get block ~ ~ ~ Items[{Slot:5b}].tag.set_bonus_id
#execute store result score #xsj temp2 run data get block ~ ~ ~ Items[{Slot:5b}].tag.shen_slot
execute store result score #xsj temp3 run data get block ~ ~ ~ Items[{Slot:5b}].tag.xyslot

#名称处理
execute if block ~-3 ~2 ~ chest positioned ~-3 ~3 ~ run function pld:system/dz/dzlegend/tagset/name/summon
execute if block ~-3 ~4 ~ oak_sign run data modify block ~ ~ ~ Items.[{Slot:5b}].tag.display.Name set from block ~-3 ~4 ~ front_text.messages[0]
execute if block ~-3 ~4 ~ oak_sign run setblock ~-3 ~4 ~ air
#tellraw @p [{"text":"当前词条3级检测:","color":"green","bold": true},{"score": {"name": "#legend_id","objective": "temp"}}]
#清理用过的tag
#execute as @p[tag=legend_check] run function pld:system/dz/dzlegend/refine/clear_id

#tag @a[tag=legend_check] remove legend_check

#tellraw @p {"translate":"pl.refine_success2"}
#playsound minecraft:block.anvil.use block @a[distance=..5] ~ ~ ~