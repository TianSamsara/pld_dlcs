#如果原装备有附灵等级，需要同步
function xsj:system/dz/dz5armor/check
function xsj:system/dz/dzslot/check
function xsj:system/dz/dz5armor/check
function xsj:system/dz/dz_fab/check
function xsj:system/dz/dzfeather/check
function xsj:system/dz/dzweapon/main
#say 3
#function xsj:system/dz/dzweapon/main2
#同步附灵
#execute if score #system temp matches 1 run function pld:system/dz/dzslot/enchant_clone/to_armor