#非炼丹师
execute if score @s job matches 0 at @s run function xsj:system/fab/job0
execute if score @s job matches 1 at @s run function xsj:system/fab/job1

execute unless score @s xsj_sneak_check matches 1.. if entity @s[nbt={SelectedItem:{tag:{id:"panling:qiang",}}}] at @s run function xsj:system/fab/main/qiang/main
execute if score @s xsj_sneak_check matches 1.. if entity @s[nbt={SelectedItem:{tag:{id:"panling:qiang",}}}] at @s run function xsj:system/fab/main/qiang/main2

execute if score @s xsj_right_click_check matches 1.. run scoreboard players set @s xsj_right_click_check 0
execute if score @s xsj_sneak_check matches 1.. run scoreboard players set @s xsj_sneak_check 0