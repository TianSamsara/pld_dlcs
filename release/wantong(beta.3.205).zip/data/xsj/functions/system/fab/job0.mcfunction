#战士
execute if score @s xsj_sneak_check matches 1.. if score @s job matches 0 if entity @s[nbt={SelectedItem:{tag:{id:"panling:dao",}}}] run function xsj:system/fab/main/job0/dao0/main


