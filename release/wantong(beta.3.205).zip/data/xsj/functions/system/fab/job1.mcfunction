#弓箭手

execute if score @s xsj_sneak_check matches 1.. if score @s job matches 1 if entity @s[nbt={SelectedItem:{tag:{id:"panling:jian",}}}] run function xsj:system/fab/main/job1/jian0/main

