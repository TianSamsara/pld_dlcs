
scoreboard objectives add fab_lvl dummy ["玩家法宝等级"]

scoreboard objectives add fab_tick1_1 dummy ["五号位法宝tick"]
scoreboard objectives add fab_tick1_2 dummy ["六号位法宝tick.下蹲"]

scoreboard objectives add fab_tick2_1 dummy ["六号位法宝tick"]
scoreboard objectives add fab_tick2_2 dummy ["六号位法宝tick.下蹲"]

scoreboard objectives add fab_tick4_1 dummy ["九号位法宝tick"]
scoreboard objectives add fab_tick4_2 dummy ["九号位法宝tick.下蹲"]
