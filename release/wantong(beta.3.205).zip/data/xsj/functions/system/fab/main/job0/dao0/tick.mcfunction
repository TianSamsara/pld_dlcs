#标记
#标记
#execute at @s store result score @s fab_lvl run data get entity @s SelectedItem.tag.enhance_lvl
#execute store result score percent inflammation_lvl run data get entity @s SelectedItem.tag.inflammation_lvl

execute as @s run tag @e[tag=monster,distance=..5] add daotag
#execute as @s[scores={zf_hold_ldl=-2}] run tag @e[tag=monster,distance=..10,limit=4] add daotag
#execute as @s[scores={zf_hold_ldl=-3}] run tag @e[tag=monster,distance=..15,limit=5] add daotag
#execute as @s[scores={zf_hold_ldl=-4}] run tag @e[tag=monster,distance=..20,limit=6] add daotag

#效果
function xsj:system/fab/main/job0/dao0/damage

#信息
execute if score @s skill_success matches 1 at @s run tellraw @s {"text":"","extra":[{"text":"☯☯☯","color":"red"},{"selector":"@s","color":"yellow"},{"translate":"dlc.info.dao","color":"red"}]}
#scoreboard players reset percent inflammation_lvl

#重置标记
tag @e[tag=daotag] remove daotag

#粒子效果
#execute at @s[scores={skill_success=1}] run particle minecraft:flame ~ ~ ~ 1 1 1 0 200 force 
#particle cloud ~ ~2 ~ 1.5 0 1.5 1 100
execute if score @s skill_success matches 1 run effect give @s instant_health 2 1 false
execute if score @s skill_success matches 1 run effect give @s saturation 2 1 false
#声音效果&进入冷却
#function xsj:system/zf/shifang/incool/inflammation/incool

#execute if score @s skill_success matches 1 run function xsj:system/fab/main/check

#设置冷却 
scoreboard players set @s fab_tick1_1 200

#应用冷却缩减
scoreboard players set @s zf_cool_middle 100
scoreboard players operation @s zf_cool_middle -= @s weapon_skill_cool_reduce 
scoreboard players operation @s fab_tick1_1 *= @s zf_cool_middle
scoreboard players operation @s fab_tick1_1 /= 100 percent





