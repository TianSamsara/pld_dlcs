#金元素 @s 施法者
#获取血量
#scoreboard players operation @e[tag=warrior_tag] entity_hurt_temp = @s player_2atk
#scoreboard players operation @e[tag=warrior_tag] entity_hurt_temp = attack_damage float2
#scoreboard players set #temp temp 150 
#scoreboard players operation @e[tag=warrior_tag] entity_hurt_temp *= #temp temp

#扣血
#scoreboard players operation #temp entity_hurt_temp = @s player_2atk
scoreboard players operation #temp entity_hurt_temp = @s archer_damage
scoreboard players operation #temp entity_hurt_temp *= 30 percent
#scoreboard players operation #temp entity_hurt_temp
#scoreboard players operation @e[tag=daotag] damage_middle /= #system 10
#execute as @e[tag=daotag] run scoreboard players operation @s damage_middle *= @s monster_resis
#scoreboard players operation @e[tag=daotag] entity_hurt_temp /= 100 percent
#execute if score #temp entity_hurt_temp matches 10000.. run scoreboard players set @s entity_hurt_temp 10000
#execute as @e[tag=daotag] run scoreboard players operation @s monster_health -= @s damage_middle

#仇恨
#function pld:system/zf/shifang/threat/main
#受伤函数
tag @s add if_death_count
execute as @e[tag=jiantag] run function pld:system/warrior_attack/hurt/hurt_armor_enchant_effect
tag @s remove if_death_count


scoreboard players set @s skill_success 1
