#标记
execute if score @s fab_tick1_1 matches 0.. run function xsj:system/zf/tick/tick1_1
execute unless score @s fab_tick1_1 matches 0.. run function xsj:system/fab/main/job1/jian0/tick


