summon marker ^3 ^1.0 ^ {Tags:["jian_marker1"]}
summon marker ^1.5 ^1.0 ^ {Tags:["jian_marker1"]}
summon marker ^ ^1.0 ^ {Tags:["jian_marker1","jian_marker_middle1"]}
summon marker ^-1.5 ^1.0 ^ {Tags:["jian_marker1"]}
summon marker ^-3 ^1.0 ^ {Tags:["jian_marker1"]}
execute as @e[type=marker,tag=jian_marker1] run function xsj:system/fab/main/job1/jian0/particle/loop

#如果够了 那就结束
execute as @e[type=marker,tag=jian_marker1] run kill @s