#标记
#execute if score @s fab_tick2_1 matches 0.. run function xsj:system/zf/tick/tick4_1
#execute unless score @s fab_tick2_1 matches 0.. run function xsj:system/fab/main/qiang/tick

execute if score @s fab_tick4_1 matches 0.. run function xsj:system/zf/tick/tick4_1
execute unless score @s fab_tick4_1 matches 0.. run function xsj:system/fab/main/qiang/tick
