#标记
#execute if score @s fab_tick2_2 matches 0.. run function xsj:system/zf/tick/tick4_2
#execute unless score @s fab_tick2_2 matches 0.. run function xsj:system/fab/main/qiang/tick2


execute if score @s fab_tick4_2 matches 0.. run function xsj:system/zf/tick/tick4_2
execute unless score @s fab_tick4_2 matches 0.. run function xsj:system/fab/main/qiang/tick2