#往前走
execute positioned as @s run tp @s ^ ^ ^0.5
#+1并执行particle
execute at @s run particle sweep_attack ~ ~ ~

execute at @s[tag=qiang_marker_middle1] run particle minecraft:end_rod ~ ~ ~
scoreboard players add @s loop 1

#如果不够，继续
execute unless score @s loop matches 20.. run function xsj:system/fab/main/qiang/particle/loop
