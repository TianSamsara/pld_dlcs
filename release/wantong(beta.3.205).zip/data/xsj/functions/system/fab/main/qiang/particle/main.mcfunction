
summon marker ^ ^1.0 ^ {Tags:["qiang_marker0","qiang_marker_middle1"]}

execute as @e[type=marker,tag=qiang_marker0] run function xsj:system/fab/main/qiang/particle/loop

#如果够了 那就结束
execute as @e[type=marker,tag=qiang_marker0] run kill @s