
execute if score @s fab_lvl matches 1.. positioned ~ ~0.2 ~ rotated ~ 0 run particle end_rod ^ ^ ^6 0.1 0 0.1 0 1 force
execute if score @s fab_lvl matches 2.. positioned ~ ~0.2 ~ rotated ~ 0 run particle end_rod ^ ^ ^8 0.1 0 0.1 0 1 force
execute if score @s fab_lvl matches 3.. positioned ~ ~0.2 ~ rotated ~ 0 run particle end_rod ^ ^ ^10 0.1 0 0.1 0 1 force

execute unless score @s loop matches 101.. run scoreboard players add @s loop 1
execute rotated ~3.6 ~ if score @s loop matches ..99 run function xsj:system/fab/main/qiang/particle2/loop
