
scoreboard players set @s loop 0

function xsj:system/fab/main/qiang/particle2/loop

#execute as @e[type=marker,tag=qiang_marker1] run kill @s

scoreboard players reset @s loop