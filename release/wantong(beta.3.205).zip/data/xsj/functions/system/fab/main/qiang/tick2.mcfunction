
#execute at @s store result score @s fab_lvl run data get entity @s SelectedItem.tag.enhance_lvl
#execute store result score percent inflammation_lvl run data get entity @s SelectedItem.tag.inflammation_lvl
#execute if score @s qiang_sneak_lvl matches 3 run function xsj:system/zf/shifang/main/dlc/qiang/target2/main
#execute as @s[scores={zf_hold_ldl=-1}] run tag @e[tag=monster,distance=..10,limit=3] add metaltag
#execute as @s[scores={zf_hold_ldl=-2}] run tag @e[tag=monster,distance=..10,limit=4] add metaltag
#execute as @s[scores={zf_hold_ldl=-3}] run tag @e[tag=monster,distance=..15,limit=5] add metaltag
#execute as @s[scores={zf_hold_ldl=-4}] run tag @e[tag=monster,distance=..20,limit=6] add metaltag
execute at @s store result score @s fab_lvl run data get entity @s SelectedItem.tag.rank_lvl

execute if score @s fab_lvl matches 1 as @s run tag @e[tag=monster,distance=..6] add qiangtag
execute if score @s fab_lvl matches 2 as @s run tag @e[tag=monster,distance=..8] add qiangtag
execute if score @s fab_lvl matches 3 as @s run tag @e[tag=monster,distance=..10] add qiangtag
#效果
function xsj:system/fab/main/qiang/damage

#信息
tellraw @s {"text":"","extra":[{"selector":"@s","color":"yellow"},{"translate":"dlc.info.qiang.1","color":"red"}]}

#重置标记
tag @e[tag=qiangtag] remove qiangtag

#粒子效果
execute store result score @s temp run function xsj:system/fab/main/qiang/particle2/main

scoreboard players reset @s fab_lvl
#粒子效果
#execute at @s[scores={skill_success=1}] run particle minecraft:flame ~ ~ ~ 1 1 1 0 200 force
#particle cloud ~ ~2 ~ 1.5 0 1.5 1 100

#声音效果&进入冷却
#function xsj:system/zf/shifang/incool/inflammation/incool

execute if score @s skill_success matches 1 run function xsj:system/fab/main/check

#设置冷却 
scoreboard players set @s fab_tick4_2 200

#应用冷却缩减
scoreboard players set @s zf_cool_middle 100
scoreboard players operation @s zf_cool_middle -= @s weapon_skill_cool_reduce
scoreboard players operation @s fab_tick4_2 *= @s zf_cool_middle
scoreboard players operation @s fab_tick4_2 /= 100 percent

