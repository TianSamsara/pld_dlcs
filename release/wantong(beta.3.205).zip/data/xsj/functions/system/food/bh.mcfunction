#scoreboard players set @s food_tick 36000
#异步

effect give @s saturation 6000 0 false

advancement revoke @s only xsj:system/food/bh