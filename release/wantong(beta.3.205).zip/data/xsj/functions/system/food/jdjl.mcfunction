#scoreboard players set @s food_tick 36000
#异步


scoreboard players set @s ldjl 1