#scoreboard players set @s food_tick 36000
#异步
execute if score @s job matches 2 run scoreboard players set @s ldjl 1