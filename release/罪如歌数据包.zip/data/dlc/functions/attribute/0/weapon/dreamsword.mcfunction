attribute @s minecraft:generic.movement_speed modifier add 1-5-5-5-5 "碎梦武器属性-移动速度" 0.15 multiply_base

#碎梦tag2增加
execute if score @s weapon_dz_skill2 matches 1 run attribute @s minecraft:generic.armor modifier add 1-5-5-5-5 "碎梦武器属性-护甲" 5 add
execute if score @s weapon_dz_skill2 matches 1 run attribute @s minecraft:generic.armor_toughness modifier add 1-5-5-5-5 "碎梦武器属性-韧性" 2 add