execute unless score @s weapon_dz_skill2 matches 1 run attribute @s minecraft:generic.max_health modifier add 1-5-5-5-5 "沄水武器属性-最终生命" 0.25 multiply

#沄水tag2增加
execute if score @s weapon_dz_skill2 matches 1 run attribute @s minecraft:generic.max_health modifier add 1-5-5-5-5 "沄水武器属性-最终生命" 0.75 multiply
