attribute @s minecraft:generic.movement_speed modifier add 1-5-5-5-5 "惊梦武器属性-速度" 0.2 multiply_base
