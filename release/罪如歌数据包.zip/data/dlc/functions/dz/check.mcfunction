#阴阳
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:6b,Count:1b,tag:{is_armor:1,rare:6}},{Slot:0b,Count:8b,tag:{dlc:"collection"}}]} run function dlc:dz/armor/5_6/main
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:6b,Count:1b,tag:{is_armor:1,rare:5}},{Slot:0b,Count:8b,tag:{dlc:"collection"}}]} run function dlc:dz/armor/5_6/main
#武器锻造 吹雪/霜主 流星照惊鸿/沄水破千军 惊梦之弓/碎梦之斧 军征/埋恨 罪之笔
function dlc:dz/main_123
#罪之锻
execute if block ~ ~ ~ minecraft:dispenser{Items:[{Slot:0b,tag:{dlc:"collection"}},{Slot:6b,tag:{id:"dlc:legend_stone"}}]} run function dlc:dz/weapon/sins/check
#give @s fire_charge{HideFlags:63,Enchantments:[{id:"minecraft:protection",lvl:1s}],id:"dlc:legend_stone",display:{Name:'{"translate":"in.dark.stone.name"}',Lore:['{"translate":"pl.lore.rare6"}','{"translate":"in.dark.stone.lore.a"}','{"translate":"in.dark.stone.lore.b"}','{"translate":"in.dark.stone.lore.c"}','{"translate":"in.dark.stone.lore.d"}','{"translate":"in.dark.stone.lore.e"}','{"translate":"in.dark.stone.lore.f"}','{"translate":"in.dark.stone.lore.g"}']}}
