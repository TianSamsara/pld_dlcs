#清理标签与效果
tag @s remove balance_all_2
tag @s remove balance_all_4
tag @s remove balance_0_4
tag @s remove balance_1_4
tag @s remove balance_rare_all_6