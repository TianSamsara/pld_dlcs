#惊梦技能
execute if score @s job matches 1 if score @s weapon_rare matches 631 if score @s weapon_branch matches 2 at @s run function dlc:weapon_skill/dreambow/arrow_bit
#惊鸿被动标记
execute if score @s job matches 1 if score @s weapon_rare matches 621 if score @s weapon_branch matches 2 at @s run function dlc:weapon_skill/firebow/arrow_bit







advancement revoke @s only dlc:bit_arrow