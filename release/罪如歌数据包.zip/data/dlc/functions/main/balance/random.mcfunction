#随机主题
loot spawn 183 65 -1769 loot dlc:pos9
execute store result score #system dlc_kind run data get entity @e[limit=1,type=item,nbt={Item: {id: "minecraft:stone", tag: {dlcpos:1}}}] Item.tag.pos
kill @e[type=item,nbt={Item: {id: "minecraft:stone", tag: {dlcpos:1}}}]
execute if score #system dlc_kind matches 1 run tellraw @a [{"text": "当前阴阳调和：","color": "green"},{"text": "☯☯☯☯","color": "white"},{"text": "","color": "black"}]
execute if score #system dlc_kind matches 2..4 run tellraw @a [{"text": "当前阴阳调和：","color": "green"},{"text": "☯☯☯","color": "white"},{"text": "☯","color": "black"}]
execute if score #system dlc_kind matches 5 run tellraw @a [{"text": "当前阴阳调和：","color": "green"},{"text": "☯☯","color": "white"},{"text": "☯☯","color": "black"}]
execute if score #system dlc_kind matches 6..8 run tellraw @a [{"text": "当前阴阳调和：","color": "green"},{"text": "☯","color": "white"},{"text": "☯☯☯","color": "black"}]
execute if score #system dlc_kind matches 9 run tellraw @a [{"text": "当前阴阳调和：","color": "green"},{"text": "","color": "white"},{"text": "☯☯☯☯","color": "black"}]
#阴阳词条
execute if score #system dlc_kind matches 1 run tellraw @a [{"text": "[至阳时刻]","color": "red"},{"text": "[至阳·4]激活时,最终生命值+30%","color": "aqua"}]
execute if score #system dlc_kind matches 5 run tellraw @a [{"text": "[阴阳平衡]","color": "red"},{"text": "[传说·宁和]提升至30%","color": "aqua"}]
execute unless score #system dlc_kind matches 5 run scoreboard players set #system balance_rare_all_6 10
execute if score #system dlc_kind matches 5 run scoreboard players set #system balance_rare_all_6 30
execute if score #system dlc_kind matches 9 run tellraw @a [{"text": "[极阴之力]","color": "red"},{"text": "[极阴·4]激活时,进攻属性+30%","color": "aqua"}]
execute unless score #system dlc_kind matches 9 run scoreboard players set #system balance_1_4 30
execute if score #system dlc_kind matches 9 run scoreboard players set #system balance_1_4 60

#随机刷新时间
loot spawn 183 65 -1769 loot dlc:pos5
execute if entity @e[type=item,nbt={Item: {id: "minecraft:stone", tag: {dlcpos:1,pos:1}}}] run scoreboard players set #system dlc_time 1200
execute if entity @e[type=item,nbt={Item: {id: "minecraft:stone", tag: {dlcpos:1,pos:2}}}] run scoreboard players set #system dlc_time 2400
execute if entity @e[type=item,nbt={Item: {id: "minecraft:stone", tag: {dlcpos:1,pos:3}}}] run scoreboard players set #system dlc_time 3600
execute if entity @e[type=item,nbt={Item: {id: "minecraft:stone", tag: {dlcpos:1,pos:4}}}] run scoreboard players set #system dlc_time 4800
execute if entity @e[type=item,nbt={Item: {id: "minecraft:stone", tag: {dlcpos:1,pos:5}}}] run scoreboard players set #system dlc_time 6000
kill @e[type=item,nbt={Item: {id: "minecraft:stone", tag: {dlcpos:1}}}]
