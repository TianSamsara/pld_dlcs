scoreboard objectives add fighting dummy
scoreboard objectives add fight_time dummy
scoreboard objectives add fight_in_way dummy ["进入战斗原因"]
scoreboard objectives add fighting_time dummy