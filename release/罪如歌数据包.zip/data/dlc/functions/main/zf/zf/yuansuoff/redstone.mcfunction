scoreboard players operation #system yi5.str2 = @s zf_str
tellraw @a [{"selector": "@s"},{"text":"将","color":"white","bold": false},{"score": {"name": "#system","objective": "yi5.str2","bold": true}},{"text":"点阵法强度上传至","color":"white","bold": false},{"text":"盘灵云","color":"green","bold": true}]
scoreboard players operation #system yi5.str2 *= #system 10


execute at @s run playsound block.anvil.place ambient @s

scoreboard players set @s yi5.timing2 1200
scoreboard players set #system yi5.timing2 1200



scoreboard players set @s 1 2