#执行主体：怪物   执行位置：怪物    伤害来源：@p[tag=bitter]
#dlc   damage_middle   100倍
#dlc   damage_type    0物理   1法术
#dlc   damage_knock   0不击退   1击退
#物理伤害：全部计算     但不会受到法抗
#法术伤害：仅无视护甲   但会受到法抗

#护甲
execute if score #dlc damage_type matches 0 run function dlc:math/skill_bit/pro_armor
#法抗
execute if score #dlc damage_type matches 1 run function dlc:math/skill_bit/fakang
#附魔
execute if score #dlc damage_type matches 0..1 run function dlc:math/skill_bit/pro_enchant
#是否击退
execute if score #dlc damage_knock matches 0 run attribute @s generic.knockback_resistance modifier add 2023-6-2-0-0 "不造成击退" 1000 add

#抗性
execute if predicate dlc:effect_check/resistance run function dlc:math/skill_bit/pro_effect

#总结
function dlc:math/skill_bit/main

