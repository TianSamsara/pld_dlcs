attribute @s generic.max_health modifier add 2025-6-12-0-1 "心之书最终加成" 0.5 multiply
attribute @s generic.movement_speed modifier add 2025-6-12-0-1 "心之书最终加成" 0.5 multiply
scoreboard players set @s sins.book.skill.0.1 1