execute if score @s sins.book.skill.tick1s matches 0.. run tellraw @s "你在说什么呀，我听不懂，可以详细描述一遍吗？"
execute unless score @s sins.book.skill.tick1s matches 0.. run function dlc:weapon_skill/book0/main
scoreboard players reset @s sins.book