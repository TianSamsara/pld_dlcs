# @s weapon_skill_cool_reduce
#阴阳4
execute if entity @s[tag=balance_all_4] if score @s job matches 1 run scoreboard players add @s weapon_skill_cool_reduce 50