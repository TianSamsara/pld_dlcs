tag @s add bitter

execute as @e[nbt={HurtTime:10s},sort=nearest,limit=1,tag=monster] at @s run function dlc:weapon_skill/dreambow/dream
title @s actionbar [{"text":"[梦醒时分]发动","color":"green","bold": true}]
tag @s remove bitter