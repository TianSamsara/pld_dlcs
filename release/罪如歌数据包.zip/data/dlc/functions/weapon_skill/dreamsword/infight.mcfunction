#武器技/阵法接口
function pld:equipment_lock/equipment/armor/set_bonus/when_weapon_skill_enable
title @s actionbar [{"text":"[破碎之梦]发动","color":"green","bold": true}]



