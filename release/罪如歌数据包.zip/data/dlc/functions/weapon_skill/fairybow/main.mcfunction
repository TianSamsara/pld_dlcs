##进入cd 秒X4
scoreboard players set @s weapon_skill_cool_5ticks 16
function pld:system/weapon_skill_cool/reduce_cool
#特效与音效
particle flame ~ ~ ~ 0 0 0 0.5 100 force
execute at @s run playsound entity.blaze.shoot ambient @a[distance=..6]
title @s actionbar [{"text":"[身陨秉节]发动","color":"green","bold": true}]
#获得debuff
function dlc:weapon_skill/fairybow/debuffs
#刷新自己箭矢强度
function pld:system/archer_damage/update
#武器技/阵法接口
function pld:equipment_lock/equipment/armor/set_bonus/when_weapon_skill_enable
#获取伤害
execute store result score #dlc damage_middle run scoreboard players get @s archer_damage
##根据debuff增加技能伤害
scoreboard players set #dlc weapon_temp2 100

#取伤害
scoreboard players set #temp temp 16
scoreboard players operation #dlc damage_middle *= #temp temp
scoreboard players operation #dlc damage_middle *= #dlc weapon_temp2
scoreboard players operation #dlc damage_middle /= #system 100



scoreboard players set #dlc damage_type 0
scoreboard players set #dlc damage_knock 1
#军征tag4增加  改法伤
execute if score @s weapon_dz_skill4 matches 1 run scoreboard players set #dlc damage_type 1

#造成伤害
tag @s add bitter
execute as @e[tag=monster,distance=..4] run function dlc:math/skill_bit/check
tag @s remove bitter