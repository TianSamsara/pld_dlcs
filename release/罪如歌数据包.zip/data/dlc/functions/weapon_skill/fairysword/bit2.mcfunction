
$damage @s $(temp) arrow
