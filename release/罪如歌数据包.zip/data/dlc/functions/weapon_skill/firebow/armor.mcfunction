#直接用吹雪的代码了
#吹雪被动增加
attribute @s generic.armor modifier add 2023-7-8-1-1 "吹雪被动护甲" 6 add
attribute @s generic.armor_toughness modifier add 2023-7-8-1-1 "吹雪被动韧性" 3 add