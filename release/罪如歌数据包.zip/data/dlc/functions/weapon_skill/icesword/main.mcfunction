##进入cd 秒X4
scoreboard players set @s weapon_skill_cool_5ticks 120

function pld:system/weapon_skill_cool/reduce_cool
#特效
execute at @s run playsound minecraft:entity.ender_dragon.flap ambient @a[distance=..10]
title @s actionbar [{"text":"[军团入侵]发动","color":"green","bold": true}]
#武器技/阵法接口
function pld:equipment_lock/equipment/armor/set_bonus/when_weapon_skill_enable
##将骸骨转化为"次数"与"时间" 以及“消耗数”
scoreboard players operation @s weapon_temp2 = @s weapon_temp1
scoreboard players operation @s weapon_temp3 = @s weapon_temp1
scoreboard players operation @s weapon_temp4 = @s weapon_temp1
scoreboard players set @s weapon_temp1 0
