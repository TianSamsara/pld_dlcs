##boss生成点 655 12 -1920
summon zombie 655 12 -1920 {Team:"monster",Tags:["panling","undead","monster","draw_boss","draw","dlc","0","fk80"],CanPickUpLoot:false,ArmorDropChances:[0f,0f,0f,0f],HandDropChances:[0f,0f],CustomNameVisible:1b,CustomName:'{"text":"良先生","color": "gold","italic": false}',DeathLootTable:"ice:diaoluowu",Health:1000.0f,Attributes:[ {Name:"generic.max_health",Base:1000d},{Name:"generic.follow_range",Base:30d},{Name:"generic.movement_speed",Base:0d},{Name:"generic.attack_damage",Base:0d},{Name:"generic.knockback_resistance",Base:1000d},{Name:"generic.armor",Base:30d},{Name:"generic.armor_toughness",Base:20d}],ArmorItems:[{id:"minecraft:chainmail_boots",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}},{id:"minecraft:chainmail_leggings",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}},{id:"minecraft:chainmail_chestplate",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:{Id:[I;260497508,-338736586,-1333673891,-1422241753],Properties:{textures:[{Value:"eyJ0aW1lc3RhbXAiOjE0MTEyODQ4ODc0MzgsInByb2ZpbGVJZCI6IjViYjE5ZjBjNDBjNjQzMmZhMGY0NTQyZDAzY2YzZGNjIiwicHJvZmlsZU5hbWUiOiJBdWRpYWNlMDgwOSIsInRleHR1cmVzIjp7IlNLSU4iOnsidXJsIjoiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9hNWFmZmQ2NGVjNzFlNzhhY2NhM2Y0ZWE4Yzk2NzRjN2RhMWNjNmQ0MzQ1Yjg1YTYxOGE3YTM3M2FmYyJ9fX0="}]}},Enchantments:[{id:"minecraft:protection",lvl:5s}]}}],HandItems:[{id:"carrot_on_a_stick",Count:1b,tag:{CustomModelData:62}},{id:glass_bottle,Count:1b}]}
#可无敌
scoreboard players set #dlc draw.bossskill.protect 1
#召唤一阶段小怪
function draw:mainskill/1/summon

#变招
execute if score #dlc draw.bossskill.mainskill.type matches 2.. run scoreboard players set #dlc draw.bossskill.mainskill.type 0
scoreboard players add #dlc draw.bossskill.mainskill.type 1
execute if score #dlc draw.bossskill.mainskill.type matches 0 run fill 630 11 -1945 679 11 -1896 black_wool
execute if score #dlc draw.bossskill.mainskill.type matches 0 run fill 629 11 -1946 679 11 -1896 white_concrete