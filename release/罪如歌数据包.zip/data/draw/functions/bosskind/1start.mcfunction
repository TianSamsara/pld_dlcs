scoreboard players set #dlc draw.boss.hpmath 8
scoreboard players set #dlc draw.bossskill.mainskill.type 0
tellraw @a[scores={dlc_ins=5}] [{"text":"良先生进入书生状态，其将持续作画，不会移动","color": "red"}]
execute as @a[scores={dlc_ins=5}] at @s run playsound entity.wither.ambient player @s
function draw:bosskind/1


