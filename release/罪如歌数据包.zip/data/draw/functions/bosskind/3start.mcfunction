scoreboard players set #dlc draw.boss.hpmath 5
scoreboard players set #dlc draw.bossskill.mainskill.type 0
scoreboard players set #dlc draw.bossskill.mainskill.3.tag 0

tellraw @a[scores={dlc_ins=5}] [{"text":"祂愈发熟练使用罪之笔,绘制出同源神器与你们战斗","color": "red"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：这副皮囊于吾本质而言已毫无意义！","color": "red"}]
execute as @a[scores={dlc_ins=5}] at @s run playsound entity.wither.ambient player @a[scores={dlc_ins=5}]
function draw:bosskind/3