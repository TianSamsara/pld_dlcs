tellraw @a[scores={dlc_ins=5}] [{"text":"在本场战斗中,已成为半神的祂将：","color": "aqua"}]
execute as @a[scores={dlc_ins=5}] at @s run playsound entity.player.levelup player @s