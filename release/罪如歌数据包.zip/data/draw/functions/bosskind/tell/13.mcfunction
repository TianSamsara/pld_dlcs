tellraw @a[scores={dlc_ins=5}] [{"text":"2、无法被连续击败","color": "aqua"}]
execute as @a[scores={dlc_ins=5}] at @s run playsound entity.experience_orb.pickup player @s