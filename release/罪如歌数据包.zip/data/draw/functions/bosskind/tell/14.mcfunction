tellraw @a[scores={dlc_ins=5}] [{"text":"3、永远无法被动摇","color": "aqua"}]
execute as @a[scores={dlc_ins=5}] at @s run playsound entity.experience_orb.pickup player @s