#检测副本是否有人
execute if entity @a[scores={dlc_ins=5}] run tellraw @a[distance=..8] [{"text":"这张纸已经被墨迹填满,无法容纳更多颜料了。","color": "gray","italic": true}]
execute unless entity @a[scores={dlc_ins=5}] run function draw:fight/main
