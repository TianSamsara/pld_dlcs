scoreboard players set @s dlc_ins 5
scoreboard players set @s feather_mainland -1
scoreboard players set @s draw.player.cs.all 1

tp @s 630 12 -1945 -45 0

#通知
tellraw @s[scores={draw.player.cs.all=1..5}] [{"text":"良先生:想要夺取此神器？那就让我领教领教你的实力吧。","color": "gold"}]
tellraw @s[scores={draw.player.cs.all=6..10}] [{"text":"良先生:又是你？一次次的轮回还没让你对这场战斗感到厌倦吗？","color": "gold"}]
tellraw @s[scores={draw.player.cs.all=11..}] [{"text":"良先生:废话不多说,让我们开始吧。","color": "gold"}]
execute at @s run playsound entity.ender_dragon.ambient player @s