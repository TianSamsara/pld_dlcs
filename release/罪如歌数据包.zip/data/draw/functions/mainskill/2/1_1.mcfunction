#loop   main 向 target 移动并投放粒子 @e[type=marker,tag=wood_line_particle_main,limit=1] @e[type=marker,tag=wood_line_particle_target,limit=1]
execute facing entity @e[type=marker,tag=boss,tag=1,limit=1] eyes run tp @s ^ ^ ^0.4

#粒子效果
particle flame ~ ~ ~

execute at @s if entity @e[type=marker,tag=boss,tag=1,limit=1,distance=..1] as @s run kill @s

tag @a[distance=..2] add draw_sins

#结束 条件一 到附近了 条件二 循环上限为80
execute at @s unless entity @e[type=marker,tag=boss,tag=1,distance=..1] run function draw:mainskill/2/1_1

