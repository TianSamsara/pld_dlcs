attribute @s generic.attack_damage modifier add 2025-6-5-0-1 "进攻属性加成" 0.5 multiply_base
attribute @s generic.movement_speed modifier add 2025-6-5-0-1 "移动速度" 0.5 multiply_base