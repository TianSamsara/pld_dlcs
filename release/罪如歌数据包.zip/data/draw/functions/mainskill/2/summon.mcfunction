tp @e[tag=monster,tag=draw,tag=normal] ~ ~-1000 ~
kill @e[tag=monster,tag=draw,tag=normal]
#小怪
summon marker 645 15 -1920 {Tags:["draw","1"]}
summon marker 665 15 -1920 {Tags:["draw","2"]}
summon marker 655 15 -1930 {Tags:["draw","3"]}
summon marker 655 15 -1910 {Tags:["draw","4"]}

#阳
execute at @e[type=marker,tag=1,tag=draw] run summon minecraft:skeleton ~ ~ ~ {Team:"monster",Tags:["panling","undead","monster","draw","special","0"],DeathLootTable:"newdark:diaoluowu",CanPickUpLoot:false,ArmorDropChances:[0f,0f,0f,0f],HandDropChances:[0f,0f],CustomNameVisible:1b,CustomName:'{"text":"洁白如玉的骷髅","color":"white"}',Health:800.0f,Attributes:[{Name:"generic.max_health",Base:800d},{Name:"generic.follow_range",Base:50d},{Name:"generic.movement_speed",Base:0.15d},{Name:"generic.attack_damage",Base:20d},{Name:"generic.armor",Base:0d},{Name:"generic.armor_toughness",Base:0d}],ArmorItems:[{},{},{},{id:"white_wool", Count:1b,tag:{Unbreakable:1b}}],HandItems:[{id:"bow",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"power",lvl:20}]}},{}]}
execute at @e[type=marker,tag=2,tag=draw] run summon minecraft:skeleton ~ ~ ~ {Team:"monster",Tags:["panling","undead","monster","draw","special","0"],DeathLootTable:"newdark:diaoluowu",CanPickUpLoot:false,ArmorDropChances:[0f,0f,0f,0f],HandDropChances:[0f,0f],CustomNameVisible:1b,CustomName:'{"text":"洁白如玉的骷髅","color":"white"}',Health:800.0f,Attributes:[{Name:"generic.max_health",Base:800d},{Name:"generic.follow_range",Base:50d},{Name:"generic.movement_speed",Base:0.15d},{Name:"generic.attack_damage",Base:20d},{Name:"generic.armor",Base:0d},{Name:"generic.armor_toughness",Base:0d}],ArmorItems:[{},{},{},{id:"white_wool", Count:1b,tag:{Unbreakable:1b}}],HandItems:[{id:"bow",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"power",lvl:20}]}},{}]}
#阴
execute at @e[type=marker,tag=3,tag=draw] run summon minecraft:wither_skeleton ~ ~ ~ {Team:"monster",Tags:["panling","undead","monster","draw","special","1"],DeathLootTable:"newdark:diaoluowu",CanPickUpLoot:false,ArmorDropChances:[0f,0f,0f,0f],HandDropChances:[0f,0f],CustomNameVisible:1b,CustomName:'{"text":"罪恶满身的骷髅","color":"black"}',Health:800.0f,Attributes:[{Name:"generic.max_health",Base:800d},{Name:"generic.follow_range",Base:50d},{Name:"generic.movement_speed",Base:0.15d},{Name:"generic.attack_damage",Base:20d},{Name:"generic.armor",Base:0d},{Name:"generic.armor_toughness",Base:0d}],ArmorItems:[{},{},{},{id:"black_wool", Count:1b,tag:{Unbreakable:1b}}],HandItems:[{id:"diamond_sword",Count:1b,tag:{Unbreakable:1b}},{}]}
execute at @e[type=marker,tag=4,tag=draw] run summon minecraft:wither_skeleton ~ ~ ~ {Team:"monster",Tags:["panling","undead","monster","draw","special","1"],DeathLootTable:"newdark:diaoluowu",CanPickUpLoot:false,ArmorDropChances:[0f,0f,0f,0f],HandDropChances:[0f,0f],CustomNameVisible:1b,CustomName:'{"text":"罪恶满身的骷髅","color":"black"}',Health:800.0f,Attributes:[{Name:"generic.max_health",Base:800d},{Name:"generic.follow_range",Base:50d},{Name:"generic.movement_speed",Base:0.15d},{Name:"generic.attack_damage",Base:20d},{Name:"generic.armor",Base:0d},{Name:"generic.armor_toughness",Base:0d}],ArmorItems:[{},{},{},{id:"black_wool", Count:1b,tag:{Unbreakable:1b}}],HandItems:[{id:"diamond_sword",Count:1b,tag:{Unbreakable:1b}},{}]}
#清理
kill @e[type=marker,tag=draw]
#通知
tellraw @a[scores={dlc_ins=5}] [{"text":"马良召唤出阴阳二属性的强大怪物，并与它们进行链接","color": "aqua"}]
tellraw @a[scores={dlc_ins=5,draw.player.cs.all=..5}] [{"text":"马良与异属性怪物链接将为双方提供50%近战伤害与移动速度","color": "aqua"}]
tellraw @a[scores={dlc_ins=5,draw.player.cs.all=..5}] [{"text":"马良与同属性怪物链接轨迹每秒会对接触玩家叠加5层[罪]","color": "aqua"}]
tellraw @a[scores={dlc_ins=5,draw.player.cs.all=..5}] [{"text":"[罪]：5秒结算一次，每10层[受到10点真实伤害，获得1层虚弱]，持续5秒","color": "aqua"}]
tellraw @a[scores={dlc_ins=5,draw.player.cs.all=..5}] [{"text":"[罪]：结算后削减10层罪,受到伤害后削减1层[罪]，最高50层","color": "aqua"}]

execute if score #dlc draw.bossskill.mainskill.2.tag matches 0 run tellraw @a[scores={dlc_ins=5}] [{"text":"注意:良先生当前属性：","color": "aqua"},{"text":"阳","color": "white"}]
execute if score #dlc draw.bossskill.mainskill.2.tag matches 1 run tellraw @a[scores={dlc_ins=5}] [{"text":"注意:良先生当前属性：","color": "aqua"},{"text":"阴","color": "black"}]

