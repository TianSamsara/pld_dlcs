setblock 655 12 -1920 dispenser
execute positioned 655 12 -1920 run function dlc:dz/weapon/sins/10/4
execute as @e[tag=draw_boss] run data modify entity @s HandItems.[0] set from block 655 12 -1920 Items.[]
setblock 655 12 -1920 air replace

tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：冰霜权柄之剑吗？好武器！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：掌管至阳权柄的神器，理应由吾使用！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：碎梦...那就由吾来破碎你们的幻想！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凡人成仙却能吸收如此心灵之权柄，当真是可怕，那就让你们也领教一下吧！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凛冬降临，凡不屈服者都将灭亡！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：流星一族为护佑此界全族灭亡，如今却无人问津，真是可笑。","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：如今想想，获得罪之笔的那一刻，我也是被惊梦之人。","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：悟道？吾已是神明，何须悟道！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：命运，当真是可笑！...又可叹。唉！","color": "red"}]

execute positioned 655 12 -1920 run function draw:mainskill/3/01/summon

tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者绘出","color": "aqua"},{"text":"霜主","color": "red"},{"text":"进行战斗","color": "aqua"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"霜主","color": "red"},{"text":"会将死去玩家的力量施加给不死的骸骨，提升其移动速度与近战伤害。","color": "aqua"}]
execute if score #dlc draw.bossskill.protect matches 0 run tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者激发神器潜力，骸骨每5秒会随机转移仇恨目标并突进到其身边。","color": "red"}]