setblock 655 12 -1920 dispenser
execute positioned 655 12 -1920 run function dlc:dz/weapon/sins/30/4
execute as @e[tag=draw_boss] run data modify entity @s HandItems.[0] set from block 655 12 -1920 Items.[]
setblock 655 12 -1920 air replace

#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：冰霜权柄之剑吗？好武器！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：掌管至阳权柄的神器，理应由吾使用！","color": "red"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：碎梦...那就由吾来破碎你们的幻想！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凡人成仙却能吸收如此心灵之权柄，当真是可怕，那就让你们也领教一下吧！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凛冬降临，凡不屈服者都将灭亡！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：流星一族为护佑此界全族灭亡，如今却无人问津，真是可笑。","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：如今想想，获得罪之笔的那一刻，我也是被惊梦之人。","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：悟道？吾已是神明，何须悟道！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：命运，当真是可笑！...又可叹。唉！","color": "red"}]

execute as @e[tag=draw_boss] run attribute @s generic.movement_speed modifier add 2025-6-9-0-1 "boss碎梦移动速度加成" 0.5 multiply_base
execute if score #dlc draw.bossskill.protect matches 0 as @e[tag=draw_boss] run attribute @s generic.attack_damage modifier add 2025-6-9-0-1 "boss碎梦近战伤害加成" 1 multiply_base

tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者绘出","color": "aqua"},{"text":"碎梦之斧","color": "red"},{"text":"进行战斗","color": "aqua"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"碎梦之斧","color": "red"},{"text":"：持有此武器时，负罪者持续获得抗性提升2，且移速提升50%","color": "aqua"}]
execute if score #dlc draw.bossskill.protect matches 0 run tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者激发神器潜力，负罪者近战伤害提升100%","color": "red"}]