setblock 655 12 -1920 dispenser
execute positioned 655 12 -1920 run function dlc:dz/weapon/sins/11/4
execute as @e[tag=draw_boss] run data modify entity @s HandItems.[0] set from block 655 12 -1920 Items.[]
execute as @e[tag=draw_boss] run data modify entity @s HandItems.[0].id set value bow
execute as @e[tag=draw_boss] run data modify entity @s HandItems[0].tag.Enchantments append value {id:"power",lvl:30}
setblock 655 12 -1920 air replace

#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：冰霜权柄之剑吗？好武器！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：掌管至阳权柄的神器，理应由吾使用！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：碎梦...那就由吾来破碎你们的幻想！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凡人成仙却能吸收如此心灵之权柄，当真是可怕，那就让你们也领教一下吧！","color": "red"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凛冬降临，凡不屈服者都将灭亡！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：流星一族为护佑此界全族灭亡，如今却无人问津，真是可笑。","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：如今想想，获得罪之笔的那一刻，我也是被惊梦之人。","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：悟道？吾已是神明，何须悟道！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：命运，当真是可笑！...又可叹。唉！","color": "red"}]


tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者绘出","color": "aqua"},{"text":"吹雪","color": "red"},{"text":"进行战斗","color": "aqua"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"吹雪","color": "red"},{"text":"给予所有玩家缓慢2，并令负罪者每秒恢复50点生命值","color": "aqua"}]
execute if score #dlc draw.bossskill.protect matches 0 run tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者激发神器潜力，所有玩家每秒受到10点真实伤害","color": "red"}]