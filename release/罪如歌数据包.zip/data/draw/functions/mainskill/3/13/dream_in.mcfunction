scoreboard players add @s draw.3.dream 5
attribute @s generic.movement_speed modifier add 2025-6-9-0-1 "惊梦debuff" -0.5 multiply
scoreboard players set #dlc draw.3.dream 1