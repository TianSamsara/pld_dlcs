setblock 655 12 -1920 dispenser
execute positioned 655 12 -1920 run function dlc:dz/weapon/sins/31/4
execute as @e[tag=draw_boss] run data modify entity @s HandItems.[0] set from block 655 12 -1920 Items.[]
execute as @e[tag=draw_boss] run data modify entity @s HandItems.[0].id set value bow
execute as @e[tag=draw_boss] run data modify entity @s HandItems[0].tag.Enchantments append value {id:"power",lvl:30}
setblock 655 12 -1920 air replace





#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：冰霜权柄之剑吗？好武器！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：掌管至阳权柄的神器，理应由吾使用！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：碎梦...那就由吾来破碎你们的幻想！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凡人成仙却能吸收如此心灵之权柄，当真是可怕，那就让你们也领教一下吧！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凛冬降临，凡不屈服者都将灭亡！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：流星一族为护佑此界全族灭亡，如今却无人问津，真是可笑。","color": "red"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：如今想想，获得罪之笔的那一刻，我也是被惊梦之人。","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：悟道？吾已是神明，何须悟道！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：命运，当真是可笑！...又可叹。唉！","color": "red"}]

scoreboard players set #dlc archer_damage 30
execute if score #dlc draw.bossskill.protect matches 0 as @a if score @s dlc_ins matches 5 run function draw:mainskill/3/13/archer_damage
execute as @e[tag=draw_boss] run function draw:mainskill/3/13/monster

tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者绘出","color": "aqua"},{"text":"惊梦之弓","color": "red"},{"text":"进行战斗","color": "aqua"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"惊梦之弓","color": "red"},{"text":"造成伤害将施加[沉睡],玩家受到伤害时清空[沉睡]，并且受到100点箭矢伤害","color": "aqua"}]
execute if score #dlc draw.bossskill.protect matches 0 run tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者激发神器潜力，其箭矢强度提升至与进攻属性最高玩家相同","color": "red"}]