#清理怪物
tp @e[tag=monster,tag=draw] ~ ~-1000 ~
kill @e[tag=monster,tag=draw]
##boss生成点 655 12 -1920
summon pillager 655 12 -1920 {Team:"monster",Tags:["panling","undead","monster","draw_boss","draw","dlc","0","fk80"],CanPickUpLoot:false,ArmorDropChances:[0f,0f,0f,0f],HandDropChances:[0f,0f],CustomNameVisible:1b,CustomName:'{"text":"背负罪孽之人","color": "gold","italic": false}',DeathLootTable:"ice:diaoluowu",Health:1000.0f,Attributes:[ {Name:"generic.max_health",Base:1000d},{Name:"generic.follow_range",Base:30d},{Name:"generic.movement_speed",Base:0.2d},{Name:"generic.attack_damage",Base:20d},{Name:"generic.knockback_resistance",Base:1000d},{Name:"generic.armor",Base:30d},{Name:"generic.armor_toughness",Base:20d}],ArmorItems:[{id:"minecraft:diamond_boots",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}},{id:"minecraft:diamond_leggings",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}},{id:"minecraft:diamond_chestplate",Count:1b,tag:{Unbreakable:1b,Enchantments:[{id:"minecraft:protection",lvl:5s}]}},{id:"minecraft:diamond_helmet",Count:1b,tag:{Enchantments:[{id:"minecraft:protection",lvl:5s}]}}],HandItems:[{},{}]}

setblock 655 12 -1920 dispenser
execute positioned 655 12 -1920 run function dlc:dz/weapon/sins/41/4
execute as @e[tag=draw_boss] run data modify entity @s HandItems.[0] set from block 655 12 -1920 Items.[]
execute as @e[tag=draw_boss] run data modify entity @s HandItems.[0].id set value crossbow
execute as @e[tag=draw_boss] run data modify entity @s HandItems[0].tag.Enchantments append value {id:"minecraft:quick_charge",lvl:4s}
execute as @e[tag=draw_boss] run data modify entity @s HandItems[0].tag.Enchantments append value {id:"minecraft:piercing",lvl:5s}
execute as @e[tag=draw_boss] run data modify entity @s HandItems[0].tag.Enchantments append value {id:"minecraft:multishot",lvl:4s}
setblock 655 12 -1920 air replace

#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：冰霜权柄之剑吗？好武器！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：掌管至阳权柄的神器，理应由吾使用！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：碎梦...那就由吾来破碎你们的幻想！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凡人成仙却能吸收如此心灵之权柄，当真是可怕，那就让你们也领教一下吧！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：凛冬降临，凡不屈服者都将灭亡！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：流星一族为护佑此界全族灭亡，如今却无人问津，真是可笑。","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：如今想想，获得罪之笔的那一刻，我也是被惊梦之人。","color": "red"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：悟道？吾已是神明，何须悟道！","color": "red"}]
#tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者：命运，当真是可笑！...又可叹。唉！","color": "red"}]


tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者绘出","color": "aqua"},{"text":"军征","color": "red"},{"text":"进行战斗","color": "aqua"}]
tellraw @a[scores={dlc_ins=5}] [{"text":"军征","color": "red"},{"text":"每秒给予随机两名玩家随机负面效果（持续1秒），随后对没有负面效果的玩家造成10点真实伤害","color": "aqua"}]
execute if score #dlc draw.bossskill.protect matches 0 run tellraw @a[scores={dlc_ins=5}] [{"text":"负罪者激发神器潜力，其对无负面效果的玩家造成伤害翻倍","color": "red"}]