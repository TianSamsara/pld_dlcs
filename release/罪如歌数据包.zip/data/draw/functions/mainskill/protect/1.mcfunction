scoreboard players set #dlc temp2 1
scoreboard players set #dlc draw_on 2
scoreboard players set #dlc draw.bossskill.protect 0
tp @e[tag=monster,tag=draw] ~ ~-1000 ~
kill @e[tag=monster,tag=draw]
#通知
tellraw @a[scores={dlc_ins=5,draw.player.cs.all=1..5}] [{"text":"良先生/马良/负罪者：见识见识这招！","color": "gold"}]
tellraw @a[scores={dlc_ins=5,draw.player.cs.all=6..10}] [{"text":"良先生/马良/负罪者：就让这泼天之罪将你们全部冲刷！","color": "gold"}]
tellraw @a[scores={dlc_ins=5,draw.player.cs.all=11..}] [{"text":"良先生/马良/负罪者：尝尝这来自造物主的权威吧！","color": "gold"}]
tellraw @a[scores={dlc_ins=5,draw.player.cs.all=0..10}] [{"text":"墨迹消退时,若你上升的高度低于5格,将会受到100点真实伤害。","color": "aqua"}]
execute as @a if score @s dlc_ins matches 5 at @s run playsound entity.wither.hurt player @s

scoreboard players set #dlc draw.bossskill.fall 500
