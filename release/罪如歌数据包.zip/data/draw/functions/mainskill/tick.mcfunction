##副本记1时开启

##bossbar显示
#常驻
execute store result bossbar dlc:draw_bossbar value run scoreboard players get #dlc draw.boss.maxhp
bossbar set dlc:draw_bossbar players @a[scores={dlc_ins=5}]
#计算神性
execute store result bossbar dlc:draw_bosshpmath1 value run scoreboard players get #dlc draw.boss.hpmath
execute store result bossbar dlc:draw_bosshpmath2 value run scoreboard players get #dlc draw.boss.hpmath
execute store result bossbar dlc:draw_bosshpmath3 value run scoreboard players get #dlc draw.boss.hpmath
#计算boss实体生命值百分比
execute store result score #dlc temp1 run data get entity @e[tag=draw_boss,limit=1] Health
execute store result score #dlc temp2 run attribute @e[tag=draw_boss,limit=1] generic.max_health get
scoreboard players operation #dlc temp1 *= #system 100
scoreboard players operation #dlc temp1 /= #dlc temp2
execute store result bossbar dlc:draw_bosshp1 value run scoreboard players get #dlc temp1
execute store result bossbar dlc:draw_bosshp2 value run scoreboard players get #dlc temp1
execute store result bossbar dlc:draw_bosshp3 value run scoreboard players get #dlc temp1
#显示
execute if score #dlc draw.boss.maxhp matches 3 run bossbar set dlc:draw_bosshp1 players @a[scores={dlc_ins=5}]
execute if score #dlc draw.boss.maxhp matches 3 run bossbar set dlc:draw_bosshpmath1 players @a[scores={dlc_ins=5}]
execute if score #dlc draw.boss.maxhp matches 2 run bossbar set dlc:draw_bosshp2 players @a[scores={dlc_ins=5}]
execute if score #dlc draw.boss.maxhp matches 2 run bossbar set dlc:draw_bosshpmath2 players @a[scores={dlc_ins=5}]
execute if score #dlc draw.boss.maxhp matches 1 run bossbar set dlc:draw_bosshp3 players @a[scores={dlc_ins=5}]
execute if score #dlc draw.boss.maxhp matches 1 run bossbar set dlc:draw_bosshpmath3 players @a[scores={dlc_ins=5}]


###boss技能tick
##半血无敌+死亡重生
#boss半血及以下时开启无敌机制
scoreboard players reset #dlc temp2
execute if score #dlc temp1 matches ..50 if score #dlc draw.bossskill.protect matches 1 run function draw:mainskill/protect/1
#boss实体死亡时死亡
#先确定当前boss此阶段是否开启过无敌,若无,则强制无敌
execute unless score #dlc temp2 matches 1 unless entity @e[tag=draw_boss] if score #dlc draw.bossskill.protect matches 1 run function draw:mainskill/protect/1
execute unless score #dlc temp2 matches 1 unless entity @e[tag=draw_boss] if score #dlc draw.bossskill.protect matches ..0 run function draw:bosskind/dead



