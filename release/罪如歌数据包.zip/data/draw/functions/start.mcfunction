
scoreboard objectives add draw_on dummy "副本开启/在副本中（0关1开）"
scoreboard objectives add draw.boss.maxhp dummy "副本阶段数(初始为3,降低至0时副本结束)"
scoreboard objectives add draw.boss.hpmath dummy "boss剩余血条数量"
scoreboard objectives add draw.boss.mobhp dummy "boss实体当前生命值"
scoreboard objectives add draw.bossskill.protect dummy "boss剩余无敌次数"
scoreboard objectives add draw.bossskill.fall dummy "boss是否开启落沙"
scoreboard objectives add draw.bossskill.mainskill.type dummy "boss在此阶段下特殊技能效果"
#二阶段
scoreboard objectives add draw.bossskill.mainskill.2.tag dummy "boss二阶段阴阳"
scoreboard objectives add draw.bossskill.mainskill.tick5s dummy "boss二阶段效果记时"
scoreboard objectives add draw.bossskill.mainskill.2.debuff dummy "boss二阶段罪数"
#三阶段
#1霜主2沄水3碎梦4埋恨5吹雪6惊鸿7惊梦8军征9硬币10罪之笔
scoreboard objectives add draw.bossskill.mainskill.3.tag dummy "boss三阶段武器类型"
scoreboard objectives add draw.3.dead dummy "玩家死亡稀有度数"
scoreboard objectives add draw.3.di dummy "boss敌层数"
scoreboard objectives add draw.3.dream dummy "boss敌层数"


bossbar add dlc:draw_bossbar {"text":"笔墨入画","color":"white"}
bossbar set dlc:draw_bossbar color white
bossbar set dlc:draw_bossbar max 3

scoreboard objectives add draw.boss.hp1 dummy
scoreboard objectives add draw.boss.hp2 dummy
scoreboard objectives add draw.boss.hp3 dummy

bossbar add dlc:draw_bosshpmath1 {"text":"神性","color":"yellow"}
bossbar set dlc:draw_bosshpmath1 color yellow
bossbar set dlc:draw_bosshpmath1 max 8

bossbar add dlc:draw_bosshpmath2 {"text":"神性","color":"yellow"}
bossbar set dlc:draw_bosshpmath2 color yellow
bossbar set dlc:draw_bosshpmath2 max 10

bossbar add dlc:draw_bosshpmath3 {"text":"神性","color":"yellow"}
bossbar set dlc:draw_bosshpmath3 color yellow
bossbar set dlc:draw_bosshpmath3 max 5


bossbar add dlc:draw_bosshp1 {"text":"良先生","color":"black"}
bossbar add dlc:draw_bosshp2 {"text":"神笔马良","color":"black"}
bossbar add dlc:draw_bosshp3 {"text":"背负罪孽之人","color":"black"}

bossbar set dlc:draw_bosshp1 color purple
bossbar set dlc:draw_bosshp2 color purple
bossbar set dlc:draw_bosshp3 color purple
bossbar set dlc:draw_bosshp1 max 100
bossbar set dlc:draw_bosshp2 max 100
bossbar set dlc:draw_bosshp3 max 100


scoreboard objectives add draw.player.cs.all dummy

scoreboard objectives add draw.system.time dummy
scoreboard objectives add draw.system.timelast dummy
#加载建筑
forceload add 622 -1990 653 -1952
setblock 633 9 -1968 structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "Creazeny", rotation: "NONE", posX: -8, mode: "LOAD", posY: 1, sizeX: 8, posZ: 1, integrity: 1.0f, showair: 0b, name: "draw:draw_start", x: 633, y: 9, z: -1968, id: "minecraft:structure_block", sizeY: 8, sizeZ: 11, showboundingbox: 1b} replace
setblock 632 9 -1967 structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "Creazeny", rotation: "NONE", posX: 1, mode: "LOAD", posY: 1, sizeX: 17, posZ: -19, integrity: 1.0f, showair: 0b, name: "draw:draw_chest", x: 632, y: 9, z: -1967, id: "minecraft:structure_block", sizeY: 10, sizeZ: 19, showboundingbox: 1b} replace
setblock 632 8 -1967 redstone_block
setblock 633 8 -1968 redstone_block
fill 632 8 -1968 633 9 -1967 air replace
forceload remove 622 -1990 653 -1952
#单独加载副本主体（副本内可能发生变动）
forceload add 628 -1945 681 -1894
setblock 653 55 -1920 structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "Creazeny", rotation: "NONE", posX: 1, mode: "LOAD", posY: -44, sizeX: 27, posZ: -26, integrity: 1.0f, showair: 0b, name: "draw:4", x: 653, y: 55, z: -1920, id: "minecraft:structure_block", sizeY: 44, sizeZ: 26, showboundingbox: 1b} replace
setblock 653 55 -1921 structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "Creazeny", rotation: "NONE", posX: 1, mode: "LOAD", posY: -44, sizeX: 27, posZ: 1, integrity: 1.0f, showair: 0b, name: "draw:3", x: 653, y: 55, z: -1921, id: "minecraft:structure_block", sizeY: 44, sizeZ: 26, showboundingbox: 1b} replace
setblock 654 55 -1921 structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "Creazeny", rotation: "NONE", posX: -25, mode: "LOAD", posY: -44, sizeX: 25, posZ: 1, integrity: 1.0f, showair: 0b, name: "draw:2", x: 654, y: 55, z: -1921, id: "minecraft:structure_block", sizeY: 44, sizeZ: 26, showboundingbox: 1b} replace
setblock 654 55 -1920 structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "Creazeny", rotation: "NONE", posX: -25, mode: "LOAD", posY: -44, sizeX: 25, posZ: -26, integrity: 1.0f, showair: 0b, name: "draw:1", x: 654, y: 55, z: -1920, id: "minecraft:structure_block", sizeY: 44, sizeZ: 26, showboundingbox: 1b} replace
fill 653 56 -1920 654 56 -1921 redstone_block replace
fill 653 56 -1920 654 55 -1921 air replace
forceload remove 628 -1945 681 -1894





scoreboard objectives add draw_start dummy
scoreboard players set #system draw_start 1