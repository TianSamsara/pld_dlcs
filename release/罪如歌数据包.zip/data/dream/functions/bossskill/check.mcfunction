scoreboard players set #system dream.buff1 0
scoreboard players set #system dream.buff2 0
scoreboard players set #system dream.buff3 0
scoreboard players set #system dream.buff4 0
execute if score #system dream_buff1 matches 1 run tellraw @a[scores={dlc_ins=3}] {"text":"上轮奇兵全部死亡,该轮中每8秒位置最低的2名玩家受到20点伤害","color": "red"}
execute if score #system dream_buff2 matches 1 run tellraw @a[scores={dlc_ins=3}] {"text":"上轮盾兵全部死亡,该轮中使徒将每8秒获得持续2秒的无敌","color": "red"}
execute if score #system dream_buff3 matches 1 run tellraw @a[scores={dlc_ins=3}] {"text":"上轮斧兵全部死亡,该轮中使徒获得攻击能力","color": "red"}
execute if score #system dream_buff4 matches 1 run tellraw @a[scores={dlc_ins=3}] {"text":"上轮戟兵全部死亡,该轮中每8秒位置最高的玩家获得4秒负面药水效果","color": "red"}
execute if score #system dream_buff1 matches 1 run scoreboard players set #system dream.buff1 1
execute if score #system dream_buff2 matches 1 run scoreboard players set #system dream.buff2 1
execute if score #system dream_buff3 matches 1 run scoreboard players set #system dream.buff3 1
execute if score #system dream_buff4 matches 1 run scoreboard players set #system dream.buff4 1

schedule function dream:bossskill/main 3s