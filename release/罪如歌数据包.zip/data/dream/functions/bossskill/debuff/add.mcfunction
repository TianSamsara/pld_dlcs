scoreboard players add @s dream_debuff 1
tellraw @s [{"text":"一名幻境使徒死亡,距离其最近的你受到","color":"white"},{"text":"[梦之殇]","color":"aqua"},{"text":"诅咒的蔓延","color":"white"}]
tellraw @s [{"text":"当前","color":"white"},{"text":"[梦之殇]","color":"aqua"},{"text":"层数:","color":"white"},{"score":{"name": "@s","objective": "dream_debuff"}}]