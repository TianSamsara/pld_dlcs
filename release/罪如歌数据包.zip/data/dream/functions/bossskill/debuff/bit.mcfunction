damage @s 30 out_of_world
scoreboard players remove @s dream_debuff 3
tellraw @s [{"text":"[梦之殇]","color":"aqua"},{"text":"堆叠从而爆发,你流失30点生命值,并移去3层","color":"white"},{"text":"[梦之殇]","color":"aqua"}]
