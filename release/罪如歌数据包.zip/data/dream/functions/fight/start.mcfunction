scoreboard players set #system dream_bosshp 8
execute store result bossbar pl:dream_bosshp value run scoreboard players get #system dream_bosshp
scoreboard players reset #system dream_buff1
scoreboard players reset #system dream_buff2
scoreboard players reset #system dream_buff3
scoreboard players reset #system dream_buff4

execute as @a[distance=..8,limit=5,sort=nearest] at @s if block ~ ~-1 ~ gold_block run scoreboard players set @s dlc_ins 3
scoreboard players set @a[scores={dlc_ins=3}] feather_mainland -1
tp @a[scores={dlc_ins=3}] 237 12 -2112
scoreboard players set #system dream_on 0
tellraw @a[scores={dlc_ins=3}] [{"text":"幻境守护着使徒,并拖拽着你们的身体","color":"gold"}]
tellraw @a[scores={dlc_ins=3}] [{"text":"每灭绝一种幻境生物,都会削弱幻境,更好的去击杀使徒","color":"gold"}]
tellraw @a[scores={dlc_ins=3}] [{"text":"击杀使徒,可令幻境灵性削减,直至击破幻境","color":"gold"}]
schedule function dream:bossskill/check 2s
