effect clear @e[tag=monster,tag=fairy_boss,tag=dlc]
tellraw @a[scores={dlc_ins=4}] [{"text":"卯十八/柳将军潜力激发效果结束,受到伤害大幅提升","color": "red"}]