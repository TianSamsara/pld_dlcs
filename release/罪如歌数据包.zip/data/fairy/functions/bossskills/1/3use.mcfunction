execute if score #dlc sword.boss.maxhp matches 2..3 run tellraw @a[scores={dlc_ins=4}] [{"text":"柳将军解放轩辕弓,接下来的战斗中其箭矢强度翻倍","color": "aqua"}]
scoreboard players set #dlc sword.skillcool.3 400
#侍者箭矢强度增加
execute as @e[tag=fairy_boss,tag=dlc,tag=1] store result score @s archer_damage run data get entity @s HandItems[0].tag.Enchantments[0].lvl
scoreboard players set #temp temp 2
execute as @e[tag=fairy_boss,tag=dlc,tag=1] run scoreboard players operation @s archer_damage *= #temp temp
execute as @e[tag=fairy_boss,tag=dlc,tag=1] store result entity @s HandItems[0].tag.Enchantments[0].lvl int 1 run scoreboard players get @s archer_damage