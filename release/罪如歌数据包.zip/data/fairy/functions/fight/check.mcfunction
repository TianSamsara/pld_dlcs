#检测副本是否有人
execute if entity @a[scores={dlc_ins=4}] run tellraw @a[distance=..8] [{"text":"刀光剑影划过你的脸颊,还是等这场战斗结束吧","color": "gray","italic": true}]
execute unless entity @a[scores={dlc_ins=4}] run function fairy:fight/main
