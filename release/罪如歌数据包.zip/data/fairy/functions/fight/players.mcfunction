scoreboard players set @s dlc_ins 4
scoreboard players set @s feather_mainland -1


tp @s ~ ~ ~23

tellraw @s [{"text":"卯十八/柳将军:吾曾屠戮万千生灵而不知道,亦曾悟道数日而明己心。","color": "gold"}]
tellraw @s [{"text":"卯十八/柳将军:现在,试着击败现在与曾经的我吧,尽力而为即可。","color": "gold"}]