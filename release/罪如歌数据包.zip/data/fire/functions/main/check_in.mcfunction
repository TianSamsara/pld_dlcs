#检测副本内是否有人
execute if entity @a[scores={dlc_ins=2}] run tellraw @a[x=470,y=3,z=-1530,dx=2,dy=4,dz=4] {"text": "§7阵法保护了其入口,让你无法前进。过一会再来吧！"}
execute unless entity @a[scores={dlc_ins=2}] run function fire:main/excheck