##检测boss血量是否为0,如果不为0则继续
execute if score #system instance7_bosshp matches 1.. run function fire:main/ex0/random
execute if score #system instance7_bosshp matches 0 run function fire:main/ex0/boss_death


