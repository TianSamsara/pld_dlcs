##当火核心进入火阵法且没有invulnerable标签时 触发此函数
data modify entity @s Attributes[{Name:"minecraft:generic.movement_speed"}].Base set value 0.3
data modify entity @s Attributes[{Name:"minecraft:generic.attack_damage"}] set value 35
tag @s add invulnerable

