##当火阵法核心走到水阵法时 触发此函数(有可能会循环触发)
data modify entity @s Attributes[{Name:"minecraft:generic.movement_speed"}].Base set value 0.2
data modify entity @s Attributes[{Name:"minecraft:generic.attack_damage"}] set value 20
tag @s remove invulnerable
effect clear @s resistance