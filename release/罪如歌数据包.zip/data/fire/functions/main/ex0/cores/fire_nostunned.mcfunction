##当火核心眩晕结束时 执行此函数
data modify entity @e[type=wither_skeleton,tag=firecore,tag=!invulnerable,limit=1] NoAI set value 0
data modify entity @e[type=wither_skeleton,tag=firecore,tag=!invulnerable,limit=1] CustomName set value '{"text":"§c千斤燃烧的 火阵法核心"}'
