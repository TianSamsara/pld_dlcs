##进度检测
advancement revoke @s only fire:firecore
tellraw @s [{"text":"周围的火焰淹没了这次攻击...","color":"red"}]