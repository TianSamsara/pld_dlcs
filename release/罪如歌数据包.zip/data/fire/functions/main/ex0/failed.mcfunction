##当玩家失败时 执行此函数
execute if score #system instance7_bosshp matches 12 run function fire:main/ex0/failed_maxhp
execute if score #system instance7_bosshp matches ..11 run function fire:main/ex0/failed_notmaxhp