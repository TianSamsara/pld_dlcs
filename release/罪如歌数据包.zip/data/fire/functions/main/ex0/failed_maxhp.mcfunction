##当boss血量满额且玩家失败时 执行此函数
tellraw @a[scores={dlc_ins=2}] [{"text":"蛤蟆吐出火雾,在场所有玩家受到伤害","color":"yellow"}]
effect give @a[scores={dlc_ins=2}] instant_damage 1 4 true

#重置并下一轮
function fire:main/ex0/reset
schedule function fire:main/ex0/random 2s replace