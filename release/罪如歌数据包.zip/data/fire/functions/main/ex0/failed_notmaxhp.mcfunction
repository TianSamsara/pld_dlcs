##当boss血量不满且玩家失败时 执行此函数
tellraw @a[scores={dlc_ins=2}] [{"text":"蛤蟆吸收阵法的力量,回复了一点血量","color":"yellow"}]
scoreboard players add #system instance7_bosshp 1

#重置并下一轮
function fire:main/ex0/reset
schedule function fire:main/ex0/random 2s replace