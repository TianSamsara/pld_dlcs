##当#system的instance7_firewater计分板为1时 循环执行此函数

#把区域中带有Iswater标签的怪数量 写入instance7_firewater_watercount计分板
execute store result score #system instance7_firewater_watercount run execute if entity @e[x=306,y=4,z=-1612,dx=118,dy=59,dz=75,type=!player,tag=Iswater]

#把区域中带有Isfire标签的怪数量 写入instance7_firewater_firecount计分板
execute store result score #system instance7_firewater_firecount run execute if entity @e[x=306,y=4,z=-1612,dx=118,dy=59,dz=75,type=!player,tag=Isfire]

#当怪物数量少于6时 执行失败函数
execute unless entity @e[x=306,y=4,z=-1612,dx=118,dy=59,dz=75,type=!player,tag=Iswater] run function fire:main/ex0/success
execute if score #system instance7_firewater_firecount matches ..5 run function fire:main/ex0/failed
