#重置副本内部
function fire:main/ex0/reset

#玩家进场

tp @s 412 16 -1580 90 ~
scoreboard players set @s dlc_ins 2
scoreboard players set #system instance7_bosshp 10
tellraw @s [{"text":"看来眼前的不明蛤蟆就是导致问题出现的原因。","color":"aqua"}]
#随机招式
schedule function fire:main/ex0/random 3s replace
function fire:loop