##当玩家按下按钮时且#system的instnace7_parkour为1时 触发此函数
effect clear @e[x=306,y=4,z=-1612,dx=118,dy=59,dz=75,type=!player] resistance
scoreboard players set #system instance7_parkour_sword 1
tellraw @a[scores={dlc_ins=2}] [{"text":"阵法的力量被中和,魔物的防御下降了...\n","color":"aqua"},{"text":"请将所有魔物击杀！","color":"yellow"}]