##当玩家按下按钮时 执行此函数
execute if score #system instance7_parkour matches 1 if score #system instance7_parkour_sword matches 0 run function fire:main/ex0/parkour/cleareffect