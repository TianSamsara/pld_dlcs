
execute as @a[x=0,y=8,z=-2018,dx=43,dy=26,dz=29] store result score @s fire_zffirecount run clear @s blaze_rod{id: "fire:fire"} 0
execute as @a[x=0,y=8,z=-2018,dx=43,dy=26,dz=29] if score @s fire_zffirecount matches 10.. run function fire:waterfire/ex0/finishfire
execute as @a[x=-2,y=5,z=-2209,dx=47,dy=46,dz=47] store result score @s fire_zfwatercount run clear @s string{id: "fire:water"} 0
execute as @a[x=-2,y=5,z=-2209,dx=47,dy=46,dz=47] if score @s fire_zfwatercount matches 10.. run function fire:waterfire/ex0/finishwater
schedule function fire:tick1s 1s replace

execute as @a[scores={fire_wfon=1}] run scoreboard players add @s fire_wftime 1
#execute as @a[scores={fire_wfwon=1}] run scoreboard players add @s fire_wfwtime 1
#execute as @a[scores={fire_dye=1}] run scoreboard players add @s fire_dye_time 1
#execute as @a[scores={fire_bird=1}] run scoreboard players add @s fire_bird_time 1

execute as @a[scores={fire_wftime=1}] run tellraw @s {"text":"","extra":[{"text":"谷主-忘尘","color":"aqua"},{"text":":有趣...这是一个火阵法,但遭到了","color":"white"},{"text":"破坏","color":"blue"},{"text":"。","color":"white"}]}
execute as @a[scores={fire_wftime=5}] run tellraw @s {"text":"","extra":[{"text":"谷主-忘尘","color":"aqua"},{"text":":试着收集这些魔物身上的","color":"white"},{"text":"火元素","color":"aqua"},{"text":",我可以试着修补火阵法,这样才得以继续前进。","color":"white"}]}
execute as @a[scores={fire_wftime=6}] run tellraw @s [{"text":"请收集","color":"gray"},{"text":"高纯度火元素碎片","color":"aqua"},{"text":" x10","color":"gray"}]
execute as @a[scores={fire_wftime=6}] run scoreboard players set @s fire_wfon 0
execute as @a[scores={fire_wftime=6}] run scoreboard players set @s fire_wftime 0

#execute as @a[scores={fire_wfwtime=1}] run tellraw @s {"text":"","extra":[{"text":"谷主-忘尘","color":"aqua"},{"text":":这次是水阵法,同样需要收集","color":"white"},{"text":"高纯度水元素碎片","color":"blue"},{"text":"x 10,才能修复阵法继续前进。","color":"white"}]}
#execute as @a[scores={fire_wfwtime=1}] run scoreboard players set @s fire_wfwon 0
#execute as @a[scores={fire_wfwtime=1}] run scoreboard players set @s fire_wfwtime 0

#scoreboard players remove @a[scores={fire_leggingscd=0..},nbt={Inventory: [{tag: {id: "dlc:fire_legs"}}]}] fire_leggingscd 1
#execute as @a[scores={fire_leggingscd=0},nbt={Inventory: [{tag: {id: "dlc:fire_legs"}}]}] run tellraw @s {"text":"[神器][火神]准备就绪！","color":"red"}
#execute as @e[tag=firecore,tag=invulnerable] at @s run particle flame ~ ~ ~ 0.5 1 0.5 0 100 force

#execute as @a[scores={fire_dye_time=1}] run effect give @s blindness 20 0 false
#execute as @a[scores={fire_dye_time=1}] run tellraw @s ["§b神秘的石碑§r:你是哪族来的小生？居然有沾染此物的东西..."]
#execute as @a[scores={fire_dye_time=3}] run tellraw @s ["§b神秘的石碑§r:那家伙不是已经被封印了吗。"]
#execute as @a[scores={fire_dye_time=5}] run tellraw @s ["§b神秘的石碑§r:不对,这股气息不对劲,此事不简单,居然会沾染朱雀的力量。"]
#execute as @a[scores={fire_dye_time=10}] run tellraw @s ["§b神秘的石碑§r:这位朋友,能否请你前往朱雀所在地查看一下情况？我感觉这件事不太简单,如果处理不当可能会危害到很多生命。"]
#execute as @a[scores={fire_dye_time=18}] run tellraw @s ["§b神秘的石碑§r:你且拿着这枚令牌前往朱雀分魂所在地,里面有我的一丝神识气息,交予朱雀分魂她便会协助你的。"]
#execute as @a[scores={fire_dye_time=18}] run give @s brick{CustomModelData: 4, display: {Lore: ['{"text":"稀有度:特殊","color":"aqua","italic":false}', '{"text":"请手持此令牌对朱雀分魂右键","color":"gold"}'], Name: '{"text":"神秘石碑的令牌","color":"yellow","italic":false}'}, id: "fire:lingpai", Enchantments: [{id: "minecraft:protection", lvl: 1}], HideFlags: 63}
#execute as @a[scores={fire_dye_time=18}] run scoreboard players set @s fire_dye -1
#execute as @a[scores={fire_dye_time=18}] run scoreboard players set @s fire_dye_time 0


#execute as @a[scores={fire_bird_time=1}] run tellraw @s ["§b朱雀分魂§r:嗯？居然是那破石头的令牌。"]
#execute as @a[scores={fire_bird_time=1}] run tellraw @s ["§8你察觉到朱雀分魂脸色微变"]
#execute as @a[scores={fire_bird_time=3}] run tellraw @s ["§b朱雀分魂§r:此事我已大致了解,这件事,还要从那件事说起..."]
#execute as @a[scores={fire_bird_time=6}] run tellraw @s ["§b朱雀分魂§r:以前有只不知道哪里冒出来的蛤蟆,本来朱雀在火山内部划分出一块地界给予它生存"]
#execute as @a[scores={fire_bird_time=11}] run tellraw @s ["§b朱雀分魂§r:本来一切都按照着最好的方向发展,可突然有一天这只蛤蟆开始狂躁起来,本来智慧不高的它根本控制不住自己,"]
#execute as @a[scores={fire_bird_time=16}] run tellraw @s ["§b朱雀分魂§r:开始在岩浆里翻来覆去闹腾,结果被沙漠深处的篆元真人感应到不对劲,他马上停下对石碑的研究回到族内报告,"]
#execute as @a[scores={fire_bird_time=21}] run tellraw @s ["§b朱雀分魂§r:由于在朱雀所栖息的火山里,仙族与其神族一起进入了火山查看,发现了这只蛤蟆,神族的一众长老质问朱雀为何不告知此事,"]
#execute as @a[scores={fire_bird_time=26}] run tellraw @s ["§b朱雀分魂§r:但还未等到回答,蛤蟆突然袭来对仙族与神族大打出手,双方激战了起来,蛤蟆寡不敌众,被仙神两族迅速击败,正欲击杀蛤蟆时,"]
#execute as @a[scores={fire_bird_time=31}] run tellraw @s ["§b朱雀分魂§r:神族大长老突然出现拦下了最后的攻击,并冰冷的看着众人说道:\"这只蛤蟆我来处理,这里的事情不许透露出去,你们速速离去。\""]
#execute as @a[scores={fire_bird_time=36}] run tellraw @s ["§b朱雀分魂§r:神族大长老那不容人反抗的语气让大家一下就不敢多言,并且连着朱雀也一起离去..."]
#execute as @a[scores={fire_bird_time=41}] run tellraw @s ["§b朱雀分魂§r:后面的事情我就不得而知了,想不到居然又出现了这只蛤蟆的消息,但为何它的气息如此奇怪？"]
#execute as @a[scores={fire_bird_time=45}] run tellraw @s ["§b朱雀分魂§r:这股气息,就像沾染了某个神的气息...好像是神族大长老的..."]
#execute as @a[scores={fire_bird_time=48}] run tellraw @s ["§b朱雀分魂§r:我给予你一件宝物,如果你能找到族内前辈,可能会有所帮助。"]
#execute as @a[scores={fire_bird_time=51}] run tellraw @s ["§b朱雀分魂§r:如果可以的话,请让这只蛤蟆解脱吧,我觉得神族大长老不太简单..."]
#execute as @a[scores={fire_bird_time=51}] run give @s brick{CustomModelData: 1, display: {Lore: ['{"text":"稀有度:特殊","italic":false,"color":"aqua"}', '{"text":"请将此物交于谷主-忘尘","color":"gold"}'], Name: '{"text":"朱雀分魂赠送的宝物","italic":false,"color":"aqua"}'}, Enchantments: [{id: "protection", lvl: 1}], HideFlags: 63, id: "fire:EX1"}
#execute as @a[scores={fire_bird_time=51}] run scoreboard players set @s fire_EX 1
#execute as @a[scores={fire_bird_time=56}] run tellraw @s ["§6你知道了蛤蟆身世的真相。这份记忆将会烙印在你的灵魂中,即使转世也不会遗忘。"]
#execute as @a[scores={fire_bird_time=60}] run tp @s 3209 148 -800
#execute as @a[scores={fire_bird_time=60}] run scoreboard players set @s fire_bird -1
#execute as @a[scores={fire_bird_time=60}] run scoreboard players set @s fire_bird_time 0