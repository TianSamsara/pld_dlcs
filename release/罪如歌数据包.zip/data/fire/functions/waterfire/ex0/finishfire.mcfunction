clear @s blaze_rod{id:"fire:fire"}
tp @s 40 8 -2187 90 ~
tp @e[type=!player,tag=water] ~ ~-1000 ~
scoreboard players set @s fire_wftime 0
scoreboard players set @s fire_wfwtime 0
scoreboard players set @s fire_wfwon 0
scoreboard players set @s fire_wfon 0
scoreboard players reset @s fire_zffirecount
tellraw @s {"text":"","extra":[{"text":"谷主-忘尘","color":"aqua"},{"text":":这次是水阵法,同样需要收集","color":"white"},{"text":"高纯度水元素碎片","color":"blue"},{"text":"x 10,才能修复阵法继续前进。","color":"white"}]}
