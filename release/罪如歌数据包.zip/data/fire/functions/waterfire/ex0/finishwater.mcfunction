clear @s string{id:"fire:water"}

tp @s 474 4 -1528 90 ~
tellraw @s {"text":"","extra":[{"text":"谷主-忘尘","color":"aqua"},{"text":":前方的阵法将我的分身挡在了外面,不过封印已经打开了,速速进入！后面的事情就拜托了！","color":"white"}]}
scoreboard players set @s fire_wfwon 0
scoreboard players set @s fire_wftime 0
scoreboard players set @s fire_wfwtime 0
scoreboard players reset @s fire_zfwatercount