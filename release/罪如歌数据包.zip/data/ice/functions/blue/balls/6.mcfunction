#5s 压力板
execute if score #system ice_blueballs6_time matches 100 run setblock 236 7 -1654 minecraft:stone_pressure_plate
#5s冰块clone
execute if score #system ice_blueballs6_time matches 100 run clone 240 5 -1610 244 10 -1606 234 13 -1656 replace
#4s清除旧冰块
execute if score #system ice_blueballs6_time matches 80 run fill 219 8 -1647 257 22 -1674 air replace packed_ice
#4s冰块clone
execute if score #system ice_blueballs6_time matches 80 run clone 240 5 -1610 244 10 -1606 234 12 -1656 replace
#3s清除旧冰块
execute if score #system ice_blueballs6_time matches 60 run fill 219 8 -1647 257 22 -1674 air replace packed_ice
#3s冰块clone
execute if score #system ice_blueballs6_time matches 60 run clone 240 5 -1610 244 10 -1606 234 11 -1656 replace
#2s清除旧冰块
execute if score #system ice_blueballs6_time matches 40 run fill 219 8 -1647 257 22 -1674 air replace packed_ice
#2s冰块clone
execute if score #system ice_blueballs6_time matches 40 run clone 240 5 -1610 244 10 -1606 234 10 -1656 replace
#1s清除旧冰块
execute if score #system ice_blueballs6_time matches 20 run fill 219 8 -1647 257 22 -1674 air replace packed_ice
#1s冰块clone
execute if score #system ice_blueballs6_time matches 20 run clone 240 5 -1610 244 10 -1606 234 9 -1656 replace
#0s清除冰块
execute if score #system ice_blueballs6_time matches 0 run fill 219 8 -1647 257 22 -1674 air replace packed_ice
#0s检测是否失败
execute if score #system ice_blueballs6_time matches 0 run execute unless entity @a[x=236,y=7,z=-1654,dx=0,dy=0,dz=0] run function ice:blue/balls/fail
#0s失败清除压力板
execute if score #system ice_blueballs6_time matches 0 run execute unless entity @a[x=236,y=7,z=-1654,dx=0,dy=0,dz=0] run setblock 236 7 -1654 minecraft:air
#0s如果成功则轮次-1
execute if score #system ice_blueballs6_time matches 0 run execute if entity @a[x=236,y=7,z=-1654,dx=0,dy=0,dz=0] run scoreboard players remove #system ice_blueballscount 1
#0s成功清除压力板
execute if score #system ice_blueballs6_time matches 0 run execute if entity @a[x=236,y=7,z=-1654,dx=0,dy=0,dz=0] run setblock 236 7 -1654 minecraft:air
#0s成功播放音效
execute if score #system ice_blueballs6_time matches 0 run execute if entity @a[x=236,y=7,z=-1654,dx=0,dy=0,dz=0] run execute as @a[scores={dlc_ins=1}] at @s run execute at @s run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1 1
#0s成功且还有剩余轮次则进入下一轮次
execute if score #system ice_blueballs6_time matches 0 run execute if entity @a[x=236,y=7,z=-1654,dx=0,dy=0,dz=0] if score #system ice_blueballscount matches 1.. run schedule function ice:blue/random 2s
#0s成功且没有轮次则直接扣boss血
execute if score #system ice_blueballs6_time matches 0 run execute if entity @a[x=236,y=7,z=-1654,dx=0,dy=0,dz=0] if score #system ice_blueballscount matches 0 run schedule function ice:up 1s
#0s成功扣玩家血
execute if score #system ice_blueballs6_time matches 0 run effect give @a[x=236,y=7,z=-1654,dx=0,dy=0,dz=0] instant_damage 1 0 true
#计时器运作
execute if score #system ice_blueballs6_time matches 0.. run scoreboard players remove #system ice_blueballs6_time 1